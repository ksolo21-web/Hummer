window.MSC_POINTERS = [
  {
    "id": "listen-first",
    "title": "Listen before answering",
    "body": "Give the person enough time to explain what matters to them. A thoughtful response begins with genuine attention.",
    "scripture": "James 1:19",
    "practice": "Ask one sincere follow-up question before sharing a scripture."
  },
  {
    "id": "warm-opening",
    "title": "Begin warmly",
    "body": "A calm greeting and friendly expression can lower tension and show that your interest is personal, not mechanical.",
    "scripture": "Colossians 4:6",
    "practice": "Use the person’s name when it is offered and keep the opening conversational."
  },
  {
    "id": "simple-question",
    "title": "Use one simple question",
    "body": "A clear question invites participation and helps you learn which thought may be useful to the person.",
    "scripture": "Proverbs 20:5",
    "practice": "Ask a question that can be answered without religious background."
  },
  {
    "id": "read-scripture",
    "title": "Let the Bible speak",
    "body": "When appropriate, read the verse rather than only summarizing it. Pause so the person can consider the wording.",
    "scripture": "Hebrews 4:12",
    "practice": "Introduce one short verse and ask what phrase stands out."
  },
  {
    "id": "personal-interest",
    "title": "Show personal interest",
    "body": "Adapt the conversation to the individual’s age, concerns, culture, and available time.",
    "scripture": "1 Corinthians 9:22, 23",
    "practice": "Change your planned presentation when the person reveals a more important concern."
  },
  {
    "id": "common-ground",
    "title": "Start with common ground",
    "body": "A point you both value can make the conversation respectful and easier to continue.",
    "scripture": "Acts 17:22, 23",
    "practice": "Acknowledge one reasonable concern before introducing a Bible thought."
  },
  {
    "id": "brief-clear",
    "title": "Keep it brief and clear",
    "body": "A small, understandable spiritual thought is often more memorable than too much information.",
    "scripture": "1 Corinthians 14:9",
    "practice": "Explain the main point in one sentence, then pause."
  },
  {
    "id": "positive-tone",
    "title": "Use a positive tone",
    "body": "Even when discussing serious problems, emphasize Jehovah’s hope and the practical help found in his Word.",
    "scripture": "Romans 15:4",
    "practice": "End the conversation with one encouraging promise or benefit."
  },
  {
    "id": "observe",
    "title": "Observe respectfully",
    "body": "Notice clues such as family needs, language, timing, and whether the person appears rushed—without making assumptions.",
    "scripture": "Philippians 2:4",
    "practice": "Adjust the length and subject to what you respectfully observe."
  },
  {
    "id": "natural-transition",
    "title": "Make a natural transition",
    "body": "Connect the scripture to what the person just said so it does not feel like a memorized change of subject.",
    "scripture": "Acts 8:30-35",
    "practice": "Repeat one key phrase from the person’s comment before introducing the verse."
  },
  {
    "id": "invite-response",
    "title": "Invite a response",
    "body": "After reading or explaining a thought, leave room for the person to react instead of filling every silence.",
    "scripture": "Luke 10:26",
    "practice": "Ask, ‘What do you think about that?’ and listen fully."
  },
  {
    "id": "respect-time",
    "title": "Respect the person’s time",
    "body": "Kindly recognizing that someone is busy can leave a good impression and make a return visit more welcome.",
    "scripture": "Matthew 7:12",
    "practice": "Offer one brief thought and ask when a better time might be."
  },
  {
    "id": "return-purpose",
    "title": "Give the return visit a purpose",
    "body": "Mention the specific question or promise you would like to discuss next time.",
    "scripture": "1 Corinthians 3:6",
    "practice": "End with one open question you can answer on the return visit."
  },
  {
    "id": "use-tract",
    "title": "Use the tool, not a speech",
    "body": "A tract or article can support a conversation, but the person’s needs should guide how you use it.",
    "scripture": "2 Timothy 2:24",
    "practice": "Highlight one question or picture rather than covering every section."
  },
  {
    "id": "adapt-language",
    "title": "Use familiar language",
    "body": "Explain Bible truth with everyday words and define any expression that may be unfamiliar.",
    "scripture": "Nehemiah 8:8",
    "practice": "Replace one religious expression with a plain-language explanation."
  },
  {
    "id": "teamwork",
    "title": "Support your partner",
    "body": "Good ministry partners listen to each other, share naturally, and help the conversation remain focused.",
    "scripture": "Ecclesiastes 4:9, 10",
    "practice": "Before starting, agree on how your partner can join the conversation."
  },
  {
    "id": "doorstep-calm",
    "title": "Stay calm at a difficult response",
    "body": "A mild answer protects peace and may keep a negative reaction from becoming a dispute.",
    "scripture": "Proverbs 15:1",
    "practice": "Lower your voice, acknowledge the person’s choice, and leave respectfully."
  },
  {
    "id": "not-argue",
    "title": "Do not argue",
    "body": "Our goal is to help, not to win. Respectful restraint can preserve the possibility of a future conversation.",
    "scripture": "2 Timothy 2:23-25",
    "practice": "When debate starts, return to one simple scripture or end graciously."
  },
  {
    "id": "commend",
    "title": "Commend sincerely",
    "body": "Recognizing an honest thought, a caring quality, or effort to understand can strengthen the conversation.",
    "scripture": "1 Thessalonians 5:11",
    "practice": "Offer one specific, truthful commendation."
  },
  {
    "id": "illustration",
    "title": "Use a simple illustration",
    "body": "A brief, familiar comparison can make an idea easier to understand and remember.",
    "scripture": "Matthew 13:34",
    "practice": "Use one everyday comparison and immediately connect it to the verse."
  },
  {
    "id": "question-later",
    "title": "Leave a question for later",
    "body": "A well-chosen question creates a natural reason to return without pressuring the person.",
    "scripture": "Proverbs 15:28",
    "practice": "Choose a question connected to the concern already discussed."
  },
  {
    "id": "pray-specific",
    "title": "Pray specifically",
    "body": "Ask Jehovah for courage, discernment, and genuine love for the people you may meet.",
    "scripture": "Colossians 4:3, 4",
    "practice": "Before starting, mention one specific quality or situation in prayer."
  },
  {
    "id": "householder-view",
    "title": "See the person, not the door",
    "body": "Each contact represents an individual with experiences, pressures, and spiritual needs.",
    "scripture": "Matthew 9:36",
    "practice": "Silently remind yourself: ‘This person matters to Jehovah.’"
  },
  {
    "id": "scripture-context",
    "title": "Use the verse accurately",
    "body": "A verse is most helpful when its setting and main point support the thought being discussed.",
    "scripture": "2 Timothy 2:15",
    "practice": "Review the surrounding verses before using a less familiar text."
  },
  {
    "id": "offer-choice",
    "title": "Offer a simple choice",
    "body": "Two suitable subjects can help the person choose what is most useful without feeling pressured.",
    "scripture": "Philippians 1:10",
    "practice": "Ask whether they would prefer a thought about family life or hope for the future."
  },
  {
    "id": "voice-pace",
    "title": "Slow your pace",
    "body": "Speaking a little more slowly improves warmth, clarity, and the person’s opportunity to think.",
    "scripture": "Proverbs 25:11",
    "practice": "Pause after the question and after the scripture."
  },
  {
    "id": "follow-interest",
    "title": "Follow the interest",
    "body": "When the person responds to a detail, explore that interest instead of rushing back to a prepared outline.",
    "scripture": "John 4:7-26",
    "practice": "Build your next question from the person’s last sentence."
  },
  {
    "id": "online-kindness",
    "title": "Be just as kind by phone or message",
    "body": "Tone can be harder to read remotely, so brief, warm, and respectful wording is especially important.",
    "scripture": "Ephesians 4:29",
    "practice": "Read the message once for warmth before sending it."
  },
  {
    "id": "finish-well",
    "title": "Finish graciously",
    "body": "A respectful ending can be remembered even when the conversation was short or the person was not interested.",
    "scripture": "1 Peter 3:15",
    "practice": "Thank the person sincerely and avoid a rushed or disappointed tone."
  },
  {
    "id": "record-detail",
    "title": "Record one useful detail",
    "body": "A brief, respectful note can help the next conversation show continuity and personal interest.",
    "scripture": "Proverbs 27:23",
    "practice": "After leaving, record only the detail needed for a considerate return visit."
  },
  {
    "id": "joy",
    "title": "Let your joy be visible",
    "body": "Quiet confidence in the good news can make the message appealing without becoming overly forceful.",
    "scripture": "Philippians 4:4, 5",
    "practice": "Share one reason the Bible’s message has personally encouraged you."
  }
];
