package com.koenterprises.territorycardstudio

import android.app.Application

class TerritoryCardStudioApplication : Application() {
    val services: TerritoryCardStudioServices by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        TerritoryCardStudioServices(this)
    }
}
