package com.koenterprises.territorycardstudio

import com.koenterprises.territorycardstudio.core.BundleIntegrity
import com.koenterprises.territorycardstudio.core.CandidatePdfArtifactReceipt
import com.koenterprises.territorycardstudio.core.CandidateReleaseReview
import com.koenterprises.territorycardstudio.core.CandidatePdfRenderResult
import com.koenterprises.territorycardstudio.core.CandidatePdfRenderSpec
import com.koenterprises.territorycardstudio.core.CandidatePdfRenderer
import com.koenterprises.territorycardstudio.core.CandidateRenderValidationReceipt
import com.koenterprises.territorycardstudio.core.ExactApprovedPdfPassthrough
import com.koenterprises.territorycardstudio.core.PdfArtifactAction
import com.koenterprises.territorycardstudio.core.PdfArtifactAuthorization
import com.koenterprises.territorycardstudio.core.PdfArtifactBoundary
import com.koenterprises.territorycardstudio.core.TerritoryKnowledgeBase
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

data class StoredExactApprovedPdf(
    val displayId: String,
    val canonicalFilename: String,
    val file: File,
    val sha256: String
)

data class StoredCandidatePdf(
    val displayId: String,
    val canonicalFilename: String,
    val file: File,
    val sha256: String,
    val renderSpecSha256: String,
    val exactPdfValidationPassed: Boolean
)

class AndroidPdfArtifactService(
    private val knowledgeBase: TerritoryKnowledgeBase,
    private val privateRoot: File,
    private val lockedTemplatePdf: ByteArray
) {
    private val exactApprovedRoot = File(privateRoot, "pdf/exact-approved-v1").apply {
        require(exists() || mkdirs()) { "Unable to create exact-approved PDF store" }
    }

    private val candidateRoot = File(privateRoot, "pdf/candidates-v1").apply {
        require(exists() || mkdirs()) { "Unable to create candidate PDF store" }
    }

    @Synchronized
    fun importExactApproved(
        displayId: String,
        input: InputStream
    ): StoredExactApprovedPdf {
        val assignment = knowledgeBase.assignments[displayId] ?: error("Unknown territory assignment: $displayId")
        val tmp = File(exactApprovedRoot, ".${assignment.canonicalFilename}.tmp")
        tmp.delete()
        try {
            FileOutputStream(tmp).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
            val sha = tmp.inputStream().use(BundleIntegrity::sha256)
            val authorization = PdfArtifactBoundary.authorizeExactApprovedPassthrough(
                knowledgeBase,
                displayId,
                assignment.canonicalFilename,
                sha
            )
            require(authorization.action == PdfArtifactAction.EXACT_APPROVED_PASSTHROUGH) { authorization.reason }

            // Re-copy through the byte-verifier rather than trusting only the first hash pass.
            val verifiedTmp = File(exactApprovedRoot, ".${assignment.canonicalFilename}.verified.tmp")
            verifiedTmp.delete()
            try {
                tmp.inputStream().use { verifiedInput ->
                    FileOutputStream(verifiedTmp).use { output ->
                        ExactApprovedPdfPassthrough.copyVerified(authorization, verifiedInput, output)
                        output.fd.sync()
                    }
                }
                val target = File(exactApprovedRoot, assignment.canonicalFilename)
                atomicReplace(verifiedTmp, target)
                val finalSha = target.inputStream().use(BundleIntegrity::sha256)
                require(finalSha == assignment.referenceSha256) { "Stored exact-approved PDF hash drift" }
                return StoredExactApprovedPdf(displayId, assignment.canonicalFilename, target, finalSha)
            } finally {
                verifiedTmp.delete()
            }
        } finally {
            tmp.delete()
        }
    }

    @Synchronized
    fun resolveExactApproved(displayId: String): StoredExactApprovedPdf? {
        val assignment = knowledgeBase.assignments[displayId] ?: return null
        val file = File(exactApprovedRoot, assignment.canonicalFilename)
        if (!file.isFile) return null
        val sha = file.inputStream().use(BundleIntegrity::sha256)
        val authorization = PdfArtifactBoundary.authorizeExactApprovedPassthrough(
            knowledgeBase,
            displayId,
            assignment.canonicalFilename,
            sha
        )
        require(authorization.action == PdfArtifactAction.EXACT_APPROVED_PASSTHROUGH) { authorization.reason }
        return StoredExactApprovedPdf(displayId, assignment.canonicalFilename, file, sha)
    }

    @Synchronized
    fun renderCandidate(
        spec: CandidatePdfRenderSpec,
        receipt: CandidateRenderValidationReceipt
    ): StoredCandidatePdf {
        val authorization = PdfArtifactBoundary.authorizeCandidateRender(knowledgeBase, receipt)
        require(authorization.action == PdfArtifactAction.VALIDATED_CANDIDATE_RENDER && authorization.renderAllowed) {
            authorization.reason
        }
        require(spec.identity.displayId == receipt.displayId) { "Candidate render spec/receipt identity mismatch" }
        require(spec.identity.canonicalFilename == receipt.canonicalFilename) { "Candidate render spec/receipt filename mismatch" }
        require(!spec.nonFieldFixture) { "Fixture-only render specs cannot enter app candidate storage" }

        val result: CandidatePdfRenderResult = CandidatePdfRenderer.renderCandidate(lockedTemplatePdf, authorization, spec)
        require(result.exactValidation.passed) { "Generated candidate failed exact internal PDF validation" }
        val target = File(candidateRoot, receipt.canonicalFilename)
        val tmp = File(candidateRoot, ".${receipt.canonicalFilename}.tmp")
        tmp.delete()
        try {
            FileOutputStream(tmp).use { output ->
                output.write(result.pdfBytes)
                output.fd.sync()
            }
            val tmpSha = tmp.inputStream().use(BundleIntegrity::sha256)
            require(tmpSha == result.pdfSha256) { "Candidate PDF write hash mismatch" }
            atomicReplace(tmp, target)
            val finalSha = target.inputStream().use(BundleIntegrity::sha256)
            require(finalSha == result.pdfSha256) { "Stored candidate PDF hash drift" }
            return StoredCandidatePdf(
                displayId = receipt.displayId,
                canonicalFilename = receipt.canonicalFilename,
                file = target,
                sha256 = finalSha,
                renderSpecSha256 = result.renderSpecSha256,
                exactPdfValidationPassed = true
            )
        } finally {
            tmp.delete()
        }
    }

    fun authorizeCandidateRender(receipt: CandidateRenderValidationReceipt): PdfArtifactAuthorization =
        PdfArtifactBoundary.authorizeCandidateRender(knowledgeBase, receipt)

    fun authorizeCandidateRelease(
        artifact: CandidatePdfArtifactReceipt,
        review: CandidateReleaseReview
    ): PdfArtifactAuthorization = PdfArtifactBoundary.authorizeCandidateRelease(knowledgeBase, artifact, review)

    private fun atomicReplace(source: File, target: File) {
        try {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }
}
