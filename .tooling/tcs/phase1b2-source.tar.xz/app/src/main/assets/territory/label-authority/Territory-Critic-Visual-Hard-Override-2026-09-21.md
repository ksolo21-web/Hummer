# Territory Critic Visual Hard Override — 2026-09-21

Status: **HARD OVERRIDE — ACTIVE.** This is additive to every existing territory-card source, geometry, label, family, PDF, identity, housing, reviewer-parity, and score gate.

## Why this override exists
A user-annotated Territory 412a synthetic fixture exposed a critic false-pass. The card still had obvious defects after a claimed pass: street-name labels touched/overlapped map content, a perimeter-road label was placed on the territory-interior side, differently colored work-status strokes visibly painted over one another at junctions, and ordinary direct labels floated farther from their assigned roads than the desired field-reading standard.

The annotated 412a fixture is **negative regression evidence only**. It does not establish geography, assignment, identity, or a positive design reference for any real territory.

## 1. Zero-overlap / zero-contact street-label rule
For every street/navigational label and every callout label, visible glyph ink must have **zero contact and zero overlap** with every map object other than its own invisible placement guide. This includes:

- its assigned road stroke;
- every other road, boundary, junction, branch, cul-de-sac stem/bulb, driveway/access line, or colored work-status stroke;
- another street label, building number, site label, annotation, key, leader, arrow shaft/head, icon, or detail title;
- any building/work footprint outline or filled shape.

Apartment/building numbers that are intentionally contained inside their own verified building footprint are not treated as street labels; they may occupy the interior of that footprint but may not touch/cross the footprint outline, another label, or road geometry.

A label that is merely collision-free by bounding box but visibly touches antialiased road ink still fails. Review actual size plus 4x closeups. Required passing counts: `label_any_object_contact_count: 0` and `label_any_object_overlap_count: 0`.

## 2. Perimeter / outside-border road labels belong on the exterior side
Every label for a territory perimeter/border street must sit on the **exterior side of that road relative to the assigned territory**, never on the worked/interior side. Determine the territory-facing side from the source/coverage model first, then place the label on the opposite side.

Examples: top border -> label above; bottom border -> label below; left border -> label left; right border -> label right, after accounting for actual page rotation/orientation. Curved/diagonal borders use the local exterior normal rather than a page-edge guess.

If exterior placement cannot remain readable inside the map panel, use a clean attached callout or an approved detail rather than moving the label to the interior side. Required passing count: `perimeter_label_inside_count: 0`.

## 3. No visible overlap between different work-status colors
Yellow/green/red road-status paint may meet only at a verified street junction or status-change intersection. Each physical segment carries one status. At a mixed-status junction, strokes must terminate/abut cleanly; one status may not visibly continue on top of, underneath, or along another status segment.

Required passing count: `mixed_status_color_overlap_count: 0`. A clean abutment may contain at most a 1 px antialias seam at exact 1x/72 dpi boundary contact, but no visible second-color overpaint, stacked centerline, blob, or colored cap extending into the other segment is allowed.

This is separate from the intersection-to-intersection work-color rule. A correct transition location can still fail because the rendered paint overlaps sloppily.

## 4. Tight direct/curved label gap — 3 px target, ±1 px only
For ordinary direct and curved street labels, measure visible glyph-ink edge to assigned road-stroke edge on the exact PDF at 1x/72 dpi.

- target: **3 px**;
- hard range: **2–4 px**;
- same-card consistency tolerance: **±1 px maximum**;
- reference-gap median must remain inside 2–4 px;
- every start/middle/end/suffix sample on a curved label must preserve the same close visual association without touching.

A label at 5 px or farther fails even if readable and collision-free. A label below 2 px fails as too close/contact-risk. Do not solve the rule by shrinking the font or moving the road. If a valid direct/curved placement cannot hold 2–4 px cleanly, use the established callout/detail decision tree.

## 5. Mandatory critic report object
Every formal internal or separate critic review must populate `critic_visual_hard_override_review` on the exact reviewed PDF:

```json
{
  "artifact_sha256": "<exact PDF hash>",
  "actual_size_inspected": true,
  "four_x_closeups_inspected": true,
  "all_street_labels_checked_against_all_map_objects": true,
  "label_any_object_contact_count": 0,
  "label_any_object_overlap_count": 0,
  "perimeter_border_labels_checked": true,
  "perimeter_border_label_count": 0,
  "perimeter_label_inside_count": 0,
  "perimeter_label_records": [],
  "mixed_status_junctions_checked": true,
  "mixed_status_junction_count": 0,
  "mixed_status_color_overlap_count": 0,
  "mixed_status_junction_records": [],
  "direct_curved_gap_target_px": 3.0,
  "direct_curved_gap_hard_min_px": 2.0,
  "direct_curved_gap_hard_max_px": 4.0,
  "direct_curved_gap_tolerance_px": 1.0,
  "direct_curved_label_count": 0,
  "direct_curved_gap_violation_count": 0,
  "direct_curved_label_records": [],
  "evidence": []
}
```

Every perimeter record must name the road/label, verified territory side, verified exterior side, and rendered side=`exterior`. Every mixed-status junction record must identify the participating segments/statuses and report zero visible status-overlap pixels. Every direct/curved label record must include its measured gap and zero contact/overlap with any map object.

## 6. Release veto and regression use
Any one of the four defect classes above is `FIX_REQUIRED`, caps labels/family/overall at **8.0**, and keeps `release_ready=false`. Do not average it away. The reviewer must finish the failing round before builder repair, then recapture and re-review the entire changed PDF.

The user-annotated 412a fixture must remain a negative regression reference. A future critic that passes an equivalent inside-border label, label/object overlap, mixed-status color overpaint, or >4 px ordinary direct/curved road gap is itself failing reviewer parity.
