#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
HEX64=re.compile(r'^[0-9a-fA-F]{64}$')

def main(path):
    d=json.loads(Path(path).read_text(encoding='utf-8'))
    r=d.get('critic_visual_hard_override_review'); e=[]
    if not isinstance(r,dict):
        return {'passed':False,'errors':['missing critic_visual_hard_override_review']}
    art=str(r.get('artifact_sha256',''))
    if not HEX64.fullmatch(art): e.append('artifact_sha256 must be 64 hex')
    if d.get('artifact_sha256') and d.get('artifact_sha256')!=art: e.append('artifact hash mismatch')
    for k in ['actual_size_inspected','four_x_closeups_inspected','all_street_labels_checked_against_all_map_objects','perimeter_border_labels_checked','mixed_status_junctions_checked']:
        if r.get(k) is not True: e.append(f'{k} must be true')
    for k in ['label_any_object_contact_count','label_any_object_overlap_count','perimeter_label_inside_count','mixed_status_color_overlap_count','direct_curved_gap_violation_count']:
        if r.get(k)!=0: e.append(f'{k} must equal 0')
    if r.get('direct_curved_gap_target_px')!=3.0: e.append('direct_curved_gap_target_px must equal 3.0')
    if r.get('direct_curved_gap_hard_min_px')!=2.0: e.append('direct_curved_gap_hard_min_px must equal 2.0')
    if r.get('direct_curved_gap_hard_max_px')!=4.0: e.append('direct_curved_gap_hard_max_px must equal 4.0')
    if r.get('direct_curved_gap_tolerance_px')!=1.0: e.append('direct_curved_gap_tolerance_px must equal 1.0')

    per=r.get('perimeter_label_records')
    if not isinstance(per,list): per=[]; e.append('perimeter_label_records must be array')
    if r.get('perimeter_border_label_count')!=len(per): e.append('perimeter_border_label_count must equal perimeter_label_records length')
    for i,x in enumerate(per):
        p=f'perimeter_label_records[{i}]'
        if not isinstance(x,dict): e.append(f'{p} must be object'); continue
        if not str(x.get('label_id','')).strip(): e.append(f'{p}.label_id required')
        if not str(x.get('road','')).strip(): e.append(f'{p}.road required')
        if x.get('territory_side_verified') is not True: e.append(f'{p}.territory_side_verified must be true')
        if not str(x.get('territory_side','')).strip(): e.append(f'{p}.territory_side required')
        if not str(x.get('exterior_side','')).strip(): e.append(f'{p}.exterior_side required')
        if x.get('rendered_side')!='exterior': e.append(f'{p}.rendered_side must be exterior')
        if x.get('result') not in ('pass','PASS',True): e.append(f'{p}.result must pass')

    junc=r.get('mixed_status_junction_records')
    if not isinstance(junc,list): junc=[]; e.append('mixed_status_junction_records must be array')
    if r.get('mixed_status_junction_count')!=len(junc): e.append('mixed_status_junction_count must equal mixed_status_junction_records length')
    for i,x in enumerate(junc):
        p=f'mixed_status_junction_records[{i}]'
        if not isinstance(x,dict): e.append(f'{p} must be object'); continue
        if not str(x.get('junction_id','')).strip(): e.append(f'{p}.junction_id required')
        sts=x.get('statuses')
        if not isinstance(sts,list) or len(set(map(str,sts)))<2: e.append(f'{p}.statuses must contain >=2 distinct statuses')
        if x.get('visible_color_overlap_px')!=0: e.append(f'{p}.visible_color_overlap_px must be 0')
        seam=x.get('antialias_seam_px')
        if not isinstance(seam,(int,float)) or seam<0 or seam>1: e.append(f'{p}.antialias_seam_px must be 0..1')
        if x.get('result') not in ('pass','PASS',True): e.append(f'{p}.result must pass')

    labels=r.get('direct_curved_label_records')
    if not isinstance(labels,list): labels=[]; e.append('direct_curved_label_records must be array')
    if r.get('direct_curved_label_count')!=len(labels): e.append('direct_curved_label_count must equal direct_curved_label_records length')
    for i,x in enumerate(labels):
        p=f'direct_curved_label_records[{i}]'
        if not isinstance(x,dict): e.append(f'{p} must be object'); continue
        if not str(x.get('label_id','')).strip(): e.append(f'{p}.label_id required')
        gap=x.get('assigned_road_gap_px')
        if not isinstance(gap,(int,float)) or gap<2 or gap>4: e.append(f'{p}.assigned_road_gap_px must be 2..4')
        elif abs(float(gap)-3.0)>1.0: e.append(f'{p}.assigned_road_gap_px exceeds 3±1 target')
        if x.get('touches_any_map_object') is not False: e.append(f'{p}.touches_any_map_object must be false')
        if x.get('overlaps_any_map_object') is not False: e.append(f'{p}.overlaps_any_map_object must be false')
        if x.get('result') not in ('pass','PASS',True): e.append(f'{p}.result must pass')

    ev=r.get('evidence')
    if not isinstance(ev,list) or len(ev)<3: e.append('evidence must include actual-size and closeup evidence')
    return {'passed':not e,'errors':e}

if __name__=='__main__':
    if len(sys.argv)!=2:
        print('usage: validate_critic_visual_hard_overrides.py REVIEW.json',file=sys.stderr); sys.exit(2)
    out=main(sys.argv[1]); print(json.dumps(out,indent=2)); sys.exit(0 if out['passed'] else 1)
