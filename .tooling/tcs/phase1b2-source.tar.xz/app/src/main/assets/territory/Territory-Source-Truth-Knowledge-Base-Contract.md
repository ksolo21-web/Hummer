# Territory Source-Truth & Knowledge-Base Contract
Revision: 2026-09-24-source-truth-v1
Status: HARD RELEASE GATE

## Purpose
The Territory Card Creator must never infer one territory's geography, work assignment, street colors, worked sides, or boundaries from another territory card. Approved cards can teach reusable visual/style standards, and an approved card can preserve the known assignment for that exact territory, but cross-territory geographic generalization is prohibited.

## Source roles
Every embedded/reference artifact has an explicit role:

- `style_only`: may teach shell, typography, label grammar, symbol placement, line quality, or layout behavior. It supplies zero geographic authority for a different territory.
- `exact_assignment_reference`: authoritative only for the exact `display_id` recorded in the Territory Knowledge Base and only when its source hash matches, or when a new source is independently reconciled against the locked assignment.
- `negative_regression`: teaches what must fail and never supplies positive geography.

A source without an explicit role is not geographic authority.

## Existing/known territories
A known territory loads its `card_identity`, locked source/reference, assignment facts, and permanent overrides from the local Territory Knowledge Base. The supplied map is reconciled against that territory's own locked assignment. A mismatch is a conflict; it is never silently "fixed" by borrowing geometry from another card.

## New territories
A new territory can enter the knowledge base only from authoritative assignment evidence. A plain consumer/street map plus a territory number does not contain the work assignment and may not be used to invent one. An authoritative colored/assignment map can be accepted only when the deterministic compiler resolves the canonical work-color system, road topology, label bindings, and all applicable building/site assignment evidence without unresolved hard failures.

## Fail-closed rules
Field-use PDF export is blocked when any required source-truth fact is unresolved, including:

- no locked assignment and no authoritative assignment source;
- source/reference role is style-only but is being used as geography;
- source belongs to another territory;
- missing expected street/segment;
- unexpected or unknown street/segment that changes assignment meaning;
- assignment/color disagreement with the locked territory record;
- unresolved perimeter worked side;
- illegal mid-segment color transition;
- unresolved apartment/condo/mobile-site footprint or member/site label;
- source conflict that cannot be reconciled deterministically.

The program must report `BLOCKED`, never guess.

## Road graph rule
Work status is assigned to real junction-to-junction graph segments. A building edge, parcel line, driveway, image coordinate, frontage cutoff, or workload split is not a legal color transition point.

## Audit requirement
Every candidate audit must record:

- territory identity;
- exact source SHA-256;
- source role;
- knowledge-base entry/status;
- source-authority decision and reason;
- locked-reference hash when applicable;
- road inventory/signature and reconciliation result;
- unknown/missing/conflicting street counts;
- road color/role validation;
- label validation;
- building/site validation;
- exact final PDF hash and release decision.

A visual similarity score or successful PDF render never overrides source-truth failure.
