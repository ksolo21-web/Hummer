# Territory Label Uniformity + Road-Line Quality Override — 2026-09-18

This is a mandatory user-authored hard override for every territory card built or reviewed after 2026-09-18. It supplements R52 and is stricter where conflicts exist.

## 1. One street-label type system per card
- Every street-name label on the same card uses one font family, one regular weight, and one point size.
- No bold street labels.
- Do not silently switch between normal/dense sizes.
- If a street name is too long for its road, keep the card's normal street font/size and advance through the placement hierarchy: direct -> curved -> cleaner same-road placement -> nearby attached-arrow callout -> dedicated detail.
- Shrinking a single long label is not an automatic exception; it requires explicit user approval.

## 2. One direct-label spacing standard per card
- Establish the card's approved direct/curved label-to-road gap from a known-good label such as W 3rd St, or from the median of at least three user-approved ordinary labels when no single explicit reference exists.
- All ordinary direct/curved street labels must match that baseline within +/-1 px at 1x/72 dpi.
- Curved labels must maintain the same visual gap over the full word; local samples may not visibly float away.
- A long/short road that cannot carry the full label at the standard gap must use the placement hierarchy; it does not justify a visibly larger direct gap.
- Callouts are exempt from the direct-gap requirement but must be the nearest clean placement and follow all R52 leader rules.


## 2A. Side-selection judgment is mandatory
A technically collision-free label can still be on the wrong visual side of its street. Before finalizing every direct/curved label, the Builder must inspect **both sides of the exact assigned road run** at actual size and choose the side that gives the clearest, closest, most natural association while preserving the card's standard gap.

- Use the side with cleaner usable whitespace when one side is clearly better. Do not keep a label on a cramped/awkward side merely because it passes collision math.
- When both sides are comparably clear, use this orientation tie-breaker for ordinary internal streets: **near-vertical street -> right/east side; near-horizontal street -> north/above side**.
- A perimeter/boundary road or unusual curve may use the opposite side when that is demonstrably cleaner, keeps the label in the usable map area, or avoids another road/junction/label. The exception must be recorded; it is not automatic.
- For a short horizontal street, if the complete name fits at the normal card font/size and standard gap on the north/above side, use that direct placement before any callout.
- For a near-vertical street, if the right/east side has clean room at the standard gap and the left/west side is less natural or more constrained, use the right/east side.
- Callouts remain later in the hierarchy. A callout is prohibited when a clean normal-size direct/curved placement exists on the preferred side or elsewhere along the same road.

Builder evidence for each label must record `side_options_reviewed`, `preferred_side`, `used_side`, `preferred_side_clear`, `preferred_side_reason`, and `callout_justified`. If the used side differs from the preferred side, `opposite_side_exception_reason` is required. The critic must independently challenge this side choice from the exact final PDF rather than trusting Builder assertions.



## 2C. Preferred-side rules are subordinate to exact rendered fit
A side preference is a **tie-breaker only after feasibility is proven**. It is never a mandate and never overrides the zero-road-overlap rule.

For every direct/curved label, the Builder must render and inspect the complete normal-size label candidate on the preferred side before accepting that side. The test must consider the entire glyph envelope, not only the midpoint or assigned-road gap. It must check **all** nearby road strokes, unrelated roads, junctions, bulbs, panel edges, labels and leaders.

Required judgment sequence:
1. Render the preferred-side candidate at the card's standard font, size and gap.
2. Reject that candidate if any glyph touches/overlaps **any** road or if the full label creates junction ambiguity, edge crowding, or label/leader interference.
3. If preferred side fails, inspect the opposite side and cleaner same-road positions using the same tests.
4. Use a callout only after both direct/curved side options and cleaner same-road placements fail visibly.
5. A user's suggested side or a tie-breaker direction is evidence to **test**, not evidence to **pass**. The Builder and critic must use independent rendered judgment.

Builder evidence for every direct/curved label must record `preferred_side_candidate_tested`, `preferred_side_candidate_road_touch_count`, `preferred_side_candidate_road_overlap_count`, `preferred_side_candidate_label_overlap_count`, `preferred_side_candidate_junction_clutter`, and `preferred_side_candidate_fit_clean`. If `used_side == preferred_side`, `preferred_side_candidate_fit_clean` must be true. If the preferred candidate fails, the exact visible reason must be recorded and the label must move to a cleaner treatment.

The critic must independently re-run this judgment from the exact frozen PDF. A preferred/tie-breaker side that overlaps another street is **FIX_REQUIRED** even if the assigned-road gap is perfect and even if a prior user comment suggested that side should fit.

## 3. Absolute no-road-overlap rule
- No street-name glyph may sit on, touch, straddle, underline, or overlap ANY road/street line, whether assigned, boundary, context, or unrelated.
- This is zero-tolerance and applies at actual size and close-up.
- White knockout/cover-up patches over a road to make a label appear clear are not permitted.

## 4. Clean professional street-line standard
For rebuilt/redrawn map linework:
- street strokes must be smooth, deliberate, and visually professional;
- use consistent stroke width for the same road-status/style class;
- keep clean joins and clean endpoints/caps;
- no unexplained kinks, wobbles, stair-steps, flattened curves, doubled strokes, blobs, overshoots, orphan dots, repair scars, or jagged raster remnants;
- no line may be erased/covered merely to make room for a label;
- intersection color transitions remain intersection-to-intersection only under the standing territory rule;
- short branches must terminate cleanly and not bleed through a differently colored boundary road.

Accepted immutable source linework may only be preserved when the task explicitly uses preserve-supplied-map mode. A new redraw/rebuild must meet this professional line-quality standard.

## 5. Builder hard gate
Before critic dispatch, the Builder must record:
- `street_label_font_family`
- `street_label_font_weight`
- `street_label_size_pt`
- `street_label_uniformity_passed: true`
- `direct_gap_reference_label_ids`
- `direct_gap_reference_px`
- `direct_gap_tolerance_px: 1`
- `direct_gap_uniformity_passed: true`
- `label_road_touch_count: 0`
- `label_road_overlap_count: 0`
- `road_line_quality_review` with zero counts for kinks/wobbles/stepoffs/doubled_strokes/overshoots/orphan_dots/repair_scars and `professional_line_quality_passed: true`.

Any violation is FIX_REQUIRED before formal critic review.

## 6. Critic hard veto
The critic must independently remeasure/reinspect the exact final PDF and may not trust Builder assertions.

Any of the following is a hard failure and caps labels/template-family/overall at 8.0 until repaired:
- mixed street-label font family, weight, or point size on one card;
- any ordinary direct/curved label more than 1 px from the card's approved direct-gap baseline;
- any street-name glyph touching/overlapping any road line;
- any avoidably distant label when a closer same-road position exists;
- any unprofessional road stroke: visible kink, wobble, step-off, double stroke, blob, overshoot, orphan artifact, or repair scar;
- any label fix that hides/breaks street linework.

A passing score above 9.0 requires zero violations in all of these fields on the exact delivered PDF.


## 2B. Rendered direct-fit judgment beats heuristic callout assumptions
The Builder may not declare a short street "too short" from a generic length formula alone. Before any callout is allowed, render the complete label at the card's normal street font/size on the **preferred side** at the card's standard gap, then inspect the exact rendered candidate.

- **Direct placement wins** when the rendered normal-size label has the standard road gap, zero glyph/road contact, zero glyph/road overlap, zero label/label overlap, zero junction ambiguity, and positive visible clearance from the roads/junctions at both ends.
- The inherited short-street `label ink + 30 px` / `15 px each end` measurement is a planning target, not authority to force an arrow when the exact normal-size rendered placement is visibly clean. Actual rendered zero-contact fit is the deciding evidence.
- A callout is permitted only after a normal-size direct/curved candidate on the preferred side and any obvious cleaner same-road position have been rendered/tested and fail for a specific visible reason.
- Every callout record must include `direct_candidate_tested:true`, `direct_candidate_side`, `direct_candidate_standard_gap_passed`, `direct_candidate_road_touch_count`, `direct_candidate_road_overlap_count`, `direct_candidate_label_overlap_count`, `direct_candidate_junction_clutter`, `direct_candidate_end_clearance_min_px`, `direct_candidate_fit_clean`, and `direct_candidate_failure_reason`. Unsupported "does not fit" judgments are not evidence.
- If `direct_candidate_fit_clean:true`, the callout is automatically avoidable and therefore FIX_REQUIRED.
- If the user identifies a clean direct placement that the Builder/Critic missed, the prior pass is reopened immediately and that correction becomes a retained positive judgment precedent for comparable geometry.

**Retained negative judgment regression: Territory 258 / W 3rd St.** A preferred-side suggestion is only a placement hypothesis, never proof that the rendered label fits. The attempted north/above direct placement looked plausible conceptually but overlapped another street in the exact PDF and therefore was wrong. The Builder and critic must independently render and inspect the complete label envelope against **every** road/junction before accepting the preferred side. Never force a label onto north/east merely because the tie-breaker points there or because the user expects room; collision-free professional fit controls.

## 2026-09-19 HARD OVERRIDE — road-following labels, junction topology, and callout attachment

This user correction is mandatory for every Builder and every critic. It supersedes any prior pass that allowed a technically readable but visibly wrong road/label relationship. **Territory 259 Round 3 (SHA-256 `fc7b802716b7a1a5bba0954adf8f79b80c77f79f3e0cc85fab0eb6a8fc5f65e2`) is a permanent negative regression fixture and must never be cited as a positive example.** The user rejected it for non-road-following labels, disconnected/improperly joined cul-de-sacs, label/road overlaps, and leaders that were not cleanly attached to their label blocks.

### A. Whole-label road following is mandatory
- A direct label on a curved or changing-direction street must visually follow that street over the **entire label**, including the final word and suffix.
- A single straight baseline is allowed only on a locally straight road run. The Builder must test the road tangent at the label start, middle, and end. If the street visibly bends under the label span, relocate to a straighter same-road run or use curved/path-following text.
- Curved/path-following text must keep the card's standard road gap continuously across the whole label; no first-half-only alignment, wandering suffix, or glyph-by-glyph kinkiness.
- Merely rotating a straight label to an average tangent is not sufficient when the road curvature is visibly material over the label length.
- The critic must inspect every curved-road label at actual size and 4x and record whether the entire word/suffix follows the road. Any failure is `FIX_REQUIRED` and caps labels/family/overall at 8.0 until repaired.

### B. Cul-de-sac and branch topology must be physically continuous
- Every cul-de-sac/stub/branch stem must be **actually connected** to its parent street and, where present, to its bulb/loop. Near-touching geometry is not a connection.
- No visible white gap, detached stem, floating bulb, double-junction, overshoot, or T-junction that stops short of the parent road is permitted.
- On rebuilt/native-vector cards, junctions must share coordinates or overlap continuously by design; do not rely on antialiasing to make two separate paths look connected.
- The Builder must inventory every cul-de-sac/stub/branch with `parent_road`, `junction_point`, `stem_connected_to_parent`, `bulb_connected_to_stem`, and `junction_gap_px` measured on the exact final PDF. Passing requires all required booleans true and `junction_gap_px == 0` at 1x/72 dpi.
- The critic must independently inspect every such junction at actual size and 4x. Any disconnected or ambiguous junction is a hard geography/linework failure.

### C. No label may overlap any road — including curved roads beneath rotated text
- The zero-road-overlap rule applies to the full transformed glyph shapes after rotation/curvature, not just an axis-aligned text box or the assigned-road midpoint.
- The Builder/critic must inspect the complete glyph envelope against **all** road strokes at the exact rendered transform. Any glyph touching, crossing, straddling, underlining, or sitting on a road is a hard failure.
- A label that follows its own road correctly but clips an unrelated road still fails.

### D. Leader/callout must be one clean connected object
- The label block and its leader are one visual object. The leader tail must originate at the label edge or within **0–2 px** at 1x/72 dpi; a larger visible gap is a detached/floating leader.
- The shaft must be a clean deliberate straight or gently bent route with no unnecessary elbows, no glyph crossings, no unrelated-road crossings, and no arrow knot with adjacent callouts.
- The shaft must connect continuously into a **filled triangular arrowhead**. No gap is allowed between shaft and arrowhead.
- The arrowhead tip must land on the exact named street stem/run; do not point vaguely near the road, to a bulb when a stem is available, or to another feature.
- Builder evidence for each callout must include `tail_gap_px`, `shaft_arrowhead_connected`, `target_street`, `target_segment_id`, `tip_on_target_stem`, `crossed_glyph_count`, `crossed_unrelated_road_count`, and `callout_cleanly_connected`. Passing requires tail gap 0–2 px, all counts zero, and all booleans true.
- The critic must independently inspect the label-to-tail connection and shaft-to-arrowhead connection at 4x. Any floating/detached/misconnected callout is `FIX_REQUIRED` and caps labels/family/overall at 8.0.

### E. Mandatory pre-delivery critic inventory
Before any card may score above 9.0, the exact final PDF critic must explicitly reconcile all four inventories below. Missing inventory is itself a failure:
1. `road_following_review` — every label on a curved/changing-direction road, with whole-label follow status.
2. `culdesac_branch_topology_review` — every cul-de-sac/stub/branch, with parent/stem/bulb continuity and zero-gap status.
3. `all_road_label_collision_review` — every street label against every road stroke, with zero contact/overlap.
4. `leader_attachment_review` — every callout, with tail gap, shaft/head continuity, exact target, and crossing counts.

A card cannot pass because a prior critic score was high, because most labels are correct, or because the defect is small. **One failed item reopens the artifact and requires repair plus a completely fresh review of the new PDF hash.** None of these rules is optional.

## 2026-09-19 Territory 312A regression - close road-following + professional road rendering

Territory 312A prior candidate SHA-256 `68e9ae154a815664499fb5ae5ef64bfd05c77f172977de64395ba51aa79c6215` is a permanent **negative** regression example. The user rejected it because the `Bedford Square Dr` label was visibly too far from its assigned street and remained straight instead of following the road's bend, while the enlarged road drawing still looked rough/unprofessional.

### F. Distance-band compliance is necessary but not sufficient
- A direct/curved label that technically falls inside a numeric 2-15 px band still fails when it visibly floats relative to its street.
- On a curved road, inspect start, middle, and end/suffix. The label must visually hug the road throughout the complete phrase. A detached average-tangent placement, or a straight phrase through a visible bend, is `FIX_REQUIRED`.
- The Builder must record `whole_label_visual_hug_passed`, `start_gap_px`, `mid_gap_px`, `end_gap_px`, and `curve_following_passed`. The critic must independently confirm them on actual-size and 4x evidence.

### G. Enlarged raster road tracing is not professional linework
- A raster source may preserve assignment/topology, but enlarging its stair-steps/wobbles into the finished card is not an acceptable rebuild.
- When authorized to redraw/clean a legacy road network, preserve topology, junctions, relative geometry and work assignment while recreating the roads with smooth antialiased/vector-quality curves, consistent stroke width, clean caps/joins, and no jagged pixel remnants.
- Professional-road review is visual as well as deterministic. `road_line_quality_review` must explicitly include `jagged_raster_remnants: 0`, `visible_stair_steps: 0`, `curve_smoothness_passed: true`, `stroke_consistency_passed: true`, and `professional_line_quality_passed: true`.
- A technically connected but visibly rough road drawing cannot score above 8.0 for linework/family/overall until repaired.

