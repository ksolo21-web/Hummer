#!/usr/bin/env bash
set -euo pipefail

fail=0
note() { printf '[toolchain] %s\n' "$*"; }
err() { printf '[toolchain][FAIL] %s\n' "$*" >&2; fail=1; }
pass() { printf '[toolchain][PASS] %s\n' "$*"; }

REQUIRED_GRADLE='9.6.0'
REQUIRED_PLATFORM_API='37'
REQUIRED_PLATFORM_CANDIDATES=('android-37' 'android-37.0')
REQUIRED_BUILD_TOOLS='36.0.0'
MIN_JAVA=17

if command -v java >/dev/null 2>&1; then
  java_line="$(java -version 2>&1 | head -n1)"
  java_major="$(printf '%s' "$java_line" | sed -E 's/.*version "([0-9]+).*/\1/')"
  if [[ "$java_major" =~ ^[0-9]+$ ]] && (( java_major >= MIN_JAVA )); then
    pass "Java runtime $java_major (minimum $MIN_JAVA)"
  else
    err "Java runtime must be >= $MIN_JAVA; found: $java_line"
  fi
else
  err 'java command not found'
fi

if command -v gradle >/dev/null 2>&1; then
  gradle_version="$(gradle --version | awk '/^Gradle /{print $2; exit}')"
  if [[ "$gradle_version" == "$REQUIRED_GRADLE" ]]; then
    pass "Gradle $gradle_version"
  else
    err "Gradle must be exactly $REQUIRED_GRADLE for the pinned build; found ${gradle_version:-unknown}"
  fi
else
  err "Gradle $REQUIRED_GRADLE not installed"
fi

sdk_root="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$sdk_root" ]]; then
  err 'ANDROID_HOME/ANDROID_SDK_ROOT not set'
elif [[ ! -d "$sdk_root" ]]; then
  err "Android SDK root does not exist: $sdk_root"
else
  pass "Android SDK root: $sdk_root"
  platform_found=''
  for platform_dir in "${REQUIRED_PLATFORM_CANDIDATES[@]}"; do
    if [[ -f "$sdk_root/platforms/$platform_dir/android.jar" ]]; then
      platform_found="$platform_dir"
      break
    fi
  done
  if [[ -n "$platform_found" ]]; then
    pass "SDK API $REQUIRED_PLATFORM_API platform ($platform_found)"
  else
    err "Missing SDK API $REQUIRED_PLATFORM_API platform (expected android-37 or android-37.0)"
  fi
  [[ -d "$sdk_root/build-tools/$REQUIRED_BUILD_TOOLS" ]] && pass "Build Tools $REQUIRED_BUILD_TOOLS" || err "Missing Build Tools $REQUIRED_BUILD_TOOLS"
fi

# Static pin checks make drift visible before Gradle starts.
grep -Fq 'id("com.android.application") version "9.4.0" apply false' build.gradle.kts \
  && pass 'AGP pin 9.4.0' || err 'AGP 9.4.0 pin missing'
grep -Fq 'compileSdk = 37' app/build.gradle.kts \
  && pass 'compileSdk 37 pin' || err 'compileSdk 37 pin missing'
grep -Fq 'targetSdk = 37' app/build.gradle.kts \
  && pass 'targetSdk 37 pin' || err 'targetSdk 37 pin missing'
grep -Fq 'sourceCompatibility = JavaVersion.VERSION_17' app/build.gradle.kts \
  && pass 'Java source target 17' || err 'Java 17 source target missing'

if (( fail != 0 )); then
  note 'Toolchain is NOT ready for a real Android Gradle build.'
  exit 2
fi
note 'Toolchain is ready for Android Gradle build.'
