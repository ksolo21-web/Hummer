package com.koenterprises.territorycardstudio.core

import java.io.File

object ProviderEndpointSwitchConfigTest {
    fun run(assets: File) {
        val switchFile = File(assets, "Provider-Endpoint-Switches.properties")
        val config = switchFile.reader(Charsets.UTF_8).use(ProviderEndpointSwitchConfigLoader::load)
        check(config.schemaVersion == 1)
        check(config.revisionSeq == 1)
        check(config.primaryEndpoints.size == 7)
        val policy = File(assets, "Online-Source-Policy.json").reader(Charsets.UTF_8).use(OnlineSourcePolicyLoader::load)
        val switched = config.applyTo(policy)
        check(switched.providers.keys == policy.providers.keys)
        policy.providers.forEach { (id, before) ->
            val after = switched.providers.getValue(id)
            check(after.tier == before.tier)
            check(after.role == before.role)
            check(after.capability == before.capability)
            check(after.layers == before.layers)
            check(after.requiresApiKey == before.requiresApiKey)
        }

        val original = switchFile.readText(Charsets.UTF_8)
        fun mustFail(from: String, to: String) {
            val mutated = original.replaceFirst(from, to)
            check(mutated != original)
            check(runCatching { ProviderEndpointSwitchConfigLoader.load(mutated.reader()) }.isFailure)
        }
        mustFail("schema_version=1", "schema_version=2")
        mustFail("revision_seq=1", "revision_seq=0")
        mustFail("base_policy_revision=2026-09-24-live-verification-v1", "base_policy_revision=other")
        mustFail("https://overpass-api.de/api/interpreter", "http://overpass-api.de/api/interpreter")
        mustFail("https://overpass-api.de/api/interpreter", "https://localhost/api/interpreter")
        mustFail("https://overpass-api.de/api/interpreter", "https://192.168.1.5/api/interpreter")
        mustFail("google_roads.primary=https://roads.googleapis.com/v1/nearestRoads", "google_roads.primary=https://roads.googleapis.com/v1/nearestRoads\nextra.role=authority")
    }
}
