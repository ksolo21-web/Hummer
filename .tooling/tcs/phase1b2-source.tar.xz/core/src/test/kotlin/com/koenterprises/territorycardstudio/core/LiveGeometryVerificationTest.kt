package com.koenterprises.territorycardstudio.core

import java.io.File
import java.security.MessageDigest

object LiveGeometryVerificationTest {
    fun run(kb: TerritoryKnowledgeBase, assets: File) {
        val policyFile = File(assets, "Online-Source-Policy.json")
        val policyText = policyFile.readText(Charsets.UTF_8)
        val policy = policyText.reader().use(OnlineSourcePolicyLoader::load)
        check(policy.schemaVersion == 1)
        check(policy.revision == "2026-09-24-live-verification-v1")
        check(policy.releasePolicy.minimumIndependentGeometrySources == 2)
        check(policy.providers.size == 7)

        fun mutationMustFail(old: String, replacement: String, label: String) {
            val mutated = policyText.replaceFirst(old, replacement)
            check(mutated != policyText) { "Online-source mutation fixture not found: $label" }
            check(runCatching { OnlineSourcePolicyLoader.load(mutated.reader()) }.isFailure) {
                "Online-source policy mutation unexpectedly accepted: $label"
            }
        }
        mutationMustFail("\"schema_version\": 1", "\"schema_version\": 2", "schema version")
        mutationMustFail(
            "\"revision\": \"2026-09-24-live-verification-v1\"",
            "\"revision\": \"2026-09-24-live-verification-v2\"",
            "revision"
        )
        mutationMustFail(
            "\"minimum_independent_geometry_sources\": 2",
            "\"minimum_independent_geometry_sources\": 1",
            "independent source minimum"
        )
        mutationMustFail(
            "\"oakland_county_primary_when_applicable\": true",
            "\"oakland_county_primary_when_applicable\": false",
            "Oakland primary"
        )
        mutationMustFail(
            "\"google_is_crosscheck_not_geometry_authority\": true",
            "\"google_is_crosscheck_not_geometry_authority\": false",
            "Google authority"
        )
        mutationMustFail(
            "\"google_map_tiles_scraping_or_machine_extraction\": false",
            "\"google_map_tiles_scraping_or_machine_extraction\": true",
            "Google tile scraping"
        )
        mutationMustFail(
            "\"source_disagreement_behavior\": \"BLOCK\"",
            "\"source_disagreement_behavior\": \"ALLOW\"",
            "source disagreement"
        )
        mutationMustFail(
            "\"provider_unavailable_behavior_when_required\": \"BLOCK\"",
            "\"provider_unavailable_behavior_when_required\": \"ALLOW\"",
            "required-provider unavailable behavior"
        )

        val jurisdiction = VerificationJurisdiction("Oakland County", "Michigan", "United States")
        check(jurisdiction.oaklandCountyMichiganApplicable)
        check(!VerificationJurisdiction("Wayne County", "Michigan", "United States").oaklandCountyMichiganApplicable)

        val ordinary = kb.assignments.getValue("263")
        val ordinaryTopology = requireNotNull(ordinary.topologySignature)
        val ordinarySourceTruth = sourceTruth(ordinary)
        val ordinaryRequest = LiveGeometryVerificationRequestFactory.create(
            kb = kb,
            policy = policy,
            displayId = ordinary.displayId,
            candidateSourceSha256 = sha256("candidate-263-v1"),
            candidateTopology = ordinaryTopology,
            candidateBuildingMemberIds = emptyList(),
            sourceTruth = ordinarySourceTruth,
            jurisdiction = jurisdiction
        )
        val ordinaryRequestAgain = LiveGeometryVerificationRequestFactory.create(
            kb = kb,
            policy = policy,
            displayId = ordinary.displayId,
            candidateSourceSha256 = sha256("candidate-263-v1"),
            candidateTopology = ordinaryTopology,
            candidateBuildingMemberIds = emptyList(),
            sourceTruth = ordinarySourceTruth,
            jurisdiction = jurisdiction
        )
        check(ordinaryRequest.requestFingerprint == ordinaryRequestAgain.requestFingerprint) {
            "Verification request fingerprint is not deterministic"
        }
        check(ordinaryRequest.roadTargets.size == ordinaryTopology.junctionBoundedSegments.size)
        check(!ordinaryRequest.siteAddressCrosscheckRequired)
        check(!ordinaryRequest.buildingOutlineCrosscheckRequired)
        check(LiveGeometryVerificationRequestFactory.fingerprintMatches(ordinaryRequest))
        val tamperedRequest = ordinaryRequest.copy(housingType = "tampered")
        check(!LiveGeometryVerificationRequestFactory.fingerprintMatches(tamperedRequest))
        val tamperedDecision = LiveGeometryVerificationReconciler.reconcile(tamperedRequest, policy, emptyList())
        check(!tamperedDecision.renderable)
        check(tamperedDecision.independentGeometrySourceCount == 0)
        check(tamperedDecision.blockedReasons.any { "fingerprint does not match request contents" in it })

        check(runCatching {
            LiveGeometryVerificationRequestFactory.create(
                kb = kb,
                policy = policy,
                displayId = ordinary.displayId,
                candidateSourceSha256 = sha256("candidate-263-v1"),
                candidateTopology = ordinaryTopology,
                candidateBuildingMemberIds = emptyList(),
                sourceTruth = ordinarySourceTruth,
                jurisdiction = jurisdiction,
                intent = CandidateBuildIntent.EXACT_APPROVED_PASSTHROUGH
            )
        }.isFailure) { "Exact approved passthrough unexpectedly entered the live-GIS rebuild pipeline" }

        val allOrdinaryTargets = ordinaryRequest.roadTargets.mapTo(linkedSetOf()) { it.targetId }
        val cleanRoadEvidence = listOf(
            roadEvidence("oakland_county_roads", ordinaryRequest, allOrdinaryTargets),
            roadEvidence("census_tigerweb_transportation", ordinaryRequest, allOrdinaryTargets)
        )
        val cleanDecision = LiveGeometryVerificationReconciler.reconcile(ordinaryRequest, policy, cleanRoadEvidence)
        check(cleanDecision.renderable)
        check(cleanDecision.disposition == LiveVerificationDisposition.RENDERABLE_VERIFIED)
        check(cleanDecision.independentGeometrySourceCount == 2)
        check(cleanDecision.qualifyingGeometryProviders == listOf("census_tigerweb_transportation", "oakland_county_roads"))
        check(cleanDecision.oaklandPrimarySatisfied)
        check(cleanDecision.sourceTruthPassed)
        check(cleanDecision.providerAgreementPassed)
        check(cleanDecision.assignmentAuthorityPreserved)
        check(cleanDecision.blockedReasons.isEmpty())
        check(cleanDecision.siteAddressCrosscheckPassed == null)
        check(cleanDecision.buildingOutlineCrosscheckPassed == null)

        val noOaklandDecision = LiveGeometryVerificationReconciler.reconcile(
            ordinaryRequest,
            policy,
            listOf(
                roadEvidence("census_tigerweb_transportation", ordinaryRequest, allOrdinaryTargets),
                roadEvidence("openstreetmap_overpass", ordinaryRequest, allOrdinaryTargets)
            )
        )
        check(!noOaklandDecision.renderable)
        check(noOaklandDecision.independentGeometrySourceCount == 2)
        check(noOaklandDecision.blockedReasons.any { "Oakland County road GIS is required" in it })

        val wrongFingerprint = sha256("wrong-request")
        val wrongFingerprintDecision = LiveGeometryVerificationReconciler.reconcile(
            ordinaryRequest,
            policy,
            listOf(
                roadEvidence("oakland_county_roads", ordinaryRequest, allOrdinaryTargets),
                roadEvidence(
                    "census_tigerweb_transportation",
                    ordinaryRequest,
                    allOrdinaryTargets,
                    requestFingerprint = wrongFingerprint
                )
            )
        )
        check(!wrongFingerprintDecision.renderable)
        check(wrongFingerprintDecision.independentGeometrySourceCount == 1) {
            "Wrong-request provider evidence was counted as qualifying geometry"
        }
        check(wrongFingerprintDecision.blockedReasons.any { "different verification request" in it })
        check("census_tigerweb_transportation" !in wrongFingerprintDecision.providerEvidenceDigests)

        val googleCannotSubstituteDecision = LiveGeometryVerificationReconciler.reconcile(
            ordinaryRequest,
            policy,
            listOf(
                roadEvidence("oakland_county_roads", ordinaryRequest, allOrdinaryTargets),
                roadEvidence("google_geocoding", ordinaryRequest, allOrdinaryTargets),
                roadEvidence("google_roads", ordinaryRequest, allOrdinaryTargets)
            )
        )
        check(!googleCannotSubstituteDecision.renderable)
        check(googleCannotSubstituteDecision.independentGeometrySourceCount == 1) {
            "Optional Google crosschecks were incorrectly counted as independent geometry authorities"
        }
        check(googleCannotSubstituteDecision.blockedReasons.any { "independent road-geometry confirmations=1" in it })

        val firstTarget = allOrdinaryTargets.first()
        val disagreementDecision = LiveGeometryVerificationReconciler.reconcile(
            ordinaryRequest,
            policy,
            listOf(
                roadEvidence("oakland_county_roads", ordinaryRequest, allOrdinaryTargets),
                roadEvidence(
                    "census_tigerweb_transportation",
                    ordinaryRequest,
                    allOrdinaryTargets,
                    confirmedTargetIds = allOrdinaryTargets - firstTarget,
                    conflictingTargetIds = setOf(firstTarget)
                ),
                roadEvidence("openstreetmap_overpass", ordinaryRequest, allOrdinaryTargets)
            )
        )
        check(!disagreementDecision.renderable)
        check(!disagreementDecision.providerAgreementPassed)
        check(disagreementDecision.blockedReasons.any { "conflicting road topology" in it })

        val meaningChangeDecision = LiveGeometryVerificationReconciler.reconcile(
            ordinaryRequest,
            policy,
            listOf(
                roadEvidence("oakland_county_roads", ordinaryRequest, allOrdinaryTargets),
                roadEvidence(
                    "census_tigerweb_transportation",
                    ordinaryRequest,
                    allOrdinaryTargets,
                    unknownMeaningChangingRoads = setOf("invented connector road")
                ),
                roadEvidence("openstreetmap_overpass", ordinaryRequest, allOrdinaryTargets)
            )
        )
        check(!meaningChangeDecision.renderable)
        check(!meaningChangeDecision.assignmentAuthorityPreserved)
        check(meaningChangeDecision.blockedReasons.any { "unknown meaning-changing roads" in it })

        val contaminatedRequest = ordinaryRequest.copy(
            sourceTruth = ordinaryRequest.sourceTruth.copy(crossTerritoryInferenceUsed = true)
        )
        val contaminatedDecision = LiveGeometryVerificationReconciler.reconcile(
            contaminatedRequest,
            policy,
            cleanRoadEvidence
        )
        check(!contaminatedDecision.renderable)
        check(!contaminatedDecision.sourceTruthPassed)
        check(!contaminatedDecision.assignmentAuthorityPreserved)
        check(contaminatedDecision.blockedReasons.any { "cross-territory geography inference" in it })

        val duplicateProviderDecision = LiveGeometryVerificationReconciler.reconcile(
            ordinaryRequest,
            policy,
            listOf(
                roadEvidence("oakland_county_roads", ordinaryRequest, allOrdinaryTargets),
                roadEvidence("census_tigerweb_transportation", ordinaryRequest, allOrdinaryTargets),
                roadEvidence("census_tigerweb_transportation", ordinaryRequest, allOrdinaryTargets, responseSalt = "duplicate")
            )
        )
        check(!duplicateProviderDecision.renderable)
        check(duplicateProviderDecision.independentGeometrySourceCount == 1) {
            "Duplicate provider evidence was allowed to satisfy independent-source count"
        }
        check(duplicateProviderDecision.blockedReasons.any { "duplicate provider evidence" in it })

        val roleContamination = ProviderVerificationEvidence(
            providerId = "oakland_county_site_addresses",
            requestFingerprint = ordinaryRequest.requestFingerprint,
            available = true,
            observedAtUtc = "2026-09-25T09:00:00Z",
            responseSha256 = sha256("site-role-contamination"),
            sourceDataVintage = null,
            queriedTargetIds = allOrdinaryTargets,
            confirmedTargetIds = allOrdinaryTargets,
            notFoundTargetIds = emptySet(),
            conflictingTargetIds = emptySet(),
            unknownMeaningChangingRoads = emptySet(),
            siteAddressCrosscheckPassed = true,
            buildingOutlineCrosscheckPassed = null,
            errorCode = null
        )
        val roleContaminationDecision = LiveGeometryVerificationReconciler.reconcile(
            ordinaryRequest,
            policy,
            cleanRoadEvidence + roleContamination
        )
        check(!roleContaminationDecision.renderable)
        check(roleContaminationDecision.blockedReasons.any { "outside its site-address role" in it })

        check(runCatching {
            ProviderVerificationEvidence(
                providerId = "census_tigerweb_transportation",
                requestFingerprint = ordinaryRequest.requestFingerprint,
                available = false,
                observedAtUtc = null,
                responseSha256 = null,
                sourceDataVintage = null,
                queriedTargetIds = allOrdinaryTargets,
                confirmedTargetIds = emptySet(),
                notFoundTargetIds = emptySet(),
                conflictingTargetIds = emptySet(),
                unknownMeaningChangingRoads = setOf("should-not-exist"),
                siteAddressCrosscheckPassed = null,
                buildingOutlineCrosscheckPassed = null,
                errorCode = "NETWORK_UNAVAILABLE"
            )
        }.isFailure) { "Unavailable evidence unexpectedly asserted unknown roads" }

        val apartment = kb.assignments.getValue("A300a")
        val apartmentTopology = requireNotNull(apartment.topologySignature)
        val apartmentMembers = requireNotNull(apartment.assignmentSignature).buildingMemberIds
        check(apartmentMembers.isNotEmpty())
        val apartmentRequest = LiveGeometryVerificationRequestFactory.create(
            kb = kb,
            policy = policy,
            displayId = apartment.displayId,
            candidateSourceSha256 = sha256("candidate-a300a-v1"),
            candidateTopology = apartmentTopology,
            candidateBuildingMemberIds = apartmentMembers,
            sourceTruth = sourceTruth(apartment),
            jurisdiction = jurisdiction
        )
        check(apartmentRequest.siteAddressCrosscheckRequired)
        check(apartmentRequest.buildingOutlineCrosscheckRequired)
        val apartmentTargets = apartmentRequest.roadTargets.mapTo(linkedSetOf()) { it.targetId }
        val apartmentEvidence = listOf(
            roadEvidence("oakland_county_roads", apartmentRequest, apartmentTargets),
            roadEvidence("census_tigerweb_transportation", apartmentRequest, apartmentTargets),
            crosscheckEvidence("oakland_county_site_addresses", apartmentRequest, sitePassed = true),
            crosscheckEvidence("oakland_county_buildings", apartmentRequest, buildingPassed = true)
        )
        val apartmentDecision = LiveGeometryVerificationReconciler.reconcile(apartmentRequest, policy, apartmentEvidence)
        check(apartmentDecision.renderable)
        check(apartmentDecision.siteAddressCrosscheckPassed == true)
        check(apartmentDecision.buildingOutlineCrosscheckPassed == true)
        check(apartmentDecision.providerDataVintages["oakland_county_buildings"] == "fixture building-source vintage")
        check(apartmentDecision.providerObservedAtUtc.keys.containsAll(setOf(
            "oakland_county_roads",
            "census_tigerweb_transportation",
            "oakland_county_site_addresses",
            "oakland_county_buildings"
        )))

        val missingVintageEvidence = apartmentEvidence.map { item ->
            if (item.providerId == "oakland_county_buildings") item.copy(sourceDataVintage = null) else item
        }
        val missingVintageDecision = LiveGeometryVerificationReconciler.reconcile(apartmentRequest, policy, missingVintageEvidence)
        check(!missingVintageDecision.renderable)
        check(missingVintageDecision.blockedReasons.any { "vintage" in it })

        val missingBuildingDecision = LiveGeometryVerificationReconciler.reconcile(
            apartmentRequest,
            policy,
            apartmentEvidence.filterNot { it.providerId == "oakland_county_buildings" }
        )
        check(!missingBuildingDecision.renderable)
        check(missingBuildingDecision.buildingOutlineCrosscheckPassed == false)
        check(missingBuildingDecision.blockedReasons.any { "required for building-outline verification" in it })

        check(runCatching {
            LiveGeometryVerificationRequestFactory.create(
                kb = kb,
                policy = policy,
                displayId = apartment.displayId,
                candidateSourceSha256 = sha256("candidate-a300a-empty-buildings"),
                candidateTopology = apartmentTopology,
                candidateBuildingMemberIds = emptyList(),
                sourceTruth = sourceTruth(apartment),
                jurisdiction = jurisdiction
            )
        }.isFailure) { "Multi-unit verification request unexpectedly accepted an empty building/site inventory" }
    }

    private fun sourceTruth(assignment: KnowledgeBaseAssignment): CandidateSourceTruthState =
        CandidateSourceTruthState(
            sourceTerritoryDisplayId = assignment.displayId,
            assignmentAuthoritySourceSha256 = assignment.sourceHashes.first(),
            lockedAssignmentReconciled = true,
            missingExpectedSegmentCount = 0,
            unexpectedMeaningChangingSegmentCount = 0,
            assignmentColorConflictCount = 0,
            unresolvedPerimeterWorkedSideCount = 0,
            illegalMidSegmentColorTransitionCount = 0,
            unresolvedBuildingSiteCount = 0,
            crossTerritoryInferenceUsed = false,
            styleOnlyGeographyUsed = false
        )

    private fun roadEvidence(
        providerId: String,
        request: LiveGeometryVerificationRequest,
        queriedTargetIds: Set<String>,
        confirmedTargetIds: Set<String> = queriedTargetIds,
        notFoundTargetIds: Set<String> = emptySet(),
        conflictingTargetIds: Set<String> = emptySet(),
        unknownMeaningChangingRoads: Set<String> = emptySet(),
        requestFingerprint: String = request.requestFingerprint,
        responseSalt: String = providerId
    ): ProviderVerificationEvidence = ProviderVerificationEvidence(
        providerId = providerId,
        requestFingerprint = requestFingerprint,
        available = true,
        observedAtUtc = "2026-09-25T09:00:00Z",
        responseSha256 = sha256("$providerId|$responseSalt|${request.requestFingerprint}"),
        sourceDataVintage = null,
        queriedTargetIds = queriedTargetIds,
        confirmedTargetIds = confirmedTargetIds,
        notFoundTargetIds = notFoundTargetIds,
        conflictingTargetIds = conflictingTargetIds,
        unknownMeaningChangingRoads = unknownMeaningChangingRoads,
        siteAddressCrosscheckPassed = null,
        buildingOutlineCrosscheckPassed = null,
        errorCode = null
    )

    private fun crosscheckEvidence(
        providerId: String,
        request: LiveGeometryVerificationRequest,
        sitePassed: Boolean? = null,
        buildingPassed: Boolean? = null
    ): ProviderVerificationEvidence = ProviderVerificationEvidence(
        providerId = providerId,
        requestFingerprint = request.requestFingerprint,
        available = true,
        observedAtUtc = "2026-09-25T09:00:00Z",
        responseSha256 = sha256("$providerId|${request.requestFingerprint}"),
        sourceDataVintage = if (providerId == "oakland_county_buildings") "fixture building-source vintage" else null,
        queriedTargetIds = emptySet(),
        confirmedTargetIds = emptySet(),
        notFoundTargetIds = emptySet(),
        conflictingTargetIds = emptySet(),
        unknownMeaningChangingRoads = emptySet(),
        siteAddressCrosscheckPassed = sitePassed,
        buildingOutlineCrosscheckPassed = buildingPassed,
        errorCode = null
    )

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
