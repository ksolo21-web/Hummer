package com.koenterprises.territorycardstudio.core

object BuildingValidationEngineTest {
    fun run(kb: TerritoryKnowledgeBase) {
        frozenCorpusParity(kb)
        distinctFootprintsPass()
        touchingUnattachedFails()
        touchingAttachedGroupPasses()
        missingInteriorLabelFails()
        multiMemberOneFootprintPasses()
        memberBindingFailsClosed()
        duplicateMemberBindingFails()
        labelOutsideFootprintFails()
        invalidPolygonFails()
        mobileHomePasses()
        ordinaryResidentialIsNotApplicable(kb)
    }

    private fun frozenCorpusParity(kb: TerritoryKnowledgeBase) {
        var locked = 0
        var reaudit = 0
        var notApplicable = 0
        var needsNew = 0
        kb.assignments.values.forEach { assignment ->
            if (assignment.needsNewCard) {
                needsNew++
                val status = ReleasePolicy.evaluate(
                    AssignmentStatus(
                        displayId = assignment.displayId,
                        status = assignment.status,
                        roadAssignmentStatus = assignment.roadAssignmentStatus,
                        buildingAssignmentStatus = assignment.buildingAssignmentStatus,
                        needsNewCard = true,
                        canonicalFilename = assignment.canonicalFilename,
                        referenceFile = assignment.referenceFile
                    )
                )
                check(!status.fieldReleaseAllowed) { "${assignment.displayId} legacy reference must never be field releasable" }
                return@forEach
            }
            val report = BuildingValidationEngine.validateAssignment(assignment)
            when (assignment.buildingAssignmentStatus) {
                "locked_300_301" -> {
                    locked++
                    check(report.applicable && report.passed) {
                        "${assignment.displayId} locked 300/301 assignment failed recomputation: ${report.failures}"
                    }
                    check(report.failures.isEmpty())
                }
                "needs_300_301_reaudit" -> {
                    reaudit++
                    check(report.applicable && !report.passed) {
                        "${assignment.displayId} re-audit assignment unexpectedly passed"
                    }
                    check(report.failures == assignment.buildingReauditFailures) {
                        "${assignment.displayId} frozen building failure parity drift:\nrecomputed=${report.failures}\nfrozen=${assignment.buildingReauditFailures}"
                    }
                }
                "not_applicable" -> {
                    notApplicable++
                    check(!report.applicable && report.passed && report.failures.isEmpty())
                }
                else -> error("Unexpected building status ${assignment.buildingAssignmentStatus}")
            }
        }
        check(locked == 23) { "Expected 23 locked 300/301 assignments, got $locked" }
        check(reaudit == 43) { "Expected 43 current building re-audits, got $reaudit" }
        check(notApplicable == 153) { "Expected 153 current not-applicable assignments, got $notApplicable" }
        check(needsNew == 6) { "Expected 6 needs-new-card legacy assignments, got $needsNew" }
    }

    private fun building(
        id: String,
        x0: Double,
        y0: Double,
        x1: Double,
        y1: Double,
        label: String,
        assigned: Boolean = true,
        attachedGroup: String = "",
        members: List<String> = listOf(label),
        items: List<BuildingLabelItem> = listOf(BuildingLabelItem(label, Point2D((x0 + x1) / 2, (y0 + y1) / 2), null, 0.0, 7.5))
    ) = BuildingGeometry(
        buildingId = id,
        label = label,
        housingType = "apartment",
        assigned = assigned,
        attachedGroup = attachedGroup,
        sourceMembers = members,
        labelItems = items,
        polygon = listOf(Point2D(x0, y0), Point2D(x1, y0), Point2D(x1, y1), Point2D(x0, y1))
    )

    private fun distinctFootprintsPass() {
        val report = BuildingValidationEngine.validateBuildings(
            listOf(building("b1", 0.0, 0.0, 40.0, 20.0, "101"), building("b2", 50.0, 0.0, 90.0, 20.0, "103"))
        )
        check(report.passed) { report.failures.toString() }
    }

    private fun touchingUnattachedFails() {
        val report = BuildingValidationEngine.validateBuildings(
            listOf(building("b1", 0.0, 0.0, 40.0, 20.0, "101"), building("b2", 40.0, 0.0, 80.0, 20.0, "103"))
        )
        check(!report.passed)
        check(report.failures.any { it == "b1/b2: separate buildings touch or overlap" })
    }

    private fun touchingAttachedGroupPasses() {
        val report = BuildingValidationEngine.validateBuildings(
            listOf(
                building("b1", 0.0, 0.0, 40.0, 20.0, "101", attachedGroup = "g1"),
                building("b2", 40.0, 0.0, 80.0, 20.0, "103", attachedGroup = "g1")
            )
        )
        check(report.passed) { report.failures.toString() }
    }

    private fun missingInteriorLabelFails() {
        val report = BuildingValidationEngine.validateBuildings(
            listOf(building("b1", 0.0, 0.0, 40.0, 20.0, "", members = emptyList(), items = emptyList()))
        )
        check(!report.passed)
        check(report.failures.contains("b1: assigned footprint requires an inside label"))
        check(report.failures.contains("b1: assigned footprint has no verified interior building/site label"))
    }

    private fun multiMemberOneFootprintPasses() {
        val items = listOf(
            BuildingLabelItem("407", Point2D(15.0, 10.0), null, 0.0, 7.5),
            BuildingLabelItem("409", Point2D(45.0, 10.0), null, 0.0, 7.5)
        )
        val report = BuildingValidationEngine.validateBuildings(
            listOf(building("b1", 0.0, 0.0, 60.0, 20.0, "407–409", members = listOf("407", "409"), items = items))
        )
        check(report.passed) { report.failures.toString() }
        check(report.buildingCount == 1 && report.memberLabelCount == 2)
    }

    private fun memberBindingFailsClosed() {
        val item = BuildingLabelItem("101", Point2D(20.0, 10.0), null, 0.0, 7.5)
        val report = BuildingValidationEngine.validateBuildings(
            listOf(building("b1", 0.0, 0.0, 40.0, 20.0, "101–103", members = listOf("101", "103"), items = listOf(item)))
        )
        check(!report.passed)
        check(report.failures.any { "member labels missing" in it })
    }

    private fun duplicateMemberBindingFails() {
        val items = listOf(
            BuildingLabelItem("101", Point2D(15.0, 10.0), null, 0.0, 7.5),
            BuildingLabelItem("101", Point2D(25.0, 10.0), null, 0.0, 7.5)
        )
        val report = BuildingValidationEngine.validateBuildings(
            listOf(building("b1", 0.0, 0.0, 40.0, 20.0, "101", members = listOf("101"), items = items))
        )
        check(!report.passed)
        check(report.failures.contains("b1: duplicate member label binding"))
    }

    private fun labelOutsideFootprintFails() {
        val item = BuildingLabelItem("101", Point2D(60.0, 10.0), null, 0.0, 7.5)
        val report = BuildingValidationEngine.validateBuildings(
            listOf(building("b1", 0.0, 0.0, 40.0, 20.0, "101", items = listOf(item)))
        )
        check(!report.passed)
        check(report.failures.any { "not fully inside its footprint" in it })
    }

    private fun invalidPolygonFails() {
        val bad = BuildingGeometry(
            buildingId = "bowtie",
            label = "101",
            housingType = "apartment",
            assigned = true,
            attachedGroup = "",
            sourceMembers = listOf("101"),
            labelItems = listOf(BuildingLabelItem("101", Point2D(10.0, 10.0), null, 0.0, 7.5)),
            polygon = listOf(Point2D(0.0, 0.0), Point2D(20.0, 20.0), Point2D(0.0, 20.0), Point2D(20.0, 0.0))
        )
        val report = BuildingValidationEngine.validateBuildings(listOf(bad))
        check(!report.passed)
        check(report.failures.contains("bowtie: invalid/zero-area footprint"))
    }

    private fun mobileHomePasses() {
        val b = building("m1", 0.0, 0.0, 30.0, 18.0, "27").copy(housingType = "mobile_home")
        val report = BuildingValidationEngine.validateBuildings(listOf(b))
        check(report.passed) { report.failures.toString() }
    }

    private fun ordinaryResidentialIsNotApplicable(kb: TerritoryKnowledgeBase) {
        val ordinary = kb.assignments.values.first { it.buildingAssignmentStatus == "not_applicable" && it.buildings.isNotEmpty() }
        val report = BuildingValidationEngine.validateAssignment(ordinary)
        check(!report.applicable && report.passed)
    }
}
