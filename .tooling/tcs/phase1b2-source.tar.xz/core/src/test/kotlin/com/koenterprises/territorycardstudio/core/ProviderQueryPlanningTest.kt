package com.koenterprises.territorycardstudio.core

import java.io.File
import java.security.MessageDigest

object ProviderQueryPlanningTest {
    fun run(kb: TerritoryKnowledgeBase, assets: File) {
        val policy = File(assets, "Online-Source-Policy.json").reader(Charsets.UTF_8).use(OnlineSourcePolicyLoader::load)
        val jurisdiction = VerificationJurisdiction("Oakland County", "Michigan", "United States")
        val simpleAssignment = kb.assignments.getValue("253")
        val simpleRequest = requestFor(kb, policy, simpleAssignment, jurisdiction, emptyList())
        val plans = ProviderQueryPlanner.initialPlans(simpleRequest, policy)
        check(plans.oaklandRoads != null)
        check(plans.censusRoads.size == 3)
        check(plans.censusRoads.map { it.resourceId }.toSet() == setOf("census-layer:2", "census-layer:6", "census-layer:8"))
        check(plans.oaklandSiteAddresses == null)
        val allInitial = listOfNotNull(plans.oaklandRoads) + plans.censusRoads + plans.osmAreaLookup
        check(allInitial.all(ProviderQueryPlanner::fingerprintMatches))
        check(allInitial.none { plan -> (plan.queryParameters + plan.formParameters).any { it.first.equals("key", true) } })
        check(plans.oaklandRoads.queryParameters.associate { it.first to it.second }.getValue("outSR") == "4326")
        check(plans.oaklandRoads.queryParameters.associate { it.first to it.second }.getValue("where").contains("MAIN"))
        check(!ProviderQueryPlanner.fingerprintMatches(plans.oaklandRoads.copy(resourceId = "tampered")))

        val nonOaklandRequest = requestFor(
            kb,
            policy,
            simpleAssignment,
            VerificationJurisdiction("Wayne County", "Michigan", "United States"),
            emptyList()
        )
        val nonOaklandPlans = ProviderQueryPlanner.initialPlans(nonOaklandRequest, policy)
        check(nonOaklandPlans.oaklandRoads == null) { "Oakland road source planned outside Oakland County" }
        check(nonOaklandPlans.oaklandSiteAddresses == null) { "Oakland site-address source planned outside Oakland County" }
        check(nonOaklandPlans.censusRoads.size == 3)

        val observedAt = "2026-09-25T10:30:00Z"
        val areaBody = """
            [
              {
                "place_id": 1,
                "osm_type": "relation",
                "osm_id": 180107,
                "class": "boundary",
                "type": "administrative",
                "display_name": "Oakland County, Michigan, United States",
                "address": {
                  "county": "Oakland County",
                  "state": "Michigan",
                  "country": "United States",
                  "country_code": "us"
                }
              }
            ]
        """.trimIndent()
        val areaResponse = ProviderRawResponse(plans.osmAreaLookup, areaBody, observedAt)
        val area = ProviderResponseParser.parseOsmArea(areaResponse, jurisdiction)
        check(area.areaId == 3_600_180_107L)
        val osmRoadPlan = ProviderQueryPlanner.osmRoadPlan(simpleRequest, policy, area)
        check(ProviderQueryPlanner.fingerprintMatches(osmRoadPlan))
        check(runCatching {
            val other = requestFor(kb, policy, kb.assignments.getValue("362"), jurisdiction, emptyList())
            ProviderQueryPlanner.osmRoadPlan(other, policy, area)
        }.isFailure) { "OSM area resolution was reused across verification requests" }
        check(osmRoadPlan.method == ProviderHttpMethod.POST_FORM)
        val overpassQuery = osmRoadPlan.formParameters.single { it.first == "data" }.second
        check(overpassQuery.contains("area(${area.areaId})"))
        check(overpassQuery.contains("out body geom qt"))
        check("(?:" !in overpassQuery) { "Overpass plan used non-POSIX non-capturing regex syntax" }

        val osmRoadBody = """
            {
              "version": 0.6,
              "generator": "Overpass API",
              "elements": [
                {
                  "type": "way",
                  "id": 1001,
                  "tags": {"highway": "primary", "name": "S Main St"},
                  "geometry": [
                    {"lat": 42.6800, "lon": -83.1400},
                    {"lat": 42.6810, "lon": -83.1400}
                  ]
                },
                {
                  "type": "way",
                  "id": 1002,
                  "tags": {"highway": "secondary", "name": "W University Dr"},
                  "geometry": [
                    {"lat": 42.6805, "lon": -83.1410},
                    {"lat": 42.6805, "lon": -83.1390}
                  ]
                }
              ]
            }
        """.trimIndent()
        val osmRoadResponse = ProviderRawResponse(osmRoadPlan, osmRoadBody, observedAt)
        val osmParsed = ProviderResponseParser.parseOsmRoads(areaResponse, osmRoadResponse)
        check(osmParsed.features.size == 2)
        val osmEvidence = ProviderEvidenceAssembler.roadEvidence(simpleRequest, osmParsed, observedAt)
        check(osmEvidence.confirmedTargetIds == simpleRequest.roadTargets.mapTo(linkedSetOf()) { it.targetId }) {
            "OSM did not confirm simple topology: $osmEvidence"
        }
        check(osmEvidence.responseSha256 == osmParsed.compositeResponseSha256)
        val overpassRemarkBody = osmRoadBody.replace(
            "\"elements\": [",
            "\"remark\": \"runtime error: Query timed out\", \"elements\": ["
        )
        check(runCatching {
            ProviderResponseParser.parseOsmRoads(areaResponse, ProviderRawResponse(osmRoadPlan, overpassRemarkBody, observedAt))
        }.isFailure) { "Overpass error/partial remark unexpectedly passed" }

        val oaklandRoadBody = arcGisRoadBody(
            listOf(
                ArcRoad(1, "S Main St", "Main", "St", listOf(listOf(-83.1400 to 42.6800, -83.1400 to 42.6810))),
                ArcRoad(2, "W University Dr", "University", "Dr", listOf(listOf(-83.1410 to 42.6805, -83.1390 to 42.6805)))
            )
        )
        val oaklandResponse = ProviderRawResponse(requireNotNull(plans.oaklandRoads), oaklandRoadBody, observedAt)
        val oaklandParsed = ProviderResponseParser.parseOaklandRoads(oaklandResponse)
        check(oaklandParsed.features.size == 2)
        check(oaklandParsed.compositeResponseSha256 == oaklandResponse.responseSha256)
        val oaklandEvidence = ProviderEvidenceAssembler.roadEvidence(simpleRequest, oaklandParsed, observedAt)
        check(oaklandEvidence.confirmedTargetIds == simpleRequest.roadTargets.mapTo(linkedSetOf()) { it.targetId })

        val ambiguousHomonymBody = arcGisRoadBody(
            listOf(
                ArcRoad(101, "S Main St", "Main", "St", listOf(listOf(-83.1400 to 42.6800, -83.1400 to 42.6810))),
                ArcRoad(102, "W University Dr", "University", "Dr", listOf(listOf(-83.1410 to 42.6805, -83.1390 to 42.6805))),
                ArcRoad(103, "S Main St", "Main", "St", listOf(listOf(-83.3000 to 42.8000, -83.3000 to 42.8010))),
                ArcRoad(104, "W University Dr", "University", "Dr", listOf(listOf(-83.3010 to 42.8005, -83.2990 to 42.8005)))
            )
        )
        val ambiguousHomonymEvidence = ProviderEvidenceAssembler.roadEvidence(
            simpleRequest,
            ProviderResponseParser.parseOaklandRoads(
                ProviderRawResponse(requireNotNull(plans.oaklandRoads), ambiguousHomonymBody, observedAt)
            ),
            observedAt
        )
        check(ambiguousHomonymEvidence.confirmedTargetIds.isEmpty()) {
            "County-wide same-name components were incorrectly unioned into a false topology confirmation"
        }
        check(ambiguousHomonymEvidence.conflictingTargetIds == simpleRequest.roadTargets.mapTo(linkedSetOf()) { it.targetId })

        val otherRequest = requestFor(kb, policy, kb.assignments.getValue("362"), jurisdiction, emptyList())
        check(runCatching { ProviderEvidenceAssembler.roadEvidence(otherRequest, oaklandParsed, observedAt) }.isFailure) {
            "Parsed road result was reusable across verification requests"
        }

        val censusResponses = plans.censusRoads.map { plan ->
            val body = if (plan.resourceId == "census-layer:8") {
                arcGisCensusRoadBody(
                    listOf(
                        CensusRoad(21, "S Main St", "Main", listOf(listOf(-83.1400 to 42.6800, -83.1400 to 42.6810))),
                        CensusRoad(22, "W University Dr", "University", listOf(listOf(-83.1410 to 42.6805, -83.1390 to 42.6805)))
                    )
                )
            } else arcGisCensusRoadBody(emptyList())
            ProviderRawResponse(plan, body, observedAt)
        }
        val censusParsed = ProviderResponseParser.parseCensusRoads(censusResponses)
        check(censusParsed.features.size == 2)
        val censusEvidence = ProviderEvidenceAssembler.roadEvidence(simpleRequest, censusParsed, observedAt)
        check(censusEvidence.confirmedTargetIds == simpleRequest.roadTargets.mapTo(linkedSetOf()) { it.targetId })

        val decision = LiveGeometryVerificationReconciler.reconcile(
            simpleRequest,
            policy,
            listOf(oaklandEvidence, censusEvidence, osmEvidence)
        )
        check(decision.renderable) { "Provider parser evidence failed reconciliation: ${decision.blockedReasons}" }
        check(decision.independentGeometrySourceCount == 3)

        val truncated = oaklandRoadBody.replace("\"exceededTransferLimit\": false", "\"exceededTransferLimit\": true")
        val truncatedParsed = ProviderResponseParser.parseOaklandRoads(ProviderRawResponse(requireNotNull(plans.oaklandRoads), truncated, observedAt))
        val truncatedEvidence = ProviderEvidenceAssembler.roadEvidence(simpleRequest, truncatedParsed, observedAt)
        check(!truncatedEvidence.available)
        check(truncatedEvidence.errorCode == "TRANSFER_LIMIT_EXCEEDED")
        check(truncatedEvidence.responseSha256 == truncatedParsed.compositeResponseSha256)
        check(truncatedEvidence.observedAtUtc == observedAt)

        val repeatedAssignment = kb.assignments.getValue("273")
        val repeatedRequest = requestFor(kb, policy, repeatedAssignment, jurisdiction, emptyList())
        val repeatedPlans = ProviderQueryPlanner.initialPlans(repeatedRequest, policy)
        val repeatedBody = arcGisRoadBody(
            listOf(ArcRoad(31, "Hidden Valley Dr", "Hidden Valley", "Dr", listOf(listOf(-83.15 to 42.68, -83.15 to 42.69))))
        )
        val repeatedEvidence = ProviderEvidenceAssembler.roadEvidence(
            repeatedRequest,
            ProviderResponseParser.parseOaklandRoads(ProviderRawResponse(requireNotNull(repeatedPlans.oaklandRoads), repeatedBody, observedAt)),
            observedAt
        )
        val hiddenValleyTargets = repeatedRequest.roadTargets.filter { RoadNameCanonicalizer.canonical(it.normalizedRoadName) == "hidden valley dr" }
        check(hiddenValleyTargets.size > 1)
        check(hiddenValleyTargets.filter { it.endpointANeighbors.isEmpty() && it.endpointBNeighbors.isEmpty() }
            .all { it.targetId in repeatedEvidence.conflictingTargetIds }) {
            "Repeated same-name segments without a geospatial locator were not failed closed"
        }

        val apartment = kb.assignments.getValue("A300a")
        val apartmentMembers = requireNotNull(apartment.assignmentSignature).buildingMemberIds
        val apartmentRequest = requestFor(kb, policy, apartment, jurisdiction, apartmentMembers)
        check(runCatching { requestFor(kb, policy, apartment, jurisdiction, apartmentMembers.dropLast(1)) }.isFailure) {
            "Live verification unexpectedly accepted a subset of the current locked apartment member inventory"
        }
        val needsNewMultiUnit = kb.assignments.getValue("A257")
        check(runCatching {
            requestFor(kb, policy, needsNewMultiUnit, jurisdiction, listOf("100", "102"))
        }.isFailure) {
            "Needs-new-card legacy reference unexpectedly authorized live geography"
        }
        val apartmentPlans = ProviderQueryPlanner.initialPlans(apartmentRequest, policy)
        val sitePlan = requireNotNull(apartmentPlans.oaklandSiteAddresses)
        check(sitePlan.queryParameters.associate { it.first to it.second }.getValue("where").contains("SITESTREETNUMBER"))
        val siteNumbers = listOf(401, 405, 420, 421, 418, 430, 440, 450, 460, 455, 490, 488, 490, 492, 494, 500)
        val siteBody = arcGisSiteAddressBody(siteNumbers)
        val siteParsed = ProviderResponseParser.parseSiteAddresses(ProviderRawResponse(sitePlan, siteBody, observedAt))
        val directionalSiteParsed = ProviderResponseParser.parseSiteAddresses(
            ProviderRawResponse(
                sitePlan,
                arcGisSiteAddressBody(listOf(123), prefix = "W", streetName = "University", streetType = "Dr"),
                observedAt
            )
        )
        check(directionalSiteParsed.records.single().canonicalRoadName == "w university dr") {
            "Oakland site-address directional prefix was lost during canonicalization"
        }
        val (siteEvidence, boundPinsMaybe) = ProviderEvidenceAssembler.siteAddressEvidence(apartmentRequest, siteParsed, observedAt)
        check(siteEvidence.siteAddressCrosscheckPassed == true)
        val boundPins = requireNotNull(boundPinsMaybe)
        check(boundPins.pins.isNotEmpty())
        check(boundPins.requestFingerprint == apartmentRequest.requestFingerprint)
        check(boundPins.siteResponseSha256 == siteParsed.responseSha256)

        val (buildingPlan, buildingMetadataPlan) = ProviderQueryPlanner.oaklandBuildingPlans(apartmentRequest, policy, boundPins)
        check(ProviderQueryPlanner.fingerprintMatches(buildingPlan))
        check(buildingPlan.resourceId.contains(boundPins.siteResponseSha256))
        check(runCatching {
            val otherApartment = kb.assignments.getValue("A301")
            val otherApartmentRequest = requestFor(kb, policy, otherApartment, jurisdiction, requireNotNull(otherApartment.assignmentSignature).buildingMemberIds)
            ProviderQueryPlanner.oaklandBuildingPlans(otherApartmentRequest, policy, boundPins)
        }.isFailure) { "Oakland building query accepted PINs from a different request" }
        check(ProviderQueryPlanner.fingerprintMatches(buildingMetadataPlan))
        check(buildingPlan.queryParameters.associate { it.first to it.second }.getValue("where").contains("keypin"))
        val buildingBody = arcGisBuildingBody(boundPins.pins.toList())
        val buildingParsed = ProviderResponseParser.parseBuildingOutlines(ProviderRawResponse(buildingPlan, buildingBody, observedAt))
        val metadataBody = """
            {
              "name":"Building Outline",
              "type":"Feature Layer",
              "description":"The building outline polygons were derived from the 2017 imagery by Eagleview. The data was updated on December, 2022, per ad hoc request."
            }
        """.trimIndent()
        val metadata = ProviderResponseParser.parseBuildingMetadata(ProviderRawResponse(buildingMetadataPlan, metadataBody, observedAt))
        check(metadata.sourceDataVintage.contains("2017"))
        check(metadata.sourceDataVintage.contains("2022"))
        val buildingEvidence = ProviderEvidenceAssembler.buildingOutlineEvidence(apartmentRequest, buildingParsed, metadata, boundPins, observedAt)
        check(buildingEvidence.buildingOutlineCrosscheckPassed == true)
        check(!buildingEvidence.sourceDataVintage.isNullOrBlank())

        val missingBuildingBody = arcGisBuildingBody(boundPins.pins.drop(1))
        val missingBuildingParsed = ProviderResponseParser.parseBuildingOutlines(ProviderRawResponse(buildingPlan, missingBuildingBody, observedAt))
        val missingBuildingEvidence = ProviderEvidenceAssembler.buildingOutlineEvidence(apartmentRequest, missingBuildingParsed, metadata, boundPins, observedAt)
        check(missingBuildingEvidence.buildingOutlineCrosscheckPassed == false)

        check(runCatching {
            ProviderResponseParser.parseBuildingMetadata(
                ProviderRawResponse(buildingMetadataPlan, "{\"description\":\"building outlines\"}", observedAt)
            )
        }.isFailure) { "Building metadata without vintage unexpectedly passed" }

        val ambiguousAreaBody = areaBody.dropLast(1) + "," + areaBody.substringAfter('[').trimStart()
        check(runCatching {
            ProviderResponseParser.parseOsmArea(ProviderRawResponse(plans.osmAreaLookup, ambiguousAreaBody, observedAt), jurisdiction)
        }.isFailure) { "Ambiguous OSM jurisdiction unexpectedly passed" }

        val arcError = """{"error":{"code":500,"message":"fixture failure","details":[]}}"""
        check(runCatching {
            ProviderResponseParser.parseOaklandRoads(ProviderRawResponse(requireNotNull(plans.oaklandRoads), arcError, observedAt))
        }.isFailure) { "ArcGIS error response unexpectedly parsed as road evidence" }
    }

    private fun requestFor(
        kb: TerritoryKnowledgeBase,
        policy: OnlineSourcePolicy,
        assignment: KnowledgeBaseAssignment,
        jurisdiction: VerificationJurisdiction,
        buildingMembers: List<String>
    ): LiveGeometryVerificationRequest = LiveGeometryVerificationRequestFactory.create(
        kb = kb,
        policy = policy,
        displayId = assignment.displayId,
        candidateSourceSha256 = sha256("provider-query-fixture:${assignment.displayId}"),
        candidateTopology = requireNotNull(assignment.topologySignature),
        candidateBuildingMemberIds = buildingMembers,
        sourceTruth = CandidateSourceTruthState(
            sourceTerritoryDisplayId = assignment.displayId,
            assignmentAuthoritySourceSha256 = assignment.sourceHashes.first(),
            lockedAssignmentReconciled = true,
            missingExpectedSegmentCount = 0,
            unexpectedMeaningChangingSegmentCount = 0,
            assignmentColorConflictCount = 0,
            unresolvedPerimeterWorkedSideCount = 0,
            illegalMidSegmentColorTransitionCount = 0,
            unresolvedBuildingSiteCount = 0,
            crossTerritoryInferenceUsed = false,
            styleOnlyGeographyUsed = false
        ),
        jurisdiction = jurisdiction
    )

    private data class ArcRoad(
        val id: Int,
        val cartographic: String,
        val streetName: String,
        val streetType: String,
        val paths: List<List<Pair<Double, Double>>>
    )

    private data class CensusRoad(
        val id: Int,
        val name: String,
        val basename: String,
        val paths: List<List<Pair<Double, Double>>>
    )

    private fun arcGisRoadBody(roads: List<ArcRoad>): String = buildString {
        append("{\"objectIdFieldName\":\"OBJECTID\",\"geometryType\":\"esriGeometryPolyline\",\"exceededTransferLimit\": false,\"features\":[")
        roads.forEachIndexed { index, road ->
            if (index > 0) append(',')
            append("{\"attributes\":{")
            append("\"OBJECTID\":").append(road.id).append(',')
            append("\"DirectionalPrefix\":\"\",")
            append("\"StreetName\":").append(jsonString(road.streetName)).append(',')
            append("\"StreetType\":").append(jsonString(road.streetType)).append(',')
            append("\"DirectionalSuffix\":\"\",")
            append("\"CartographicName\":").append(jsonString(road.cartographic))
            append("},\"geometry\":{\"paths\":")
            append(pathsJson(road.paths)).append("}}")
        }
        append("]}")
    }

    private fun arcGisCensusRoadBody(roads: List<CensusRoad>): String = buildString {
        append("{\"objectIdFieldName\":\"OBJECTID\",\"geometryType\":\"esriGeometryPolyline\",\"exceededTransferLimit\": false,\"features\":[")
        roads.forEachIndexed { index, road ->
            if (index > 0) append(',')
            append("{\"attributes\":{")
            append("\"OBJECTID\":").append(road.id).append(',')
            append("\"OID\":").append(jsonString("oid-${road.id}")).append(',')
            append("\"NAME\":").append(jsonString(road.name)).append(',')
            append("\"BASENAME\":").append(jsonString(road.basename)).append(',')
            append("\"MTFCC\":\"S1400\"},\"geometry\":{\"paths\":")
            append(pathsJson(road.paths)).append("}}")
        }
        append("]}")
    }

    private fun arcGisSiteAddressBody(
        numbers: List<Int>,
        prefix: String = "",
        streetName: String = "Miller",
        streetType: String = "Ave",
        suffix: String = ""
    ): String = buildString {
        append("{\"objectIdFieldName\":\"OBJECTID\",\"geometryType\":\"esriGeometryPoint\",\"exceededTransferLimit\": false,\"features\":[")
        numbers.forEachIndexed { index, number ->
            if (index > 0) append(',')
            val pin = "P" + (index + 1).toString().padStart(9, '0')
            append("{\"attributes\":{")
            append("\"OBJECTID\":").append(index + 1).append(',')
            append("\"PIN\":").append(jsonString(pin)).append(',')
            append("\"SITEPREFIXONE\":").append(jsonString(prefix)).append(',')
            append("\"SITESTREETNUMBER\":").append(number).append(',')
            append("\"SITESTREETNAME\":").append(jsonString(streetName)).append(',')
            append("\"SITESTREETTYPE\":").append(jsonString(streetType)).append(',')
            append("\"SITESUFFIXONE\":").append(jsonString(suffix)).append(',')
            val addressParts = listOf(number.toString(), prefix, streetName, streetType, suffix).filter(String::isNotBlank)
            append("\"SITESTREETADDRESS\":").append(jsonString(addressParts.joinToString(" ")))
            append("},\"geometry\":{\"x\":-83.14,\"y\":42.68}}")
        }
        append("]}")
    }

    private fun arcGisBuildingBody(pins: List<String>): String = buildString {
        append("{\"objectIdFieldName\":\"objectid\",\"geometryType\":\"esriGeometryPolygon\",\"exceededTransferLimit\": false,\"features\":[")
        pins.forEachIndexed { index, pin ->
            if (index > 0) append(',')
            val x = -83.14 + index * 0.00001
            val y = 42.68 + index * 0.00001
            append("{\"attributes\":{")
            append("\"objectid\":").append(index + 1).append(',')
            append("\"keypin\":").append(jsonString(pin)).append(',')
            append("\"status\":\"existing\"},\"geometry\":{\"rings\":[[[")
            append(x).append(',').append(y).append("],[")
            append(x + 0.000005).append(',').append(y).append("],[")
            append(x + 0.000005).append(',').append(y + 0.000005).append("],[")
            append(x).append(',').append(y).append("]] ]}}")
        }
        append("]}")
    }

    private fun pathsJson(paths: List<List<Pair<Double, Double>>>): String = buildString {
        append('[')
        paths.forEachIndexed { pIndex, path ->
            if (pIndex > 0) append(',')
            append('[')
            path.forEachIndexed { index, point ->
                if (index > 0) append(',')
                append('[').append(point.first).append(',').append(point.second).append(']')
            }
            append(']')
        }
        append(']')
    }

    private fun jsonString(value: String): String = buildString {
        append('"')
        value.forEach { c ->
            when (c) {
                '"' -> append("\\\"")
                '\\' -> append("\\\\")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> append(c)
            }
        }
        append('"')
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
