package com.koenterprises.territorycardstudio.core

import java.io.File

object RoadLabelPlacementEngineTest {
    private val testHash = "a".repeat(64)

    fun run(kb: TerritoryKnowledgeBase, assets: File) {
        val styleFile = File(assets, "R48-Canonical-Style-Tokens.json")
        val style = styleFile.reader(Charsets.UTF_8).use(LabelStyleContractLoader::load)
        val authorityDir = File(assets, "label-authority")
        LabelAuthorityIntegrity.requiredSha256.forEach { (name, expected) ->
            val file = File(authorityDir, name)
            check(file.isFile) { "Missing label authority: $name" }
            val actual = file.inputStream().use(BundleIntegrity::sha256)
            check(actual == expected) { "Label authority hash drift: $name $actual != $expected" }
        }
        check(style.streetFont.family == "DejaVu Sans")
        check(style.streetFont.regularOnly)
        check(style.streetFont.minimumSizePt == 8.0)
        check(style.streetFont.normalSizePt == 9.0)
        check(style.streetFont.denseSizePt == 8.0)
        check(style.placement.assignedRoadGapHardMinPx == 2.0)
        check(style.placement.assignedRoadGapTargetPx == 3.0)
        check(style.placement.assignedRoadGapHardMaxPx == 4.0)
        check(style.placement.sameCardGapTolerancePx == 1.0)
        check(style.placement.calloutPreferredMaxLengthPx == 80.0)
        check(style.placement.calloutHardMaxLengthPx == 110.0)

        val styleText = styleFile.readText(Charsets.UTF_8)
        mutationMustFail(
            styleText,
            "\"street_label_any_object_overlap_allowed\": false",
            "\"street_label_any_object_overlap_allowed\": true",
            "street/object overlap"
        )
        mutationMustFail(
            styleText,
            "\"mixed_status_color_overlap_allowed\": false",
            "\"mixed_status_color_overlap_allowed\": true",
            "mixed-status overlap"
        )
        mutationMustFail(
            styleText,
            "\"no_font_substitution\": true",
            "\"no_font_substitution\": false",
            "font substitution"
        )
        mutationMustFail(
            styleText,
            "\"assigned_road_gap_hard_px\": [\n      2.0,\n      4.0\n    ]",
            "\"assigned_road_gap_hard_px\": [\n      1.0,\n      5.0\n    ]",
            "hard road-gap band"
        )
        mutationMustFail(
            styleText,
            "\"assigned_road_gap_target_px\": 3.0",
            "\"assigned_road_gap_target_px\": 5.0",
            "road-gap target"
        )
        mutationMustFail(
            styleText,
            "\"same_card_gap_tolerance_px\": 1.0",
            "\"same_card_gap_tolerance_px\": 2.0",
            "same-card gap tolerance"
        )
        mutationMustFail(
            styleText,
            "\"callout_hard_max_length_px\": 110",
            "\"callout_hard_max_length_px\": 130",
            "callout hard maximum"
        )
        mutationMustFail(
            styleText,
            "\"direct_road_following\",\n      \"curved_road_following\",\n      \"same_road_relocation\"",
            "\"direct_road_following\",\n      \"same_road_relocation\",\n      \"curved_road_following\"",
            "placement order"
        )

        val engine = RoadLabelPlacementEngine(style)
        directPlacementUsesNorthTieBreaker(engine)
        verticalPlacementUsesEastTieBreaker(engine)
        reversedRoadUpright(engine)
        cleanerSideWinsWhenPreferredCandidateBlocked(engine)
        exactEdgeContactIsRejected(engine)
        sameRoadRelocation(engine)
        curvedRoadRoutesToRenderer(engine)
        perimeterRequiresExteriorDirection(engine)
        perimeterUsesDeclaredExterior(engine)
        navigationLockViolations(engine)
        fontContractViolations(engine)
        cardWideFontUniformity(engine)
        renderedShortStreetFitBeatsPlanningHeuristic(engine)
        shortStreetUsesAttachedCallout(engine)
        blockedCalloutRoutesToDetail(engine)
        mixedStatusRoadObstacleBlocksOverlap(engine)
        frozenCorpusPreflight(kb)
    }

    private fun directPlacementUsesNorthTieBreaker(engine: RoadLabelPlacementEngine) {
        val decision = engine.place(
            request(
                road = road("Main St", listOf(p(20, 50), p(180, 50))),
                metrics = metrics(40.0, 10.0)
            )
        )
        val placed = decision as? LabelPlacementDecision.Placed ?: error("direct placement did not place: $decision")
        check(placed.placement.mode == LabelPlacementMode.DIRECT_ROAD_FOLLOWING)
        check(close(placed.placement.roadGapGeometryUnits, 3.0))
        check(close(placed.placement.angleDeg, 0.0))
        check(placed.placement.center.y < 50.0) { "horizontal tie-break must use north/above side" }
        val evidence = requireNotNull(placed.placement.sideEvidence)
        check(evidence.sideOptionsReviewed == setOf(LabelSide.POSITIVE_NORMAL, LabelSide.NEGATIVE_NORMAL))
        check(evidence.usedSide == evidence.preferredSide)
        check(evidence.preferredSideCandidateFitClean)
    }

    private fun verticalPlacementUsesEastTieBreaker(engine: RoadLabelPlacementEngine) {
        val decision = engine.place(
            request(
                road = road("North Rd", listOf(p(50, 10), p(50, 90))),
                metrics = metrics(30.0, 10.0),
                bounds = AxisAlignedRect(0.0, 0.0, 120.0, 100.0)
            )
        )
        val placed = decision as LabelPlacementDecision.Placed
        check(placed.placement.center.x > 50.0) { "vertical tie-break must use right/east side" }
    }

    private fun reversedRoadUpright(engine: RoadLabelPlacementEngine) {
        val decision = engine.place(
            request(
                road = road("Main St", listOf(p(180, 50), p(20, 50))),
                metrics = metrics(40.0, 10.0)
            )
        )
        val placed = decision as LabelPlacementDecision.Placed
        check(close(placed.placement.angleDeg, 0.0)) { "reversed road label must remain upright: ${placed.placement.angleDeg}" }
        check(placed.placement.center.y < 50.0) { "page-side tie-break must remain north even when road geometry is reversed" }
    }

    private fun cleanerSideWinsWhenPreferredCandidateBlocked(engine: RoadLabelPlacementEngine) {
        val northBlocker = LabelObstacle("north-blocker", LabelObstacleKind.BUILDING, AxisAlignedRect(78.0, 34.0, 122.0, 46.0))
        val decision = engine.place(
            request(
                road = road("Oak St", listOf(p(20, 50), p(180, 50))),
                metrics = metrics(40.0, 10.0),
                obstacles = listOf(northBlocker)
            )
        )
        val placed = decision as LabelPlacementDecision.Placed
        check(placed.placement.mode == LabelPlacementMode.DIRECT_ROAD_FOLLOWING)
        check(placed.placement.center.y > 50.0) { "engine should use the cleaner collision-free side" }
        val evidence = requireNotNull(placed.placement.sideEvidence)
        check(evidence.preferredSideClear)
        check(evidence.preferredSideReason == "only clean policy-allowed side")
        check(evidence.candidates.count { it.fitClean } == 1)
    }

    private fun exactEdgeContactIsRejected(engine: RoadLabelPlacementEngine) {
        val northToucher = LabelObstacle("touching-label", LabelObstacleKind.STREET_LABEL, AxisAlignedRect(80.0, 25.0, 120.0, 35.0))
        val decision = engine.place(
            request(
                road = road("Touch Rd", listOf(p(20, 50), p(180, 50))),
                metrics = metrics(40.0, 10.0),
                obstacles = listOf(northToucher)
            )
        )
        val placed = decision as LabelPlacementDecision.Placed
        check(placed.placement.center.y > 50.0) { "edge contact must disqualify the north candidate" }
        val north = requireNotNull(placed.placement.sideEvidence).candidates.first { it.side == LabelSide.NEGATIVE_NORMAL }
        check(north.anyObjectContactCount == 1)
        check(north.labelContactOrOverlapCount == 1)
        check(!north.fitClean)
    }

    private fun sameRoadRelocation(engine: RoadLabelPlacementEngine) {
        val blockers = listOf(
            LabelObstacle("primary-plus", LabelObstacleKind.BUILDING, AxisAlignedRect(25.0, 52.0, 75.0, 70.0)),
            LabelObstacle("primary-minus", LabelObstacleKind.BUILDING, AxisAlignedRect(25.0, 30.0, 75.0, 48.0))
        )
        val decision = engine.place(
            request(
                road = road("Relocate Dr", listOf(p(0, 50), p(100, 50), p(200, 50))),
                metrics = metrics(40.0, 10.0),
                bounds = AxisAlignedRect(-20.0, 0.0, 220.0, 100.0),
                obstacles = blockers
            )
        )
        val placed = decision as? LabelPlacementDecision.Placed ?: error("relocation did not place: $decision")
        check(placed.placement.mode == LabelPlacementMode.SAME_ROAD_RELOCATION)
        check(placed.placement.sourceSegmentIndex == 1)
        check(placed.attempts.any { it.mode == LabelPlacementMode.DIRECT_ROAD_FOLLOWING && !it.accepted })
        check(placed.attempts.any { it.mode == LabelPlacementMode.SAME_ROAD_RELOCATION && it.accepted })
        check(placed.placement.navigationLock.segmentId == "test-Relocate-Dr")
    }

    private fun curvedRoadRoutesToRenderer(engine: RoadLabelPlacementEngine) {
        val northBlocker = LabelObstacle("curve-north", LabelObstacleKind.BUILDING, AxisAlignedRect(35.0, 45.0, 75.0, 70.0))
        val decision = engine.place(
            request(
                road = road("Curve Ct", listOf(p(20, 80), p(60, 78), p(100, 70), p(140, 55))),
                metrics = metrics(50.0, 10.0),
                bounds = AxisAlignedRect(0.0, 0.0, 180.0, 120.0),
                obstacles = listOf(northBlocker)
            )
        )
        val placed = decision as? LabelPlacementDecision.Placed ?: error("curved road should produce verified path placement: $decision")
        check(placed.placement.mode == LabelPlacementMode.CURVED_ROAD_FOLLOWING)
        check(placed.placement.sourceSegmentIndex != null)
        check(placed.placement.sideEvidence != null)
        check(placed.placement.roadGapGeometryUnits == 3.0)
        check(!placed.placement.requiresReview)
    }

    private fun perimeterRequiresExteriorDirection(engine: RoadLabelPlacementEngine) {
        val decision = engine.place(
            request(
                road = road("Border Rd", listOf(p(20, 15), p(180, 15)), role = "perimeter"),
                metrics = metrics(45.0, 10.0)
            )
        )
        val review = decision as LabelPlacementDecision.ReviewRequired
        check(review.reason == LabelReviewReason.PERIMETER_EXTERIOR_DIRECTION_REQUIRED)
    }

    private fun perimeterUsesDeclaredExterior(engine: RoadLabelPlacementEngine) {
        val decision = engine.place(
            request(
                road = road("Border Rd", listOf(p(20, 25), p(180, 25)), role = "perimeter"),
                metrics = metrics(45.0, 10.0),
                exteriorNormalSign = -1
            )
        )
        val placed = decision as LabelPlacementDecision.Placed
        check(placed.placement.center.y < 25.0)
        val evidence = requireNotNull(placed.placement.sideEvidence)
        check(evidence.usedSide.normalSign == -1)
        check(evidence.candidates.first { it.side.normalSign == 1 }.policyAllowed.not())
    }

    private fun navigationLockViolations(engine: RoadLabelPlacementEngine) {
        val r = road("Lock Rd", listOf(p(20, 50), p(180, 50)))
        val bad = lock(r).copy(segmentId = "wrong-segment")
        val decision = engine.place(request(r, metrics(40.0, 10.0), lockOverride = bad))
        val review = decision as LabelPlacementDecision.ReviewRequired
        check(review.reason == LabelReviewReason.NAVIGATION_LOCK_VIOLATION)

        val perimeter = road("Edge Rd", listOf(p(20, 25), p(180, 25)), role = "perimeter")
        val missingSides = lock(perimeter).copy(territoryFacingSide = null, exteriorSide = null)
        val sideDecision = engine.place(
            request(perimeter, metrics(40.0, 10.0), exteriorNormalSign = -1, lockOverride = missingSides)
        )
        check((sideDecision as LabelPlacementDecision.ReviewRequired).reason == LabelReviewReason.NAVIGATION_LOCK_VIOLATION)
    }

    private fun fontContractViolations(engine: RoadLabelPlacementEngine) {
        val base = road("Font Rd", listOf(p(20, 50), p(180, 50)))
        val wrongFamily = engine.place(
            request(base, StreetLabelTextMetrics(40.0, 10.0, 9.0, "Roboto", TextMetricsProvenance.VERIFIED_SHAPING_ENGINE))
        )
        check((wrongFamily as LabelPlacementDecision.ReviewRequired).reason == LabelReviewReason.FONT_CONTRACT_VIOLATION)
        val bold = engine.place(
            request(
                base,
                StreetLabelTextMetrics(40.0, 10.0, 9.0, "DejaVu Sans", TextMetricsProvenance.VERIFIED_SHAPING_ENGINE, isBold = true)
            )
        )
        check((bold as LabelPlacementDecision.ReviewRequired).reason == LabelReviewReason.FONT_CONTRACT_VIOLATION)
        val tooSmall = engine.place(
            request(base, StreetLabelTextMetrics(40.0, 10.0, 7.9, "DejaVu Sans", TextMetricsProvenance.ACTUAL_PDF_FONT_WIDTHS))
        )
        check((tooSmall as LabelPlacementDecision.ReviewRequired).reason == LabelReviewReason.FONT_CONTRACT_VIOLATION)
    }

    private fun cardWideFontUniformity(engine: RoadLabelPlacementEngine) {
        val base = road("Uniform Rd", listOf(p(20, 50), p(180, 50)))
        val eightPt = StreetLabelTextMetrics(40.0, 10.0, 8.0, "DejaVu Sans", TextMetricsProvenance.VERIFIED_SHAPING_ENGINE)
        val rejected = engine.place(request(base, eightPt, cardFontSizePt = 9.0))
        check((rejected as LabelPlacementDecision.ReviewRequired).reason == LabelReviewReason.CARD_FONT_UNIFORMITY_VIOLATION)
        val approved = engine.place(request(base, eightPt, cardFontSizePt = 9.0, userApprovedSizeException = true))
        check(approved is LabelPlacementDecision.Placed)
    }

    private fun renderedShortStreetFitBeatsPlanningHeuristic(engine: RoadLabelPlacementEngine) {
        val decision = engine.place(
            request(
                road = road("Short Rd", listOf(p(65, 50), p(135, 50))),
                metrics = metrics(50.0, 10.0),
                bounds = AxisAlignedRect(0.0, 0.0, 200.0, 100.0)
            )
        )
        val placed = decision as? LabelPlacementDecision.Placed ?: error("clean rendered short-road fit must beat planning heuristic: $decision")
        check(placed.placement.mode == LabelPlacementMode.DIRECT_ROAD_FOLLOWING)
        val sideEvidence = requireNotNull(placed.placement.sideEvidence)
        val candidate = sideEvidence.candidates.first { it.side == sideEvidence.usedSide }
        check(candidate.endClearancePx == 10.0)
        check(candidate.endClearancePx < 15.0) { "fixture must remain below inherited short-street planning target" }
        check(candidate.fitClean)
    }

    private fun shortStreetUsesAttachedCallout(engine: RoadLabelPlacementEngine) {
        val decision = engine.place(
            request(
                road = road("Tiny Ct", listOf(p(90, 50), p(110, 50))),
                metrics = metrics(60.0, 10.0),
                bounds = AxisAlignedRect(0.0, 0.0, 300.0, 150.0)
            )
        )
        val placed = decision as? LabelPlacementDecision.Placed ?: error("short street should use attached callout: $decision")
        check(placed.placement.mode == LabelPlacementMode.NEARBY_ATTACHED_ARROW_CALLOUT)
        val callout = requireNotNull(placed.placement.callout)
        val evidence = requireNotNull(placed.placement.calloutEvidence)
        check(callout.length <= 80.0 + 1e-9)
        check(close(distance(callout.labelAttach, callout.tailStart), callout.tailGapGeometryUnits)) {
            "leader tail gap must be measured from label edge"
        }
        check(distance(callout.tailStart, callout.roadAnchor) > distance(callout.labelAttach, callout.tailStart)) {
            "leader shaft must run from label-side tail toward exact road anchor"
        }
        check(evidence.directCandidateTested)
        check(!evidence.directCandidateFitClean)
        check(evidence.calloutJustified)
        check(evidence.directCandidateEndClearanceMinPx < 0.0)
        val expandedRoad = AxisAlignedRect(88.0, 48.0, 112.0, 52.0)
        check(!placed.placement.bounds.touchesOrOverlaps(expandedRoad)) { "callout label box must not touch its own assigned road stroke" }
    }

    private fun blockedCalloutRoutesToDetail(engine: RoadLabelPlacementEngine) {
        val fullBlocker = LabelObstacle("blocked-region", LabelObstacleKind.DETAIL, AxisAlignedRect(0.0, 0.0, 300.0, 150.0))
        val decision = engine.place(
            request(
                road = road("Tiny Ct", listOf(p(90, 50), p(110, 50))),
                metrics = metrics(60.0, 10.0),
                bounds = AxisAlignedRect(0.0, 0.0, 300.0, 150.0),
                obstacles = listOf(fullBlocker)
            )
        )
        val review = decision as? LabelPlacementDecision.ReviewRequired ?: error("blocked label should require detail: $decision")
        check(review.recommendedMode == LabelPlacementMode.DEDICATED_DETAIL)
        check(review.reason == LabelReviewReason.DEDICATED_DETAIL_REQUIRED)
    }

    private fun mixedStatusRoadObstacleBlocksOverlap(engine: RoadLabelPlacementEngine) {
        val blocker = LabelObstacle(
            id = "red-road",
            kind = LabelObstacleKind.ROAD,
            bounds = AxisAlignedRect(70.0, 34.0, 130.0, 46.0),
            roadStatus = "red"
        )
        val decision = engine.place(
            request(
                road = road("Green Rd", listOf(p(20, 50), p(180, 50)), status = "green"),
                metrics = metrics(40.0, 10.0),
                obstacles = listOf(blocker)
            )
        )
        val placed = decision as LabelPlacementDecision.Placed
        check(placed.placement.center.y > 50.0) { "label must not overlap mixed-status road obstacle" }
        check(placed.placement.sideEvidence!!.candidates.any { it.roadOverlapCount > 0 })
    }

    private fun frozenCorpusPreflight(kb: TerritoryKnowledgeBase) {
        val authoritativeAssignments = kb.assignments.values.filter { it.geometryAvailable }
        val namedRoads = authoritativeAssignments.flatMap { assignment -> assignment.roads.filter { it.name.isNotBlank() } }
        check(namedRoads.size == 3802) { "Expected 3802 named authoritative road segments, got ${namedRoads.size}" }
        check(namedRoads.all { it.points.size >= 2 }) { "Named authoritative road segment missing geometry" }
        check(namedRoads.all { it.segmentId.isNotBlank() }) { "Named authoritative road segment missing segment ID" }
        check(namedRoads.all { it.role in setOf("interior", "perimeter", "excluded") }) { "Unexpected road role in label corpus" }
        check(namedRoads.all { it.status in setOf("green", "yellow", "red") }) { "Unexpected road status in label corpus" }
        check(namedRoads.count { it.role == "perimeter" } == 796)
        check(namedRoads.count { it.role == "interior" } == 1065)
        check(namedRoads.count { it.role == "excluded" } == 1941)
        authoritativeAssignments.forEach { assignment ->
            check(assignment.sourceHashes.isNotEmpty()) { "${assignment.displayId} lacks source hashes for label target locks" }
            check(assignment.sourceHashes.all { SHA256_HEX_TEST.matches(it) }) { "${assignment.displayId} has malformed source hash" }
            val ids = assignment.roads.map { it.segmentId }
            check(ids.size == ids.toSet().size) { "${assignment.displayId} has duplicate road segment IDs" }
        }
    }

    private fun request(
        road: RoadGeometry,
        metrics: StreetLabelTextMetrics,
        bounds: AxisAlignedRect = AxisAlignedRect(0.0, 0.0, 200.0, 100.0),
        obstacles: List<LabelObstacle> = emptyList(),
        exteriorNormalSign: Int? = null,
        cardFontSizePt: Double = metrics.fontSizePt,
        userApprovedSizeException: Boolean = false,
        lockOverride: LabelNavigationLock? = null
    ): StreetLabelRequest {
        val labelId = "${road.segmentId}:label"
        return StreetLabelRequest(
            labelId = labelId,
            road = road,
            navigationLock = lockOverride ?: lock(road, labelId),
            textMetrics = metrics,
            cardStreetFontSizePt = cardFontSizePt,
            mapBounds = bounds,
            scale = LabelLayoutScale(1.0),
            obstacles = obstacles,
            perimeterExteriorNormalSign = exteriorNormalSign,
            userApprovedIndividualSizeException = userApprovedSizeException
        )
    }

    private fun lock(road: RoadGeometry, labelId: String = "${road.segmentId}:label"): LabelNavigationLock =
        LabelNavigationLock(
            labelId = labelId,
            streetName = road.name,
            navigationRole = if (road.role == "perimeter") "perimeter_run" else "road_run",
            segmentId = road.segmentId,
            sourceEvidence = "synthetic-regression-fixture",
            sourceSha256 = testHash,
            territoryFacingSide = if (road.role == "perimeter") "territory_side" else null,
            exteriorSide = if (road.role == "perimeter") "exterior_side" else null
        )

    private fun road(
        name: String,
        points: List<Point2D>,
        role: String = "interior",
        status: String = "green"
    ): RoadGeometry = RoadGeometry(
        segmentId = "test-${name.replace(' ', '-')}",
        name = name,
        normalizedName = name.lowercase(),
        status = status,
        role = role,
        insideSide = "both",
        accessOnly = false,
        endpointAKind = "junction",
        endpointBKind = "junction",
        widthPt = 4.0,
        points = points
    )

    private fun metrics(width: Double, height: Double): StreetLabelTextMetrics =
        StreetLabelTextMetrics(width, height, 9.0, "DejaVu Sans", TextMetricsProvenance.VERIFIED_SHAPING_ENGINE)

    private fun p(x: Number, y: Number): Point2D = Point2D(x.toDouble(), y.toDouble())
    private fun close(a: Double, b: Double): Boolean = kotlin.math.abs(a - b) <= 1e-9
    private fun distance(a: Point2D, b: Point2D): Double = kotlin.math.hypot(b.x - a.x, b.y - a.y)

    private fun mutationMustFail(source: String, old: String, replacement: String, label: String) {
        val mutated = source.replaceFirst(old, replacement)
        check(mutated != source) { "Style mutation fixture not found: $label" }
        check(runCatching { LabelStyleContractLoader.load(mutated.reader()) }.isFailure) {
            "Unsafe style mutation unexpectedly accepted: $label"
        }
    }

    private val SHA256_HEX_TEST = Regex("^[0-9a-f]{64}$")
}
