package com.koenterprises.territorycardstudio.core

import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.time.Clock
import java.time.Instant
import java.time.ZoneId
import java.util.ArrayDeque
import kotlin.io.path.createTempDirectory

object ProviderExecutionCoordinatorTest {
    fun run(kb: TerritoryKnowledgeBase, assets: File) {
        val policy = File(assets, "Online-Source-Policy.json").reader(Charsets.UTF_8).use(OnlineSourcePolicyLoader::load)
        val assignment = kb.assignments.getValue("253")
        val request = requestFor(kb, policy, assignment)
        val plans = ProviderQueryPlanner.initialPlans(request, policy)
        val oakland = requireNotNull(plans.oaklandRoads)
        val nominatim = plans.osmAreaLookup

        check(ProviderExecutionPolicy.revision == "2026-09-25-provider-execution-v1")
        check(ProviderExecutionPolicy.ruleFor(nominatim).minimumRequestIntervalMillis == 1_000L)
        check(ProviderExecutionPolicy.ruleFor(nominatim).maxResponseBytes == 2 * 1024 * 1024)
        check(ProviderExecutionPolicy.ruleFor(oakland).maxAttempts == 3)
        check(ProviderHttpEncoding.requestUrl(nominatim).startsWith("https://nominatim.openstreetmap.org/search?"))
        check("Oakland%20County%2C%20Michigan%2C%20United%20States" in ProviderHttpEncoding.requestUrl(nominatim))

        val fakeClock = MutableClock(Instant.parse("2026-09-25T11:00:00Z"))
        val sleeper = AdvancingSleeper(fakeClock)
        val successBody = "{\"features\":[]}"
        val transport = QueueTransport(fakeClock).apply {
            enqueue(200, successBody)
        }
        val coordinator = ProviderExecutionCoordinator(transport, NoProviderEvidenceCache, fakeClock, sleeper, ProviderRateGate())
        val raw = coordinator.execute(oakland, ProviderCacheMode.BYPASS)
        check(raw.plan === oakland || raw.plan == oakland) { "Provider execution did not preserve exact plan" }
        check(raw.body == successBody)
        check(raw.observedAtUtc == "2026-09-25T11:00:00Z")
        check(transport.calls.single().plan == oakland)
        check(transport.calls.single().rule == ProviderExecutionPolicy.ruleFor(oakland))

        val retryClock = MutableClock(Instant.parse("2026-09-25T11:10:00Z"))
        val retrySleeper = AdvancingSleeper(retryClock)
        val retryTransport = QueueTransport(retryClock).apply {
            enqueue(503, "{\"error\":\"busy\"}")
            enqueue(200, successBody)
        }
        val retried = ProviderExecutionCoordinator(retryTransport, NoProviderEvidenceCache, retryClock, retrySleeper, ProviderRateGate())
            .execute(oakland, ProviderCacheMode.BYPASS)
        check(retried.body == successBody)
        check(retryTransport.calls.size == 2)
        check(retrySleeper.sleeps == listOf(750L)) { "Unexpected retry delay ${retrySleeper.sleeps}" }

        val nonRetryClock = MutableClock(Instant.parse("2026-09-25T11:20:00Z"))
        val nonRetryTransport = QueueTransport(nonRetryClock).apply { enqueue(400, "{\"error\":\"bad request\"}") }
        val nonRetry = ProviderExecutionCoordinator(nonRetryTransport, NoProviderEvidenceCache, nonRetryClock, AdvancingSleeper(nonRetryClock), ProviderRateGate())
        val nonRetryFailure = runCatching { nonRetry.execute(oakland, ProviderCacheMode.BYPASS) }.exceptionOrNull()
        check(nonRetryFailure is ProviderHttpStatusException && nonRetryFailure.statusCode == 400)
        check(nonRetryTransport.calls.size == 1) { "Permanent HTTP error was retried" }

        val overpassAreaBody = """[{"place_id":1,"osm_type":"relation","osm_id":180107,"class":"boundary","type":"administrative","display_name":"Oakland County, Michigan, United States","address":{"county":"Oakland County","state":"Michigan","country":"United States","country_code":"us"}}]"""
        val areaResponse = ProviderRawResponse(nominatim, overpassAreaBody, "2026-09-25T11:30:00Z")
        val area = ProviderResponseParser.parseOsmArea(areaResponse, VerificationJurisdiction("Oakland County", "Michigan", "United States"))
        val overpass = ProviderQueryPlanner.osmRoadPlan(request, policy, area)
        val overpassForm = ProviderHttpEncoding.formBody(overpass)
        check(overpass.method == ProviderHttpMethod.POST_FORM)
        check(overpassForm.startsWith("data=%5Bout%3Ajson%5D")) { "Overpass form body is not deterministic x-www-form-urlencoded data" }
        check(ProviderHttpEncoding.requestUrl(overpass) == overpass.endpoint)
        val overpassClock = MutableClock(Instant.parse("2026-09-25T11:30:00Z"))
        val overpassSleeper = AdvancingSleeper(overpassClock)
        val overpassTransport = QueueTransport(overpassClock).apply {
            enqueue(429, "{\"remark\":\"rate limited\"}")
            enqueue(200, "{\"elements\":[]}")
        }
        ProviderExecutionCoordinator(overpassTransport, NoProviderEvidenceCache, overpassClock, overpassSleeper, ProviderRateGate())
            .execute(overpass, ProviderCacheMode.BYPASS)
        check(overpassSleeper.sleeps == listOf(30_000L)) { "Overpass 429 did not enforce 30 second backoff: ${overpassSleeper.sleeps}" }

        val nominatimClock = MutableClock(Instant.parse("2026-09-25T11:40:00Z"))
        val nominatimSleeper = AdvancingSleeper(nominatimClock)
        val nominatimTransport = QueueTransport(nominatimClock).apply {
            enqueue(200, overpassAreaBody)
            enqueue(200, overpassAreaBody)
        }
        val nominatimCoordinator = ProviderExecutionCoordinator(nominatimTransport, NoProviderEvidenceCache, nominatimClock, nominatimSleeper, ProviderRateGate())
        nominatimCoordinator.execute(nominatim, ProviderCacheMode.BYPASS)
        nominatimClock.advanceMillis(250)
        nominatimCoordinator.execute(nominatim, ProviderCacheMode.BYPASS)
        check(nominatimSleeper.sleeps == listOf(750L)) { "Nominatim one-request-per-second throttle failed: ${nominatimSleeper.sleeps}" }
        check(nominatimTransport.calls[1].at.toEpochMilli() - nominatimTransport.calls[0].at.toEpochMilli() >= 1_000)

        val sharedGateClock = MutableClock(Instant.parse("2026-09-25T11:45:00Z"))
        val sharedGateSleeper = AdvancingSleeper(sharedGateClock)
        val sharedGate = ProviderRateGate()
        val firstGateTransport = QueueTransport(sharedGateClock).apply { enqueue(200, overpassAreaBody) }
        val secondGateTransport = QueueTransport(sharedGateClock).apply { enqueue(200, overpassAreaBody) }
        ProviderExecutionCoordinator(firstGateTransport, NoProviderEvidenceCache, sharedGateClock, sharedGateSleeper, sharedGate)
            .execute(nominatim, ProviderCacheMode.BYPASS)
        sharedGateClock.advanceMillis(100)
        ProviderExecutionCoordinator(secondGateTransport, NoProviderEvidenceCache, sharedGateClock, sharedGateSleeper, sharedGate)
            .execute(nominatim, ProviderCacheMode.BYPASS)
        check(sharedGateSleeper.sleeps == listOf(900L)) { "Nominatim throttle was not shared across coordinator instances" }

        val retryAfterClock = MutableClock(Instant.parse("2026-09-25T11:50:00Z"))
        val retryAfterSleeper = AdvancingSleeper(retryAfterClock)
        val retryAfterTransport = QueueTransport(retryAfterClock).apply {
            enqueue(429, "busy", mapOf("Retry-After" to listOf("5")))
            enqueue(200, successBody)
        }
        ProviderExecutionCoordinator(retryAfterTransport, NoProviderEvidenceCache, retryAfterClock, retryAfterSleeper, ProviderRateGate())
            .execute(oakland, ProviderCacheMode.BYPASS)
        check(retryAfterSleeper.sleeps == listOf(5_000L))

        val ioClock = MutableClock(Instant.parse("2026-09-25T12:00:00Z"))
        val ioSleeper = AdvancingSleeper(ioClock)
        val ioTransport = QueueTransport(ioClock).apply {
            enqueueFailure(IOException("fixture connection reset"))
            enqueue(200, successBody)
        }
        ProviderExecutionCoordinator(ioTransport, NoProviderEvidenceCache, ioClock, ioSleeper, ProviderRateGate())
            .execute(oakland, ProviderCacheMode.BYPASS)
        check(ioSleeper.sleeps == listOf(750L))
        check(ioTransport.calls.size == 2)

        val largeClock = MutableClock(Instant.parse("2026-09-25T12:10:00Z"))
        val tooLarge = "x".repeat(ProviderExecutionPolicy.ruleFor(nominatim).maxResponseBytes + 1)
        val largeTransport = QueueTransport(largeClock).apply { enqueue(200, tooLarge) }
        check(runCatching {
            ProviderExecutionCoordinator(largeTransport, NoProviderEvidenceCache, largeClock, AdvancingSleeper(largeClock), ProviderRateGate())
                .execute(nominatim, ProviderCacheMode.BYPASS)
        }.exceptionOrNull() is ProviderResponseTooLargeException) { "Oversized response did not fail closed" }
        check(largeTransport.calls.size == 1) { "Oversized response was retried" }

        val cacheDir = createTempDirectory("tcs-provider-cache-").toFile()
        try {
            val cacheClock = MutableClock(Instant.parse("2026-09-25T12:20:00Z"))
            val cacheTransport = QueueTransport(cacheClock).apply { enqueue(200, successBody) }
            val cache = DirectoryProviderEvidenceCache(cacheDir)
            val cachedCoordinator = ProviderExecutionCoordinator(cacheTransport, cache, cacheClock, AdvancingSleeper(cacheClock), ProviderRateGate())
            val first = cachedCoordinator.execute(oakland)
            check(cacheTransport.calls.size == 1)
            cacheClock.advanceMillis(60_000)
            val second = cachedCoordinator.execute(oakland)
            check(cacheTransport.calls.size == 1) { "Fresh evidence cache did not prevent duplicate network call" }
            check(second.responseSha256 == first.responseSha256)
            check(second.observedAtUtc == first.observedAtUtc) { "Cache changed source observation timestamp" }

            val bodyFile = cacheDir.listFiles()!!.single { it.name.endsWith(".body") }
            bodyFile.appendText("tamper", Charsets.UTF_8)
            check(runCatching { cachedCoordinator.execute(oakland) }.exceptionOrNull() is ProviderCacheIntegrityException) {
                "Tampered provider cache body did not fail closed"
            }
        } finally {
            cacheDir.deleteRecursively()
        }

        val staleCacheDir = createTempDirectory("tcs-provider-stale-cache-").toFile()
        try {
            val staleClock = MutableClock(Instant.parse("2026-09-25T12:30:00Z"))
            val staleTransport = QueueTransport(staleClock).apply {
                enqueue(200, "{\"features\":[1]}")
                enqueue(200, "{\"features\":[2]}")
            }
            val staleCoordinator = ProviderExecutionCoordinator(
                staleTransport,
                DirectoryProviderEvidenceCache(staleCacheDir),
                staleClock,
                AdvancingSleeper(staleClock),
                ProviderRateGate()
            )
            check(staleCoordinator.execute(oakland).body.contains("[1]"))
            staleClock.advanceMillis((ProviderExecutionPolicy.ruleFor(oakland).freshCacheSeconds + 1) * 1_000)
            val staleBodyFile = staleCacheDir.listFiles()!!.single { it.name.endsWith(".body") }
            staleBodyFile.appendText("tamper", Charsets.UTF_8)
            check(runCatching { staleCoordinator.execute(oakland) }.exceptionOrNull() is ProviderCacheIntegrityException) {
                "Expired cached evidence bypassed integrity verification"
            }
            staleCacheDir.deleteRecursively()
            check(staleCacheDir.mkdirs())
            val refreshedCoordinator = ProviderExecutionCoordinator(
                staleTransport,
                DirectoryProviderEvidenceCache(staleCacheDir),
                staleClock,
                AdvancingSleeper(staleClock),
                ProviderRateGate()
            )
            check(refreshedCoordinator.execute(oakland).body.contains("[2]"))
            check(staleTransport.calls.size == 2) { "Stale provider evidence was reused" }
        } finally {
            staleCacheDir.deleteRecursively()
        }

        val otherRequest = requestFor(kb, policy, kb.assignments.getValue("362"))
        val otherPlan = requireNotNull(ProviderQueryPlanner.initialPlans(otherRequest, policy).oaklandRoads)
        check(otherPlan.planFingerprint != oakland.planFingerprint)
        val isolatedCacheDir = createTempDirectory("tcs-provider-isolated-cache-").toFile()
        try {
            val isolationClock = MutableClock(Instant.parse("2026-09-25T12:40:00Z"))
            val isolationTransport = QueueTransport(isolationClock).apply {
                enqueue(200, successBody)
                enqueue(200, successBody)
            }
            val isolationCoordinator = ProviderExecutionCoordinator(
                isolationTransport,
                DirectoryProviderEvidenceCache(isolatedCacheDir),
                isolationClock,
                AdvancingSleeper(isolationClock),
                ProviderRateGate()
            )
            isolationCoordinator.execute(oakland)
            isolationCoordinator.execute(otherPlan)
            check(isolationTransport.calls.size == 2) { "Provider cache crossed verification-request/plan boundaries" }
            check(isolatedCacheDir.listFiles()!!.count { it.name.endsWith(".meta") } == 2)
        } finally {
            isolatedCacheDir.deleteRecursively()
        }

        check(runCatching {
            ProviderExecutionPolicy.ruleFor(
                ProviderQueryPlanner.initialPlans(request, policy).osmAreaLookup.copy(resourceId = "tampered")
            )
        }.isFailure) { "Tampered provider plan entered execution policy" }
    }

    private fun requestFor(
        kb: TerritoryKnowledgeBase,
        policy: OnlineSourcePolicy,
        assignment: KnowledgeBaseAssignment
    ): LiveGeometryVerificationRequest = LiveGeometryVerificationRequestFactory.create(
        kb = kb,
        policy = policy,
        displayId = assignment.displayId,
        candidateSourceSha256 = sha256("provider-execution-fixture:${assignment.displayId}"),
        candidateTopology = requireNotNull(assignment.topologySignature),
        candidateBuildingMemberIds = emptyList(),
        sourceTruth = CandidateSourceTruthState(
            sourceTerritoryDisplayId = assignment.displayId,
            assignmentAuthoritySourceSha256 = assignment.sourceHashes.first(),
            lockedAssignmentReconciled = true,
            missingExpectedSegmentCount = 0,
            unexpectedMeaningChangingSegmentCount = 0,
            assignmentColorConflictCount = 0,
            unresolvedPerimeterWorkedSideCount = 0,
            illegalMidSegmentColorTransitionCount = 0,
            unresolvedBuildingSiteCount = 0,
            crossTerritoryInferenceUsed = false,
            styleOnlyGeographyUsed = false
        ),
        jurisdiction = VerificationJurisdiction("Oakland County", "Michigan", "United States")
    )

    private data class TransportCall(val plan: ProviderQueryPlan, val rule: ProviderExecutionRule, val at: Instant)

    private class QueueTransport(private val clock: Clock) : ProviderTransport {
        private sealed interface Item {
            data class Response(val status: Int, val body: String, val headers: Map<String, List<String>>) : Item
            data class Failure(val error: IOException) : Item
        }

        private val queue = ArrayDeque<Item>()
        val calls = mutableListOf<TransportCall>()

        fun enqueue(status: Int, body: String, headers: Map<String, List<String>> = emptyMap()) {
            queue.addLast(Item.Response(status, body, headers))
        }

        fun enqueueFailure(error: IOException) {
            queue.addLast(Item.Failure(error))
        }

        override fun execute(plan: ProviderQueryPlan, rule: ProviderExecutionRule): ProviderTransportResponse {
            calls += TransportCall(plan, rule, Instant.now(clock))
            return when (val item = queue.removeFirst()) {
                is Item.Failure -> throw item.error
                is Item.Response -> ProviderTransportResponse(
                    statusCode = item.status,
                    body = item.body,
                    headers = item.headers,
                    observedAtUtc = Instant.now(clock).toString()
                )
            }
        }
    }

    private class MutableClock(private var instant: Instant) : Clock() {
        override fun getZone(): ZoneId = ZoneId.of("UTC")
        override fun withZone(zone: ZoneId): Clock = this
        override fun instant(): Instant = instant
        fun advanceMillis(millis: Long) {
            instant = instant.plusMillis(millis)
        }
    }

    private class AdvancingSleeper(private val clock: MutableClock) : ProviderSleeper {
        val sleeps = mutableListOf<Long>()
        override fun sleep(millis: Long) {
            require(millis >= 0)
            sleeps += millis
            clock.advanceMillis(millis)
        }
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
