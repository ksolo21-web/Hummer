package com.koenterprises.territorycardstudio.core

object TopologyOverlapDecisionEngineTest {
    fun run(kb: TerritoryKnowledgeBase) {
        topologyBuilderFindsRealJunctionNeighbors()
        topologyValidationAcceptsJunctionTransition()
        topologyValidationRejectsMidBlockTransition()
        topologyValidationRejectsContiguousUnjoinedTransition()
        topologyValidationRejectsAccessOnlyYellow()
        pairClassificationMatrix(kb)
        runtimeCandidateOverlapUsesFrozenAssignments(kb)
        exactLockedPreservesFrozenArtifact(kb)
        unresolvedCandidateFailsClosed(kb)
        frozenTopologySignaturesRecomputeExactly(kb)
        frozenAuditRecomputesExactly(kb)
    }

    private fun road(
        id: String,
        name: String,
        status: String,
        role: String,
        points: List<Point2D>,
        inside: String = "",
        aKind: String = "junction",
        bKind: String = "junction",
        accessOnly: Boolean = false
    ) = RoadGeometry(id, name, TopologyOverlapDecisionEngine.normalizeRoadName(name), status, role, inside, accessOnly, aKind, bKind, 4.0, points)

    private fun topologyBuilderFindsRealJunctionNeighbors() {
        val roads = listOf(
            road("main", "Main Rd", "green", "interior", listOf(Point2D(0.0, 0.0), Point2D(10.0, 0.0))),
            road("west", "West St", "red", "excluded", listOf(Point2D(0.0, -10.0), Point2D(0.0, 10.0))),
            road("east", "East St", "red", "excluded", listOf(Point2D(10.0, -10.0), Point2D(10.0, 10.0)))
        )
        val main = TopologyOverlapDecisionEngine.topologySignature(roads).junctionBoundedSegments.first { it.road == "main rd" }
        check(main.endpointANeighbors == listOf("west st")) { "Unexpected endpoint A neighbors: ${main.endpointANeighbors}" }
        check(main.endpointBNeighbors == listOf("east st")) { "Unexpected endpoint B neighbors: ${main.endpointBNeighbors}" }
    }

    private fun topologyValidationAcceptsJunctionTransition() {
        val roads = listOf(
            road("a", "Boundary Dr", "red", "excluded", listOf(Point2D(0.0, 0.0), Point2D(10.0, 0.0))),
            road("b", "Boundary Dr", "green", "interior", listOf(Point2D(10.0, 0.0), Point2D(20.0, 0.0)))
        )
        val result = TopologyOverlapDecisionEngine.validateIntersectionColorRoles(roads)
        check(result.passed) { "Real-junction color transition should pass: ${result.failures}" }
    }

    private fun topologyValidationRejectsMidBlockTransition() {
        val roads = listOf(
            road("a", "Boundary Dr", "red", "excluded", listOf(Point2D(0.0, 0.0), Point2D(10.0, 0.0)), bKind = "termination"),
            road("b", "Boundary Dr", "green", "interior", listOf(Point2D(10.0, 0.0), Point2D(20.0, 0.0)), aKind = "termination")
        )
        val result = TopologyOverlapDecisionEngine.validateIntersectionColorRoles(roads)
        check(!result.passed)
        check(result.failures.any { "not at a real junction" in it }) { "Expected real-junction veto, got ${result.failures}" }
    }


    private fun topologyValidationRejectsContiguousUnjoinedTransition() {
        val roads = listOf(
            road("a", "Boundary Dr", "red", "excluded", listOf(Point2D(0.0, 0.0), Point2D(10.0, 0.0))),
            road("b", "Boundary Dr", "green", "interior", listOf(Point2D(10.5, -1.0), Point2D(10.5, 1.0)))
        )
        val result = TopologyOverlapDecisionEngine.validateIntersectionColorRoles(roads)
        check(!result.passed)
        check(result.failures.any { "lacks a shared junction endpoint" in it }) {
            "Expected contiguous-unjoined transition veto, got ${result.failures}"
        }
    }

    private fun topologyValidationRejectsAccessOnlyYellow() {
        val roads = listOf(
            road("a", "Access Rd", "yellow", "perimeter", listOf(Point2D(0.0, 0.0), Point2D(10.0, 0.0)), inside = "left", accessOnly = true)
        )
        val result = TopologyOverlapDecisionEngine.validateIntersectionColorRoles(roads)
        check(!result.passed)
        check(result.failures.any { "access-only road must remain red" in it })
    }

    private fun seg(
        status: String,
        role: String = "interior",
        inside: String = "",
        a: List<String> = listOf("alpha rd"),
        b: List<String> = listOf("beta rd"),
        road: String = "shared rd"
    ) = TopologySegment(road, status, role, inside, false, "junction", "junction", a, b)

    private fun pairClassificationMatrix(kb: TerritoryKnowledgeBase) {
        val green = seg("green")
        val duplicate = TopologyOverlapDecisionEngine.classifyPair("101", "102", green, green, kb)
        check(duplicate is PairClassification.Block)

        val oneEnd = TopologyOverlapDecisionEngine.classifyPair(
            "101", "102", green, seg("green", a = listOf("alpha rd"), b = listOf("gamma rd")), kb
        )
        check(oneEnd is PairClassification.Review && oneEnd.finding.confidence == "medium")

        val unresolvedSides = TopologyOverlapDecisionEngine.classifyPair(
            "101", "102", seg("yellow", role = "perimeter", inside = "left"), seg("yellow", role = "perimeter", inside = "right"), kb
        )
        check(unresolvedSides is PairClassification.Review && unresolvedSides.finding.confidence == "high-segment/side-unresolved")

        val oppositeSides = TopologyOverlapDecisionEngine.classifyPair(
            "101", "102", seg("yellow", role = "perimeter", inside = "east"), seg("yellow", role = "perimeter", inside = "west"), kb
        )
        check(oppositeSides is PairClassification.Allowed)

        val context = TopologyOverlapDecisionEngine.classifyPair("101", "102", green, seg("green", role = "context"), kb)
        check(context == PairClassification.Ignore)

        val red = TopologyOverlapDecisionEngine.classifyPair("101", "102", green, seg("red", role = "excluded"), kb)
        check(red == PairClassification.Ignore)

        val bridgestone = TopologyOverlapDecisionEngine.classifyPair(
            "278", "280", seg("yellow", role = "perimeter", inside = "left", road = "bridgestone dr"),
            seg("yellow", role = "perimeter", inside = "right", road = "bridgestone dr"), kb
        )
        check(bridgestone is PairClassification.Allowed && "278/280" in bridgestone.finding.reason)
    }

    private fun runtimeCandidateOverlapUsesFrozenAssignments(kb: TerritoryKnowledgeBase) {
        val source = kb.assignments.entries.firstNotNullOf { (id, assignment) ->
            assignment.topologySignature?.junctionBoundedSegments?.firstOrNull {
                it.status in setOf("green", "yellow") && it.role != "context" && it.endpointANeighbors.isNotEmpty() && it.endpointBNeighbors.isNotEmpty()
            }?.let { id to it }
        }
        val candidateId = listOf("299", "297", "T250", "A257", "A298", "TA347").first { it != source.first }
        val decision = TopologyOverlapDecisionEngine.crossTerritoryOverlapCheck(
            TerritoryIdentity.parse(candidateId), TopologySignature(listOf(source.second), 1), kb
        )
        check(decision.blocking.any { it.otherTerritory == source.first } || decision.reviewCandidates.any { it.otherTerritory == source.first }) {
            "A copied workable topology segment must never disappear from the overlap gate: source=${source.first}, decision=$decision"
        }
    }

    private fun exactLockedPreservesFrozenArtifact(kb: TerritoryKnowledgeBase) {
        val decision = TopologyOverlapDecisionEngine.crossTerritoryOverlapCheck(
            TerritoryIdentity.parse("355"), null, kb, exactLocked = true
        )
        check(decision.status == "LOCKED_CORPUS_ACCEPTED")
        check(decision.passed)
        check(decision.globalBlockingCount == 0)
        check(decision.blocking.isEmpty() && decision.reviewCandidates.isEmpty())
        check(decision.note?.contains("bytes are not rewritten") == true)
    }

    private fun unresolvedCandidateFailsClosed(kb: TerritoryKnowledgeBase) {
        val decision = TopologyOverlapDecisionEngine.crossTerritoryOverlapCheck(TerritoryIdentity.parse("299"), null, kb)
        check(!decision.passed && decision.status == "UNRESOLVED")
        check(decision.hardFailure?.contains("geometry unavailable") == true)
    }


    private fun frozenTopologySignaturesRecomputeExactly(kb: TerritoryKnowledgeBase) {
        fun key(s: TopologySegment): String = listOf(
            s.road, s.status, s.role, s.insideSide, s.accessOnly.toString(), s.endpointAKind, s.endpointBKind,
            s.endpointANeighbors.joinToString("|"), s.endpointBNeighbors.joinToString("|")
        ).joinToString("\u0001")

        var checked = 0
        kb.assignments.forEach { (id, assignment) ->
            if (!assignment.geometryAvailable) return@forEach
            val stored = assignment.topologySignature ?: error("$id geometry is available but topology signature is missing")
            val recomputed = TopologyOverlapDecisionEngine.topologySignature(assignment.roads)
            check(recomputed.segmentCount == stored.segmentCount) {
                "$id topology segment count drift: ${recomputed.segmentCount} != ${stored.segmentCount}"
            }
            check(recomputed.junctionBoundedSegments.sortedBy(::key) == stored.junctionBoundedSegments.sortedBy(::key)) {
                "$id topology content drift"
            }
            checked++
        }
        check(checked == 214) { "Expected to recompute 214 geometry-available frozen topology signatures, got $checked" }
    }

    private fun frozenAuditRecomputesExactly(kb: TerritoryKnowledgeBase) {
        val recomputed = TopologyOverlapDecisionEngine.auditFrozenAssignments(kb)
        val stored = kb.crossTerritoryOverlapAudit
        check(recomputed.blockingCount == stored.blockingCount) { "Frozen blocker parity drift: ${recomputed.blockingCount} != ${stored.blockingCount}" }
        check(recomputed.reviewCandidateCount == stored.reviewCandidateCount) { "Frozen review parity drift: ${recomputed.reviewCandidateCount} != ${stored.reviewCandidateCount}" }
        check(recomputed.nameOnlyOverlapGroupCount == stored.nameOnlyOverlapGroupCount) { "Name-only parity drift: ${recomputed.nameOnlyOverlapGroupCount} != ${stored.nameOnlyOverlapGroupCount}" }
        check(recomputed.blockingDuplicateWork == stored.blockingDuplicateWork) { "Frozen blocker content drift" }
        check(recomputed.reviewCandidates == stored.reviewCandidates) {
            "Frozen review content drift:\nrecomputed=${recomputed.reviewCandidates}\nstored=${stored.reviewCandidates}"
        }
        check(recomputed.nameOnlyOverlapGroups == stored.nameOnlyOverlapGroups) { "Frozen name-only group content drift" }
        val storedAllowed = stored.allowedSharedContext.mapIndexed { i, v ->
            val o = v.obj("cross_territory_overlap_audit.allowed_shared_context[$i]")
            AllowedSharedFinding(
                road = o.required("road", "allowed_shared_context[$i]").string("allowed_shared_context[$i].road"),
                territories = o.stringList("territories", "allowed_shared_context[$i]"),
                reason = o.required("reason", "allowed_shared_context[$i]").string("allowed_shared_context[$i].reason")
            )
        }
        check(recomputed.allowedSharedContext == storedAllowed) { "Frozen allowed-shared-context content drift" }
    }
}
