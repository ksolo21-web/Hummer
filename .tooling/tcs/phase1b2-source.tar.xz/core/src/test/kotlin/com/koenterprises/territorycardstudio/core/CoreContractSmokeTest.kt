package com.koenterprises.territorycardstudio.core

import java.io.File

fun main(args: Array<String>) {
    require(args.size == 2) { "Pass the territory assets directory and exact-approved PDF regression fixture" }
    val assets = File(args[0])
    val exactApprovedFixture = File(args[1])
    require(assets.isDirectory) { "Missing asset directory: $assets" }
    require(exactApprovedFixture.isFile) { "Missing exact-approved PDF fixture: $exactApprovedFixture" }

    val identityCases = linkedMapOf(
        "263a" to "Territory - 263a.pdf",
        "A263a" to "Territory - 263Aa.pdf",
        "T263a" to "Territory - 263Ta.pdf",
        "TA263a" to "Territory - 263TAa.pdf",
        "TA263b" to "Territory - 263TAb.pdf",
        "A33" to "Territory - 033A.pdf",
        "T40" to "Territory - 040T.pdf",
        "TA45" to "Territory - 045TA.pdf",
        "31a" to "Territory - 031a.pdf",
        "T250" to "Territory - 250T.pdf",
        "A257" to "Territory - 257A.pdf",
        "TA347" to "Territory - 347TA.pdf"
    )
    identityCases.forEach { (visible, fileName) ->
        val parsed = TerritoryIdentity.parse(visible)
        check(parsed.displayId == visible)
        check(parsed.canonicalFilename == fileName) {
            "$visible canonical mismatch: ${parsed.canonicalFilename} != $fileName"
        }
    }

    val invalid = listOf("R263", "R-263-A", "A-263-A", "263R", "A033", "TA045", "263A", "0", "A0", "263aa")
    invalid.forEach { raw ->
        check(runCatching { TerritoryIdentity.parse(raw) }.isFailure) { "Invalid ID unexpectedly accepted: $raw" }
    }

    check(StrictJson.parse("{\"a\":1,\"b\":[true,false,null]}".reader()) is JsonValue.Obj)
    check(runCatching { StrictJson.parse("{\"a\":1,\"a\":2}".reader()) }.isFailure) { "Duplicate JSON key unexpectedly accepted" }
    check(runCatching { StrictJson.parse("{\"a\":1} trailing".reader()) }.isFailure) { "Trailing JSON content unexpectedly accepted" }

    BundleIntegrity.requiredSha256.forEach { (name, expected) ->
        val file = File(assets, name)
        check(file.isFile) { "Missing shared bundle asset: $name" }
        val actual = file.inputStream().use(BundleIntegrity::sha256)
        check(actual == expected) { "$name hash drift: $actual != $expected" }
    }

    val index = File(assets, "Knowledge_Base_Assignment_Status.csv").reader(Charsets.UTF_8).use(AssignmentStatusIndex::load)
    check(index.records.size == 225) { "Expected 225 active assignments, got ${index.records.size}" }

    val expectedNeedsNew = linkedMapOf(
        "T250" to "Territory - 250T.pdf",
        "A257" to "Territory - 257A.pdf",
        "297" to "Territory - 297.pdf",
        "A298" to "Territory - 298A.pdf",
        "299" to "Territory - 299.pdf",
        "TA347" to "Territory - 347TA.pdf"
    )
    val actualNeedsNew = index.needsNewCard.associate { it.displayId to it.canonicalFilename }
    check(actualNeedsNew == expectedNeedsNew) { "needs_new_card drift: $actualNeedsNew" }

    expectedNeedsNew.keys.forEach { id ->
        val status = requireNotNull(index.get(id))
        val policy = ReleasePolicy.evaluate(status)
        check(policy.disposition == ReleaseDisposition.CANDIDATE_UNAPPROVED)
        check(!policy.fieldReleaseAllowed)
    }

    val approved = requireNotNull(index.get("A300a"))
    check(!approved.needsNewCard)
    check(ReleasePolicy.evaluate(approved).fieldReleaseAllowed)

    val kbFile = File(assets, "Territory-Knowledge-Base.json")
    val kb = kbFile.reader(Charsets.UTF_8).use(TerritoryKnowledgeBaseLoader::load)
    val kbText = kbFile.readText(Charsets.UTF_8)
    fun mutationMustFail(old: String, replacement: String, label: String) {
        val mutated = kbText.replaceFirst(old, replacement)
        check(mutated != kbText) { "Mutation fixture not found: $label" }
        check(runCatching { TerritoryKnowledgeBaseLoader.load(mutated.reader()) }.isFailure) { "Fail-closed mutation unexpectedly accepted: $label" }
    }
    mutationMustFail("\"schema_version\": 3", "\"schema_version\": 4", "schema version")
    mutationMustFail("\"unknown_assignment_behavior\": \"BLOCK\"", "\"unknown_assignment_behavior\": \"ALLOW\"", "unknown assignment behavior")
    mutationMustFail("\"road_color_partition\": \"real_junction_to_real_junction_only\"", "\"road_color_partition\": \"mid_block_allowed\"", "road partition")
    mutationMustFail("\"cross_territory_geography_inference\": false", "\"cross_territory_geography_inference\": true", "cross territory inference")
    check(kb.schemaVersion == 3)
    check(kb.assignments.size == 225)
    check(kb.referenceRoles.size == 228)
    check(kb.referenceRoles.values.count { it.role == "style_only" } == 3)
    check(kb.referenceRoles.values.filter { it.role == "style_only" }.none { it.fieldReleaseAllowed })
    check(kb.coverageCandidates.size == 20)
    check(kb.classSupersessions.size == 8)
    check(kb.needsNewCardQueue.keys == expectedNeedsNew.keys) { "KB needs_new_card queue drift: ${kb.needsNewCardQueue.keys}" }
    check(kb.crossTerritoryOverlapAudit.blockingCount == 0)
    check(kb.crossTerritoryOverlapAudit.reviewCandidateCount == 6)
    check(kb.crossTerritoryOverlapAudit.nameOnlyOverlapGroupCount == 458)
    check(kb.populationSummary.building300301Locked == 23)
    check(kb.populationSummary.buildingReauditRequired == 46)
    check(kb.permanentPatches.getValue("300-301-APARTMENT").rule.contains("distinct source-faithful"))
    check(kb.assignments.getValue("A300a").buildingAssignmentStatus == "locked_300_301")
    check(kb.assignments.getValue("A300a").fieldReleaseAllowedForExactArtifact)
    check(kb.assignments.getValue("T250").needsNewCard)
    check(kb.assignments.getValue("T250").newCardApproved == false)
    check(!kb.needsNewCardQueue.getValue("T250").fieldReleaseAllowed)
    val totalRoads = kb.assignments.values.sumOf { it.roads.size }
    val totalBuildings = kb.assignments.values.sumOf { it.buildings.size }
    val totalTopologySegments = kb.assignments.values.sumOf { it.topologySignature?.junctionBoundedSegments?.size ?: 0 }
    check(totalRoads == 6930) { "Expected 6930 road geometries, got $totalRoads" }
    check(totalBuildings == 364) { "Expected 364 building geometries, got $totalBuildings" }
    check(totalTopologySegments == 3802) { "Expected 3802 topology segments, got $totalTopologySegments" }

    TopologyOverlapDecisionEngineTest.run(kb)
    BuildingValidationEngineTest.run(kb)
    RoadLabelPlacementEngineTest.run(kb, assets)
    LiveGeometryVerificationTest.run(kb, assets)
    ProviderQueryPlanningTest.run(kb, assets)
    ProviderExecutionCoordinatorTest.run(kb, assets)
    LiveVerificationExecutionPipelineTest.run(kb, assets)
    ProviderEndpointSwitchConfigTest.run(assets)
    PdfArtifactBoundaryTest.run(kb, assets, exactApprovedFixture)
    CandidatePdfRendererTest.run(assets)
    ProductionRenderModelAdapterTest.run(kb, assets)

    println("PASS core contract smoke test")
    println("identity cases=${identityCases.size}")
    println("invalid identity vetoes=${invalid.size}")
    println("shared assets verified=${BundleIntegrity.requiredSha256.size}")
    println("assignments=${index.records.size}")
    println("needs_new_card=${index.needsNewCard.size}")
    println("kb assignments=${kb.assignments.size}")
    println("kb roads=$totalRoads")
    println("kb buildings=$totalBuildings")
    println("kb topology segments=$totalTopologySegments")
    println("kb overlap review=${kb.crossTerritoryOverlapAudit.reviewCandidateCount}")
    println("kb fail-closed mutations=4")
    println("topology/overlap decision engine=PASS")
    println("300/301 building validation engine=PASS")
    println("road/street label placement engine=PASS")
    println("live GIS/source verification reconciliation=PASS")
    println("provider query planning/response parsing=PASS")
    println("provider execution coordinator/cache/retry=PASS")
    println("live verification execution pipeline=PASS")
    println("provider endpoint service-switch config=PASS")
    println("PDF render/release boundary + exact-approved passthrough=PASS")
    println("deterministic R48 candidate PDF renderer=PASS")
    println("production render-model adapter=PASS")
    println("building locked_300_301 current=" + kb.assignments.values.count { !it.needsNewCard && it.buildingAssignmentStatus == "locked_300_301" })
    println("building re-audit current=" + kb.assignments.values.count { !it.needsNewCard && it.buildingAssignmentStatus == "needs_300_301_reaudit" })
    println("building not-applicable current=" + kb.assignments.values.count { !it.needsNewCard && it.buildingAssignmentStatus == "not_applicable" })
}
