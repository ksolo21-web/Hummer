package com.koenterprises.territorycardstudio.core

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

object PdfArtifactBoundaryTest {
    fun run(kb: TerritoryKnowledgeBase, assets: File, exactApprovedFixture: File) {
        val rendererContract = File(assets, "R48-Canonical-Style-Tokens.json")
            .reader(Charsets.UTF_8).use(LockedPdfRendererContractLoader::load)
        check(rendererContract.widthPt == 768.0)
        check(rendererContract.heightPt == 480.5)
        check(rendererContract.layoutModes.size == 4)
        check(rendererContract.styleTokenProvenanceRequired)

        val current = kb.assignments.values.filter { !it.needsNewCard }
        check(current.size == 219)
        current.forEach { assignment ->
            val authorization = PdfArtifactBoundary.authorizeExactApprovedPassthrough(
                kb = kb,
                displayId = assignment.displayId,
                fileName = assignment.canonicalFilename,
                artifactSha256 = assignment.referenceSha256
            )
            check(authorization.action == PdfArtifactAction.EXACT_APPROVED_PASSTHROUGH) { assignment.displayId }
            check(!authorization.renderAllowed) { "${assignment.displayId} must not silently rebuild" }
            check(authorization.fieldReleaseState == PdfFieldReleaseState.ALLOWED)
            check(authorization.expectedSha256 == assignment.referenceSha256)
        }

        kb.needsNewCardQueue.keys.forEach { displayId ->
            val assignment = kb.assignments.getValue(displayId)
            val legacy = PdfArtifactBoundary.authorizeExactApprovedPassthrough(
                kb = kb,
                displayId = displayId,
                fileName = assignment.canonicalFilename,
                artifactSha256 = assignment.referenceSha256
            )
            check(legacy.action == PdfArtifactAction.BLOCKED) { "$displayId legacy PDF unexpectedly releasable" }
            check(legacy.fieldReleaseState == PdfFieldReleaseState.BLOCKED)
        }

        val a300a = kb.assignments.getValue("A300a")
        check(exactApprovedFixture.isFile)
        val exactBytes = exactApprovedFixture.readBytes()
        val exactHash = exactApprovedFixture.inputStream().use(BundleIntegrity::sha256)
        check(exactHash == a300a.referenceSha256) { "A300a regression fixture hash mismatch" }
        val exactAuth = PdfArtifactBoundary.authorizeExactApprovedPassthrough(
            kb, "A300a", a300a.canonicalFilename, exactHash
        )
        val copied = ByteArrayOutputStream()
        val copiedHash = ExactApprovedPdfPassthrough.copyVerified(
            exactAuth,
            ByteArrayInputStream(exactBytes),
            copied
        )
        check(copiedHash == exactHash)
        check(copied.toByteArray().contentEquals(exactBytes)) { "Exact-approved passthrough changed bytes" }

        val mutated = exactBytes.copyOf().also { it[it.lastIndex] = (it.last().toInt() xor 0x01).toByte() }
        val mutatedHash = ByteArrayInputStream(mutated).use(BundleIntegrity::sha256)
        val badAuth = PdfArtifactBoundary.authorizeExactApprovedPassthrough(
            kb, "A300a", a300a.canonicalFilename, mutatedHash
        )
        check(badAuth.action == PdfArtifactAction.BLOCKED)
        check(runCatching {
            ExactApprovedPdfPassthrough.copyVerified(exactAuth, ByteArrayInputStream(mutated), ByteArrayOutputStream())
        }.isFailure) { "Mutated exact-approved PDF unexpectedly passed byte-copy verification" }

        val reserved = kb.needsNewCardQueue.keys.first()
        val validReceipt = validCandidateReceipt(kb, reserved)
        val candidate = PdfArtifactBoundary.authorizeCandidateRender(kb, validReceipt)
        check(candidate.action == PdfArtifactAction.VALIDATED_CANDIDATE_RENDER)
        check(candidate.renderAllowed)
        check(candidate.fieldReleaseState == PdfFieldReleaseState.AWAITING_EXPLICIT_USER_APPROVAL)

        val gateMutations = listOf<(CandidateRenderValidationReceipt) -> CandidateRenderValidationReceipt>(
            { it.copy(sourceTruthPassed = false) },
            { it.copy(liveGeometryVerificationPassed = false) },
            { it.copy(topologyOverlapPassed = false) },
            { it.copy(buildingValidationPassed = false) },
            { it.copy(labelValidationPassed = false) },
            { it.copy(rendererSha256 = "0".repeat(64)) },
            { it.copy(assignmentAuthorityRole = "legacy_assignment_reference_needs_new_card") }
        )
        gateMutations.forEachIndexed { index, mutate ->
            val blocked = PdfArtifactBoundary.authorizeCandidateRender(kb, mutate(validReceipt))
            check(blocked.action == PdfArtifactAction.BLOCKED) { "Candidate render mutation $index unexpectedly passed" }
        }

        val approvedRebuild = PdfArtifactBoundary.authorizeCandidateRender(
            kb,
            validCandidateReceipt(kb, "A300a")
        )
        check(approvedRebuild.action == PdfArtifactAction.BLOCKED) { "Approved exact artifact silently entered renderer path" }

        val candidateArtifact = CandidatePdfArtifactReceipt(
            displayId = reserved,
            canonicalFilename = kb.assignments.getValue(reserved).canonicalFilename,
            pdfSha256 = "a".repeat(64),
            renderValidation = validReceipt
        )
        val unapproved = PdfArtifactBoundary.authorizeCandidateRelease(
            kb,
            candidateArtifact,
            CandidateReleaseReview(
                reviewedPdfSha256 = candidateArtifact.pdfSha256,
                finalPdfValidatorsPassed = true,
                mandatoryReviewPassed = true,
                explicitUserApproval = false,
                approvalRecordedInAuthorityLayer = false
            )
        )
        check(unapproved.fieldReleaseState == PdfFieldReleaseState.AWAITING_EXPLICIT_USER_APPROVAL)

        val approvedButNotPromoted = PdfArtifactBoundary.authorizeCandidateRelease(
            kb,
            candidateArtifact,
            CandidateReleaseReview(
                reviewedPdfSha256 = candidateArtifact.pdfSha256,
                finalPdfValidatorsPassed = true,
                mandatoryReviewPassed = true,
                explicitUserApproval = true,
                approvalRecordedInAuthorityLayer = true
            )
        )
        check(approvedButNotPromoted.fieldReleaseState == PdfFieldReleaseState.BLOCKED)
        check(approvedButNotPromoted.reason.contains("promoted"))
    }

    private fun validCandidateReceipt(kb: TerritoryKnowledgeBase, displayId: String): CandidateRenderValidationReceipt {
        val assignment = kb.assignments.getValue(displayId)
        return CandidateRenderValidationReceipt(
            displayId = displayId,
            canonicalFilename = assignment.canonicalFilename,
            knowledgeBaseRevision = kb.revision,
            assignmentAuthorityRole = "current_authoritative_assignment",
            assignmentAuthoritySha256 = "b".repeat(64),
            sourceTruthPassed = true,
            liveGeometryVerificationPassed = true,
            topologyOverlapPassed = true,
            buildingValidationPassed = true,
            labelValidationPassed = true,
            styleTokenSha256 = LockedPdfRendererAuthorityHashes.STYLE_TOKENS_SHA256,
            templatePdfSha256 = LockedPdfRendererAuthorityHashes.TEMPLATE_PDF_SHA256,
            rendererSha256 = LockedPdfRendererAuthorityHashes.RENDERER_SHA256,
            rendererContractSha256 = LockedPdfRendererAuthorityHashes.CONTRACT_SHA256,
            directionsBadgeSha256 = LockedPdfRendererAuthorityHashes.DIRECTIONS_BADGE_SHA256
        )
    }
}
