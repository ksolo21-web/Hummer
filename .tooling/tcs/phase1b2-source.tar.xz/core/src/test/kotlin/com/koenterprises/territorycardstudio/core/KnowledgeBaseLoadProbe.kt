package com.koenterprises.territorycardstudio.core

import java.io.File

fun main(args: Array<String>) {
    require(args.size == 1)
    val kb = File(args[0], "Territory-Knowledge-Base.json").reader(Charsets.UTF_8).use(TerritoryKnowledgeBaseLoader::load)
    println("PASS KB load probe assignments=${kb.assignments.size} roads=${kb.assignments.values.sumOf { it.roads.size }} buildings=${kb.assignments.values.sumOf { it.buildings.size }}")
}
