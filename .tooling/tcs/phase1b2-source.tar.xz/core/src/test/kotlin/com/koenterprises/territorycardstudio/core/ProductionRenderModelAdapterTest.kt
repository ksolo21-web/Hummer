package com.koenterprises.territorycardstudio.core

import java.io.File
import java.security.MessageDigest

object ProductionRenderModelAdapterTest {
    fun run(kb: TerritoryKnowledgeBase, assets: File) {
        val policy = File(assets, "Online-Source-Policy.json").reader(Charsets.UTF_8).use(OnlineSourcePolicyLoader::load)
        val approvedRegression = kb.assignments.getValue("273")
        check(!approvedRegression.needsNewCard)
        val authoritySha = approvedRegression.sourceHashes.first()

        val roads = listOf(
            RoadGeometry(
                segmentId = "adapter-alpha",
                name = "Alpha Rd",
                normalizedName = "alpha rd",
                status = "yellow",
                role = "perimeter",
                insideSide = "left",
                accessOnly = false,
                endpointAKind = "junction",
                endpointBKind = "junction",
                widthPt = 4.0,
                points = listOf(Point2D(225.0, 115.0), Point2D(650.0, 115.0))
            ),
            RoadGeometry(
                segmentId = "adapter-beta",
                name = "Beta Dr",
                normalizedName = "beta dr",
                status = "green",
                role = "interior",
                insideSide = "",
                accessOnly = false,
                endpointAKind = "termination",
                endpointBKind = "termination",
                widthPt = 4.0,
                points = listOf(Point2D(225.0, 200.0), Point2D(650.0, 200.0))
            ),
            RoadGeometry(
                segmentId = "adapter-gamma",
                name = "Gamma Ct",
                normalizedName = "gamma ct",
                status = "red",
                role = "excluded",
                insideSide = "",
                accessOnly = false,
                endpointAKind = "termination",
                endpointBKind = "termination",
                widthPt = 4.0,
                points = listOf(Point2D(225.0, 285.0), Point2D(650.0, 285.0))
            )
        )
        val state = CurrentAuthoritativeAssignmentState(
            displayId = approvedRegression.displayId,
            identity = approvedRegression.identity,
            canonicalFilename = approvedRegression.canonicalFilename,
            knowledgeBaseRevision = kb.revision,
            authorityRole = "current_authoritative_assignment",
            authoritySha256 = authoritySha,
            sourceMasterLabel = "SYNTHETIC-RENDER-MODEL-ADAPTER",
            locality = "Oakland Township",
            updated = "9/25/2026",
            directionsLines = listOf(
                "Directions: Synthetic render-model adapter regression.",
                "No geography or assignment authority is certified.",
                "NOT FOR FIELD USE."
            ),
            layoutMode = "full_map",
            housingType = approvedRegression.housingType,
            coordinateSpace = RenderCoordinateSpace.LOCKED_R48_PAGE_POINTS_TOP_ORIGIN,
            roads = roads,
            buildings = emptyList()
        )
        val sourceTruth = CandidateSourceTruthState(
            sourceTerritoryDisplayId = state.displayId,
            assignmentAuthoritySourceSha256 = authoritySha,
            lockedAssignmentReconciled = true,
            missingExpectedSegmentCount = 0,
            unexpectedMeaningChangingSegmentCount = 0,
            assignmentColorConflictCount = 0,
            unresolvedPerimeterWorkedSideCount = 0,
            illegalMidSegmentColorTransitionCount = 0,
            unresolvedBuildingSiteCount = 0,
            crossTerritoryInferenceUsed = false,
            styleOnlyGeographyUsed = false
        )
        val topology = TopologyOverlapDecisionEngine.topologySignature(roads)
        val topologyValidation = TopologyOverlapDecisionEngine.validateIntersectionColorRoles(roads)
        check(topologyValidation.passed)
        val overlap = TopologyOverlapDecisionEngine.crossTerritoryOverlapCheck(state.identity, topology, kb)
        check(overlap.passed && overlap.reviewCandidateCount == 0)
        val request = LiveGeometryVerificationRequestFactory.create(
            kb = kb,
            policy = policy,
            displayId = state.displayId,
            candidateSourceSha256 = authoritySha,
            candidateTopology = topology,
            candidateBuildingMemberIds = emptyList(),
            sourceTruth = sourceTruth,
            jurisdiction = VerificationJurisdiction("Oakland County", "Michigan", "United States")
        )
        val targetIds = request.roadTargets.mapTo(linkedSetOf()) { it.targetId }
        val evidence = listOf(
            roadEvidence("oakland_county_roads", request, targetIds),
            roadEvidence("census_tigerweb_transportation", request, targetIds)
        )
        val decision = LiveGeometryVerificationReconciler.reconcile(request, policy, evidence)
        check(decision.renderable)
        val liveResult = LiveVerificationExecutionResult(
            requestFingerprint = request.requestFingerprint,
            evidence = evidence,
            decision = decision,
            events = emptyList()
        )
        val labels = listOf(
            label("adapter-label-alpha", roads[0], authoritySha, 330.0, 108.0, territoryFacing = "south", exterior = "north"),
            label("adapter-label-beta", roads[1], authoritySha, 330.0, 193.0),
            label("adapter-label-gamma", roads[2], authoritySha, 330.0, 278.0)
        )
        val buildingReport = BuildingValidationEngine.validateBuildings(emptyList(), applicable = false)
        val input = ProductionRenderModelInput(
            assignment = state,
            sourceTruth = sourceTruth,
            liveRequest = request,
            liveResult = liveResult,
            topologySignature = topology,
            topologyValidation = topologyValidation,
            overlapDecision = overlap,
            buildingValidation = buildingReport,
            labels = labels
        )

        val first = ProductionRenderModelAdapter.adaptNonFieldFixture(kb, input)
        val second = ProductionRenderModelAdapter.adaptNonFieldFixture(kb, input)
        check(first is RenderModelAdaptationResult.Renderable) { (first as RenderModelAdaptationResult.Blocked).reasons.joinToString() }
        check(second is RenderModelAdaptationResult.Renderable)
        check(first.inputSha256 == second.inputSha256) { "Adapter input hash is not deterministic" }
        check(first.renderSpecSha256 == second.renderSpecSha256) { "Adapter output hash is not deterministic" }
        check(first.assignmentStateSha256 == state.canonicalSha256())
        check(first.renderSpec.nonFieldFixture)
        check(first.renderSpec.roads.size == 3)
        check(first.renderSpec.labels.size == 3)
        check(first.renderSpec.roads.map { it.status } == listOf(
            PdfRoadStatus.WORK_INSIDE_ONLY,
            PdfRoadStatus.WORK_BOTH_SIDES,
            PdfRoadStatus.DO_NOT_WORK
        ))
        check(first.validationReceipt.assignmentAuthorityRole == "current_authoritative_assignment")
        check(first.validationReceipt.assignmentAuthoritySha256 == authoritySha)

        val template = File(assets, "render-authority/Canonical-New-Designed-Template-R48.pdf").readBytes()
        val rendered = CandidatePdfRenderer.renderNonFieldFixture(template, first.renderSpec)
        check(rendered.exactValidation.passed)
        check(rendered.renderSpecSha256 == first.renderSpecSha256)

        val betaDirect = labels[1]
        val betaBounds = AxisAlignedRect(535.0, 264.0, 605.0, 274.0)
        val betaDetailLabel = betaDirect.copy(
            baselineX = 535.0,
            baselineTopY = 273.0,
            placement = betaDirect.placement.copy(
                mode = LabelPlacementMode.DEDICATED_DETAIL,
                center = betaBounds.center,
                bounds = betaBounds,
                requiresReview = false,
                reviewNote = null
            )
        )
        val detailGeometry = VerifiedDedicatedDetailGeometry(
            detailId = "detail-beta",
            sourceBounds = AxisAlignedRect(215.0, 185.0, 275.0, 215.0),
            destinationBounds = AxisAlignedRect(440.0, 215.0, 700.0, 345.0),
            sourceSegmentIds = listOf("adapter-beta"),
            renderedRoads = listOf(roads[1].copy(points = listOf(Point2D(485.0, 280.0), Point2D(655.0, 280.0)))),
            labelIds = listOf(betaDetailLabel.labelId)
        )
        val detailInput = input.copy(
            labels = listOf(labels[0], betaDetailLabel, labels[2]),
            dedicatedDetails = listOf(detailGeometry)
        )
        val detailAdapted = ProductionRenderModelAdapter.adaptNonFieldFixture(kb, detailInput)
        check(detailAdapted is RenderModelAdaptationResult.Renderable) {
            (detailAdapted as RenderModelAdaptationResult.Blocked).reasons.joinToString()
        }
        check(detailAdapted.renderSpec.dedicatedDetails.size == 1)
        check(detailAdapted.renderSpec.labels.size == 2)
        val detailRendered = CandidatePdfRenderer.renderNonFieldFixture(template, detailAdapted.renderSpec)
        check(detailRendered.exactValidation.passed)
        check(detailRendered.renderSpecSha256 == detailAdapted.renderSpecSha256)
        expectBlocked(kb, detailInput.copy(dedicatedDetails = listOf(detailGeometry.copy(labelIds = listOf("missing-label")))), "unknown detail label")
        expectBlocked(kb, detailInput.copy(dedicatedDetails = listOf(detailGeometry.copy(renderedRoads = detailGeometry.renderedRoads.map { it.copy(status = "red") }))), "meaning drift")
        expectBlocked(kb, detailInput.copy(dedicatedDetails = listOf(detailGeometry.copy(destinationBounds = AxisAlignedRect(430.0, 215.0, 750.0, 345.0)))), "destination bounds escape")

        // Phase 1B-1: split_detail must be carried only with explicit locked panel geometry.
        val splitRoads = listOf(
            RoadGeometry(
                segmentId = "split-north", name = "Zeta North Rd", normalizedName = "zeta north rd", status = "green",
                role = "interior", insideSide = "", accessOnly = false, endpointAKind = "termination", endpointBKind = "termination",
                widthPt = 4.0, points = listOf(Point2D(195.0, 105.0), Point2D(330.0, 105.0))
            ),
            RoadGeometry(
                segmentId = "split-south", name = "Zeta South Ln", normalizedName = "zeta south ln", status = "yellow",
                role = "perimeter", insideSide = "left", accessOnly = false, endpointAKind = "termination", endpointBKind = "termination",
                widthPt = 4.0, points = listOf(Point2D(195.0, 270.0), Point2D(330.0, 270.0))
            )
        )
        val splitState = state.copy(layoutMode = "split_detail", roads = splitRoads, buildings = emptyList())
        val splitTopology = TopologyOverlapDecisionEngine.topologySignature(splitRoads)
        val splitTopologyValidation = TopologyOverlapDecisionEngine.validateIntersectionColorRoles(splitRoads)
        check(splitTopologyValidation.passed)
        val splitOverlap = TopologyOverlapDecisionEngine.crossTerritoryOverlapCheck(splitState.identity, splitTopology, kb)
        check(splitOverlap.passed && splitOverlap.reviewCandidateCount == 0)
        val splitRequest = LiveGeometryVerificationRequestFactory.create(
            kb = kb,
            policy = policy,
            displayId = splitState.displayId,
            candidateSourceSha256 = authoritySha,
            candidateTopology = splitTopology,
            candidateBuildingMemberIds = emptyList(),
            sourceTruth = sourceTruth,
            jurisdiction = VerificationJurisdiction("Oakland County", "Michigan", "United States")
        )
        val splitTargetIds = splitRequest.roadTargets.mapTo(linkedSetOf()) { it.targetId }
        val splitEvidence = listOf(
            roadEvidence("oakland_county_roads", splitRequest, splitTargetIds),
            roadEvidence("census_tigerweb_transportation", splitRequest, splitTargetIds)
        )
        val splitDecision = LiveGeometryVerificationReconciler.reconcile(splitRequest, policy, splitEvidence)
        check(splitDecision.renderable)
        val splitLiveResult = LiveVerificationExecutionResult(splitRequest.requestFingerprint, splitEvidence, splitDecision, emptyList())
        val splitLabels = listOf(
            label("split-north-base", splitRoads[0], authoritySha, 215.0, 98.0),
            label("split-south-base", splitRoads[1], authoritySha, 215.0, 263.0, territoryFacing = "north", exterior = "south"),
            label("split-north-detail", splitRoads[0], authoritySha, 500.0, 103.0),
            label("split-south-detail", splitRoads[1], authoritySha, 500.0, 288.0, territoryFacing = "north", exterior = "south")
        )
        val splitGeometry = VerifiedSplitDetailGeometry(
            fullMapRect = AxisAlignedRect(176.0, 20.0, 350.0, 365.0),
            rightRect = AxisAlignedRect(357.0, 20.0, 748.0, 365.0),
            dividerX = 350.0,
            detailDividerY = 228.0,
            northDetailRect = AxisAlignedRect(357.0, 20.0, 748.0, 228.0),
            southDetailRect = AxisAlignedRect(357.0, 228.0, 748.0, 365.0),
            northPanel = VerifiedSplitDetailPanelGeometry(
                panelId = "north-panel",
                sourceBounds = AxisAlignedRect(185.0, 80.0, 340.0, 130.0),
                destinationBounds = AxisAlignedRect(357.0, 20.0, 748.0, 228.0),
                sourceSegmentIds = listOf("split-north"),
                renderedRoads = listOf(splitRoads[0].copy(points = listOf(Point2D(395.0, 110.0), Point2D(700.0, 110.0)))),
                labelIds = listOf("split-north-detail")
            ),
            southPanel = VerifiedSplitDetailPanelGeometry(
                panelId = "south-panel",
                sourceBounds = AxisAlignedRect(185.0, 245.0, 340.0, 295.0),
                destinationBounds = AxisAlignedRect(357.0, 228.0, 748.0, 365.0),
                sourceSegmentIds = listOf("split-south"),
                renderedRoads = listOf(splitRoads[1].copy(points = listOf(Point2D(395.0, 295.0), Point2D(700.0, 295.0)))),
                labelIds = listOf("split-south-detail")
            )
        )
        val splitInput = ProductionRenderModelInput(
            assignment = splitState,
            sourceTruth = sourceTruth,
            liveRequest = splitRequest,
            liveResult = splitLiveResult,
            topologySignature = splitTopology,
            topologyValidation = splitTopologyValidation,
            overlapDecision = splitOverlap,
            buildingValidation = BuildingValidationEngine.validateBuildings(emptyList(), applicable = false),
            labels = splitLabels,
            splitDetail = splitGeometry
        )
        val splitAdapted = ProductionRenderModelAdapter.adaptNonFieldFixture(kb, splitInput)
        check(splitAdapted is RenderModelAdaptationResult.Renderable) {
            (splitAdapted as RenderModelAdaptationResult.Blocked).reasons.joinToString()
        }
        check(splitAdapted.renderSpec.layoutMode == "split_detail")
        check(splitAdapted.renderSpec.splitDetail != null)
        check(splitAdapted.renderSpec.labels.size == 2) { "Panel-owned labels leaked into split full-map region" }
        val splitRendered = CandidatePdfRenderer.renderNonFieldFixture(template, splitAdapted.renderSpec)
        check(splitRendered.exactValidation.passed)
        check(splitRendered.renderSpecSha256 == splitAdapted.renderSpecSha256)
        expectBlocked(kb, splitInput.copy(splitDetail = null), "split_detail requires mode-specific verified geometry")
        expectBlocked(kb, splitInput.copy(splitDetail = splitGeometry.copy(dividerX = 349.0)), "divider_x")
        expectBlocked(
            kb,
            splitInput.copy(splitDetail = splitGeometry.copy(southPanel = splitGeometry.southPanel.copy(sourceSegmentIds = listOf("split-north")))),
            "ambiguous region ownership"
        )
        expectBlocked(
            kb,
            splitInput.copy(splitDetail = splitGeometry.copy(northPanel = splitGeometry.northPanel.copy(renderedRoads = splitGeometry.northPanel.renderedRoads.map { it.copy(status = "red") }))),
            "meaning drift"
        )
        expectBlocked(
            kb,
            splitInput.copy(splitDetail = splitGeometry.copy(northPanel = splitGeometry.northPanel.copy(renderedRoads = splitGeometry.northPanel.renderedRoads.map { it.copy(points = listOf(Point2D(360.0, 110.0), Point2D(760.0, 110.0))) }))),
            "escapes destination region"
        )

        // Phase 1B-2: full_plus_detail uses one explicit main-context rect and one exact mapped detail rect.
        val fpState = splitState.copy(layoutMode = "full_plus_detail")
        val fpSource = AxisAlignedRect(185.0, 80.0, 340.0, 130.0)
        val fpDest = AxisAlignedRect(515.0, 70.0, 747.0, 330.0)
        fun fpx(x: Double) = fpDest.left + (x - fpSource.left) * fpDest.width / fpSource.width
        fun fpy(y: Double) = fpDest.top + (y - fpSource.top) * fpDest.height / fpSource.height
        val fpLabels = listOf(
            label("fp-source", splitRoads[0], authoritySha, 215.0, 98.0),
            label("fp-context", splitRoads[1], authoritySha, 215.0, 263.0, territoryFacing = "north", exterior = "south"),
            label("fp-detail", splitRoads[0], authoritySha, fpx(215.0), fpy(98.0))
        )
        val fpGeometry = VerifiedFullPlusDetailGeometry(
            mainContextRect = AxisAlignedRect(176.0, 20.0, 500.0, 363.0),
            detail = VerifiedFullPlusDetailPanelGeometry(
                panelId = "full-plus-detail-panel",
                sourceBounds = fpSource,
                destinationBounds = fpDest,
                sourceSegmentIds = listOf("split-north"),
                sourceLabelIds = listOf("fp-source"),
                detailLabelIds = listOf("fp-detail"),
                renderedRoads = listOf(
                    splitRoads[0].copy(points = splitRoads[0].points.map { Point2D(fpx(it.x), fpy(it.y)) })
                )
            )
        )
        val fpInput = splitInput.copy(
            assignment = fpState,
            labels = fpLabels,
            splitDetail = null,
            fullPlusDetail = fpGeometry
        )
        val fpAdapted = ProductionRenderModelAdapter.adaptNonFieldFixture(kb, fpInput)
        check(fpAdapted is RenderModelAdaptationResult.Renderable) {
            (fpAdapted as RenderModelAdaptationResult.Blocked).reasons.joinToString()
        }
        check(fpAdapted.renderSpec.layoutMode == "full_plus_detail")
        check(fpAdapted.renderSpec.fullPlusDetail != null)
        check(fpAdapted.renderSpec.labels.map { it.labelId }.toSet() == setOf("fp-source", "fp-context")) { "full_plus_detail detail label leaked into main context" }
        val fpRendered = CandidatePdfRenderer.renderNonFieldFixture(template, fpAdapted.renderSpec)
        check(fpRendered.exactValidation.passed)
        check(fpRendered.renderSpecSha256 == fpAdapted.renderSpecSha256)
        expectBlocked(kb, fpInput.copy(fullPlusDetail = null), "full_plus_detail requires mode-specific verified geometry")
        expectBlocked(kb, fpInput.copy(fullPlusDetail = fpGeometry.copy(mainContextRect = AxisAlignedRect(176.0, 20.0, 540.0, 363.0))), "rectangles collide")
        expectBlocked(
            kb,
            fpInput.copy(fullPlusDetail = fpGeometry.copy(detail = fpGeometry.detail.copy(renderedRoads = fpGeometry.detail.renderedRoads.map { it.copy(status = "red") }))),
            "road meaning/status drift"
        )
        expectBlocked(
            kb,
            fpInput.copy(fullPlusDetail = fpGeometry.copy(detail = fpGeometry.detail.copy(renderedRoads = fpGeometry.detail.renderedRoads.map { road -> road.copy(points = road.points.mapIndexed { i, p -> if (i == 0) Point2D(p.x + 2.0, p.y) else p }) }))),
            "source-to-destination mapping"
        )
        expectBlocked(
            kb,
            fpInput.copy(fullPlusDetail = fpGeometry.copy(detail = fpGeometry.detail.copy(sourceLabelIds = listOf("missing-source-label")))),
            "unknown source label"
        )

        val approvedProduction = ProductionRenderModelAdapter.adaptProduction(kb, input)
        check(approvedProduction is RenderModelAdaptationResult.Blocked)
        check(approvedProduction.reasons.any { "exact-artifact passthrough" in it })

        expectBlocked(kb, input.copy(sourceTruth = sourceTruth.copy(crossTerritoryInferenceUsed = true)), "cross-territory geography")
        expectBlocked(
            kb,
            input.copy(
                liveResult = liveResult.copy(
                    decision = decision.copy(disposition = LiveVerificationDisposition.BLOCKED, renderable = false, blockedReasons = listOf("fixture block"))
                )
            ),
            "live geometry verification is not renderable"
        )
        expectBlocked(
            kb,
            input.copy(
                topologyValidation = topologyValidation.copy(passed = false, failures = listOf("synthetic topology failure"))
            ),
            "topology/color validation output drift"
        )
        expectBlocked(
            kb,
            input.copy(
                overlapDecision = overlap.copy(
                    reviewCandidates = listOf(CandidateOverlapFinding("alpha rd", "999", "medium", reason = "synthetic unresolved review"))
                )
            ),
            "overlap output is not bound to current assignment topology"
        )
        expectBlocked(
            kb,
            input.copy(overlapDecision = overlap.copy(status = "FORGED_PASS")),
            "overlap output is not bound to current assignment topology"
        )
        val wrongLock = labels.first().copy(
            placement = labels.first().placement.copy(
                navigationLock = labels.first().placement.navigationLock.copy(sourceSha256 = sha256("wrong-authority"))
            )
        )
        expectBlocked(kb, input.copy(labels = listOf(wrongLock) + labels.drop(1)), "not bound to current assignment authority")
        val curved = labels[1].copy(placement = labels[1].placement.copy(mode = LabelPlacementMode.CURVED_ROAD_FOLLOWING))
        expectBlocked(kb, input.copy(labels = listOf(labels[0], curved, labels[2])), "curved label lacks verified side evidence")
        expectBlocked(kb, input.copy(assignment = state.copy(authorityRole = "legacy_reference")), "current_authoritative_assignment evidence is required")
        expectBlocked(kb, input.copy(assignment = state.copy(layoutMode = "split_detail")), "requires mode-specific verified geometry")

        val incompleteLabels = input.copy(labels = labels.dropLast(1))
        expectBlocked(kb, incompleteLabels, "missing labels for visible named roads")

        println("PASS production render-model adapter")
        println("adapter_input_sha256=${first.inputSha256}")
        println("adapter_output_spec_sha256=${first.renderSpecSha256}")
        println("adapter_non_field_pdf_sha256=${rendered.pdfSha256}")
        println("adapter_fail_closed_mutations=23")
    }

    private fun label(
        id: String,
        road: RoadGeometry,
        authoritySha: String,
        baselineX: Double,
        baselineTopY: Double,
        territoryFacing: String? = null,
        exterior: String? = null
    ): VerifiedLabelRenderOutput {
        val lock = LabelNavigationLock(
            labelId = id,
            streetName = road.name,
            navigationRole = if (road.role == "perimeter") "perimeter_run" else "road_run",
            segmentId = road.segmentId,
            sourceEvidence = "synthetic current-authority adapter fixture",
            sourceSha256 = authoritySha,
            territoryFacingSide = territoryFacing,
            exteriorSide = exterior
        )
        val bounds = AxisAlignedRect(baselineX, baselineTopY - 9.0, baselineX + 70.0, baselineTopY + 1.0)
        val placement = LabelPlacement(
            mode = LabelPlacementMode.DIRECT_ROAD_FOLLOWING,
            center = bounds.center,
            angleDeg = 0.0,
            bounds = bounds,
            roadGapGeometryUnits = 3.0,
            sourceSegmentIndex = 0,
            navigationLock = lock,
            requiresReview = false
        )
        return VerifiedLabelRenderOutput(
            labelId = id,
            segmentId = road.segmentId,
            text = road.name,
            baselineX = baselineX,
            baselineTopY = baselineTopY,
            rotationDegrees = 0.0,
            fontSizePt = 9.0,
            assignedRoadGapPx = 3.0,
            scale = LabelLayoutScale(1.0),
            placement = placement
        )
    }

    private fun roadEvidence(
        providerId: String,
        request: LiveGeometryVerificationRequest,
        targetIds: Set<String>
    ) = ProviderVerificationEvidence(
        providerId = providerId,
        requestFingerprint = request.requestFingerprint,
        available = true,
        observedAtUtc = "2026-09-25T16:00:00Z",
        responseSha256 = sha256("$providerId|${request.requestFingerprint}"),
        sourceDataVintage = null,
        queriedTargetIds = targetIds,
        confirmedTargetIds = targetIds,
        notFoundTargetIds = emptySet(),
        conflictingTargetIds = emptySet(),
        unknownMeaningChangingRoads = emptySet(),
        siteAddressCrosscheckPassed = null,
        buildingOutlineCrosscheckPassed = null,
        errorCode = null
    )

    private fun expectBlocked(kb: TerritoryKnowledgeBase, input: ProductionRenderModelInput, message: String) {
        val result = ProductionRenderModelAdapter.adaptNonFieldFixture(kb, input)
        check(result is RenderModelAdaptationResult.Blocked) { "Expected adapter block containing '$message'" }
        check(result.reasons.any { message in it }) { "Adapter block did not contain '$message': ${result.reasons}" }
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
