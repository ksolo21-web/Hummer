package com.koenterprises.territorycardstudio.core

import java.io.File

fun main(args: Array<String>) {
    require(args.size == 2) { "usage: CurvedCalloutFixtureGenerator ASSETS_DIR OUTPUT.pdf" }
    val assets = File(args[0])
    val output = File(args[1])
    val template = File(assets, "render-authority/Canonical-New-Designed-Template-R48.pdf").readBytes()
    val result = CandidatePdfRenderer.renderNonFieldFixture(template, CandidatePdfRendererTest.curvedCalloutFixtureSpec())
    output.parentFile?.mkdirs()
    output.writeBytes(result.pdfBytes)
    println("pdf=${output.absolutePath}")
    println("bytes=${result.pdfBytes.size}")
    println("spec_sha256=${result.renderSpecSha256}")
    println("pdf_sha256=${result.pdfSha256}")
    println("validation_passed=${result.exactValidation.passed}")
}
