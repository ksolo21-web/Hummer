package com.koenterprises.territorycardstudio.core

import java.io.File
import java.security.MessageDigest
import java.time.Clock
import java.time.Instant
import java.time.ZoneId

object LiveVerificationExecutionPipelineTest {
    fun run(kb: TerritoryKnowledgeBase, assets: File) {
        val policy = File(assets, "Online-Source-Policy.json").reader(Charsets.UTF_8).use(OnlineSourcePolicyLoader::load)
        val jurisdiction = VerificationJurisdiction("Oakland County", "Michigan", "United States")
        val simple = requestFor(kb, policy, kb.assignments.getValue("253"), jurisdiction, emptyList())

        val successTransport = FixtureTransport()
        val success = pipeline(successTransport).verify(simple, policy, ProviderCacheMode.BYPASS)
        check(success.decision.renderable) { "Full live pipeline failed: ${success.decision.blockedReasons}" }
        check(success.decision.qualifyingGeometryProviders == listOf(
            "census_tigerweb_transportation",
            "oakland_county_roads",
            "openstreetmap_overpass"
        ))
        check(success.evidence.map { it.providerId }.toSet() == setOf(
            "oakland_county_roads", "census_tigerweb_transportation", "openstreetmap_overpass"
        ))
        check(successTransport.calls.size == 6) { "Expected 6 residential provider executions, got ${successTransport.calls.size}" }
        check(success.events.none { it.outcome != VerificationPipelineStageOutcome.SUCCEEDED })
        check(success.events.count { it.phase == VerificationPipelineEventPhase.EXECUTION } == 6)
        check(success.events.count { it.phase == VerificationPipelineEventPhase.PARSE_ASSEMBLY } == 4)
        check(success.events.all { it.bindingFingerprint == null || it.bindingFingerprint.matches(Regex("^[0-9a-f]{64}$")) })


        val cacheIntegrityCoordinator = ProviderExecutionCoordinator(
            transport = FixtureTransport(),
            cache = object : ProviderEvidenceCache {
                override fun read(plan: ProviderQueryPlan, rule: ProviderExecutionRule, now: Instant): ProviderRawResponse? {
                    throw ProviderCacheIntegrityException("fixture tamper")
                }
                override fun write(response: ProviderRawResponse, rule: ProviderExecutionRule) = Unit
            },
            clock = FixedClock(Instant.parse("2026-09-25T11:30:00Z")),
            sleeper = ProviderSleeper { },
            rateGate = ProviderRateGate()
        )
        check(runCatching {
            LiveVerificationExecutionPipeline(cacheIntegrityCoordinator).verify(simple, policy, ProviderCacheMode.READ_WRITE)
        }.exceptionOrNull() is ProviderCacheIntegrityException) {
            "Provider cache integrity failure was downgraded to ordinary source unavailability"
        }

        val malformedOaklandTransport = FixtureTransport(malformedOaklandRoads = true)
        val malformedOakland = pipeline(malformedOaklandTransport).verify(simple, policy, ProviderCacheMode.BYPASS)
        check(!malformedOakland.decision.renderable) { "Malformed Oakland primary response unexpectedly rendered" }
        val oaklandEvidence = malformedOakland.evidence.single { it.providerId == "oakland_county_roads" }
        check(!oaklandEvidence.available)
        check(oaklandEvidence.queriedTargetIds == simple.roadTargets.mapTo(linkedSetOf()) { it.targetId })
        check(oaklandEvidence.responseSha256 != null) { "Malformed 200 response lost audit digest" }
        check(malformedOakland.events.any {
            it.providerId == "oakland_county_roads" &&
                it.phase == VerificationPipelineEventPhase.EXECUTION &&
                it.outcome == VerificationPipelineStageOutcome.SUCCEEDED
        })
        check(malformedOakland.events.any {
            it.providerId == "oakland_county_roads" &&
                it.phase == VerificationPipelineEventPhase.PARSE_ASSEMBLY &&
                it.outcome == VerificationPipelineStageOutcome.FAILED
        }) { "Malformed 200 response did not produce a parse/assembly failure event" }
        check(malformedOakland.decision.blockedReasons.any { it.contains("Oakland County road GIS is required") })

        val badAreaTransport = FixtureTransport(malformedOsmArea = true)
        val badArea = pipeline(badAreaTransport).verify(simple, policy, ProviderCacheMode.BYPASS)
        check(badArea.decision.renderable) {
            "OSM failure should remain non-fatal when Oakland+Census satisfy the two-source policy: ${badArea.decision.blockedReasons}"
        }
        check(badAreaTransport.calls.none { it.stage == ProviderQueryStage.OSM_ROADS }) {
            "OSM road request executed after area-resolution failure"
        }
        check(badArea.events.any {
            it.providerId == "openstreetmap_overpass" &&
                it.stage == ProviderQueryStage.OSM_ROADS &&
                it.outcome == VerificationPipelineStageOutcome.SKIPPED_DEPENDENCY
        })
        check(badArea.decision.independentGeometrySourceCount == 2)


        val partialCensusTransport = FixtureTransport(failCensusLayer6 = true)
        val partialCensus = pipeline(partialCensusTransport).verify(simple, policy, ProviderCacheMode.BYPASS)
        val partialCensusEvidence = partialCensus.evidence.single { it.providerId == "census_tigerweb_transportation" }
        check(!partialCensusEvidence.available)
        check(partialCensusEvidence.observedAtUtc != null) { "Successful Census subresponse timestamp was discarded after later layer failure" }
        check(partialCensusEvidence.responseSha256 != null) { "Successful Census subresponse digest was discarded after later layer failure" }
        check(partialCensusTransport.calls.none { it.resourceId == "census-layer:8" }) { "Census pipeline continued after a required batch member failed" }
        check(partialCensus.decision.renderable) { "Oakland+OSM should satisfy geometry quorum when Census is unavailable" }

        val badSourceTruth = LiveGeometryVerificationRequestFactory.create(
            kb = kb,
            policy = policy,
            displayId = "253",
            candidateSourceSha256 = sha256("pipeline-bad-source-truth"),
            candidateTopology = requireNotNull(kb.assignments.getValue("253").topologySignature),
            candidateBuildingMemberIds = emptyList(),
            sourceTruth = CandidateSourceTruthState(
                sourceTerritoryDisplayId = "253",
                assignmentAuthoritySourceSha256 = kb.assignments.getValue("253").sourceHashes.first(),
                lockedAssignmentReconciled = false,
                missingExpectedSegmentCount = 1,
                unexpectedMeaningChangingSegmentCount = 0,
                assignmentColorConflictCount = 0,
                unresolvedPerimeterWorkedSideCount = 0,
                illegalMidSegmentColorTransitionCount = 0,
                unresolvedBuildingSiteCount = 0,
                crossTerritoryInferenceUsed = false,
                styleOnlyGeographyUsed = false
            ),
            jurisdiction = jurisdiction
        )
        val badSourceTransport = FixtureTransport()
        val badSource = pipeline(badSourceTransport).verify(badSourceTruth, policy, ProviderCacheMode.BYPASS)
        check(!badSource.decision.renderable)
        check(badSourceTransport.calls.isEmpty()) { "Live providers executed despite failed locked source-truth reconciliation" }
        check(badSource.evidence.isEmpty() && badSource.events.isEmpty())

        val apartmentAssignment = kb.assignments.getValue("A264")
        val apartmentMembers = requireNotNull(apartmentAssignment.assignmentSignature).buildingMemberIds
        val apartment = requestFor(kb, policy, apartmentAssignment, jurisdiction, apartmentMembers)
        check(apartment.siteAddressCrosscheckRequired && apartment.buildingOutlineCrosscheckRequired)
        val apartmentTransport = FixtureTransport(emptyRoads = true)
        val apartmentResult = pipeline(apartmentTransport).verify(apartment, policy, ProviderCacheMode.BYPASS)
        val siteEvidence = apartmentResult.evidence.single { it.providerId == "oakland_county_site_addresses" }
        val buildingEvidence = apartmentResult.evidence.single { it.providerId == "oakland_county_buildings" }
        check(siteEvidence.available && siteEvidence.siteAddressCrosscheckPassed == true)
        check(buildingEvidence.available && buildingEvidence.buildingOutlineCrosscheckPassed == true)
        val vintage = requireNotNull(buildingEvidence.sourceDataVintage)
        check(vintage.contains("2017"))
        check(vintage.contains("2022"))
        check(apartmentTransport.calls.any { it.stage == ProviderQueryStage.SITE_ADDRESS })
        check(apartmentTransport.calls.any { it.stage == ProviderQueryStage.BUILDING_OUTLINE })
        check(apartmentTransport.calls.any { it.stage == ProviderQueryStage.BUILDING_METADATA })
        check(apartmentResult.events.none {
            it.providerId == "oakland_county_buildings" && it.outcome == VerificationPipelineStageOutcome.SKIPPED_DEPENDENCY
        })
        check(!apartmentResult.decision.renderable) { "Empty road authorities unexpectedly rendered apartment candidate" }


        val failedMetadataTransport = FixtureTransport(emptyRoads = true, failBuildingMetadata = true)
        val failedMetadata = pipeline(failedMetadataTransport).verify(apartment, policy, ProviderCacheMode.BYPASS)
        val failedBuildingEvidence = failedMetadata.evidence.single { it.providerId == "oakland_county_buildings" }
        check(!failedBuildingEvidence.available)
        check(failedBuildingEvidence.observedAtUtc != null) { "Successful building-outline timestamp was discarded after metadata failure" }
        check(failedBuildingEvidence.responseSha256 != null) { "Successful building-outline digest was discarded after metadata failure" }
        check(failedMetadata.decision.buildingOutlineCrosscheckPassed == false)

        val failedSiteTransport = FixtureTransport(emptyRoads = true, malformedSiteAddresses = true)
        val failedSite = pipeline(failedSiteTransport).verify(apartment, policy, ProviderCacheMode.BYPASS)
        check(failedSiteTransport.calls.none { it.stage == ProviderQueryStage.BUILDING_OUTLINE || it.stage == ProviderQueryStage.BUILDING_METADATA }) {
            "Building providers executed after site-address dependency failed"
        }
        check(failedSite.evidence.single { it.providerId == "oakland_county_buildings" }.errorCode == "SITE_ADDRESS_DEPENDENCY_FAILED")
        check(failedSite.events.count {
            it.providerId == "oakland_county_buildings" && it.outcome == VerificationPipelineStageOutcome.SKIPPED_DEPENDENCY
        } == 2)

        val tampered = simple.copy(candidateSourceSha256 = sha256("tampered-candidate"))
        val tamperTransport = FixtureTransport()
        check(runCatching { pipeline(tamperTransport).verify(tampered, policy, ProviderCacheMode.BYPASS) }.isFailure) {
            "Tampered verification request entered provider execution"
        }
        check(tamperTransport.calls.isEmpty()) { "Provider execution started before request fingerprint validation" }
    }

    private fun pipeline(transport: FixtureTransport): LiveVerificationExecutionPipeline {
        val clock = FixedClock(Instant.parse("2026-09-25T11:30:00Z"))
        val coordinator = ProviderExecutionCoordinator(
            transport = transport,
            cache = NoProviderEvidenceCache,
            clock = clock,
            sleeper = ProviderSleeper { },
            rateGate = ProviderRateGate()
        )
        return LiveVerificationExecutionPipeline(coordinator)
    }

    private fun requestFor(
        kb: TerritoryKnowledgeBase,
        policy: OnlineSourcePolicy,
        assignment: KnowledgeBaseAssignment,
        jurisdiction: VerificationJurisdiction,
        members: List<String>
    ): LiveGeometryVerificationRequest = LiveGeometryVerificationRequestFactory.create(
        kb = kb,
        policy = policy,
        displayId = assignment.displayId,
        candidateSourceSha256 = sha256("pipeline-fixture:${assignment.displayId}"),
        candidateTopology = requireNotNull(assignment.topologySignature),
        candidateBuildingMemberIds = members,
        sourceTruth = CandidateSourceTruthState(
            sourceTerritoryDisplayId = assignment.displayId,
            assignmentAuthoritySourceSha256 = assignment.sourceHashes.first(),
            lockedAssignmentReconciled = true,
            missingExpectedSegmentCount = 0,
            unexpectedMeaningChangingSegmentCount = 0,
            assignmentColorConflictCount = 0,
            unresolvedPerimeterWorkedSideCount = 0,
            illegalMidSegmentColorTransitionCount = 0,
            unresolvedBuildingSiteCount = 0,
            crossTerritoryInferenceUsed = false,
            styleOnlyGeographyUsed = false
        ),
        jurisdiction = jurisdiction
    )

    private data class Call(val providerId: String, val stage: ProviderQueryStage, val resourceId: String)

    private class FixtureTransport(
        private val malformedOaklandRoads: Boolean = false,
        private val malformedOsmArea: Boolean = false,
        private val emptyRoads: Boolean = false,
        private val malformedSiteAddresses: Boolean = false,
        private val failCensusLayer6: Boolean = false,
        private val failBuildingMetadata: Boolean = false
    ) : ProviderTransport {
        val calls = mutableListOf<Call>()

        override fun execute(plan: ProviderQueryPlan, rule: ProviderExecutionRule): ProviderTransportResponse {
            calls += Call(plan.providerId, plan.stage, plan.resourceId)
            val status = when {
                failCensusLayer6 && plan.resourceId == "census-layer:6" -> 400
                failBuildingMetadata && plan.providerId == "oakland_county_buildings" && plan.stage == ProviderQueryStage.BUILDING_METADATA -> 400
                else -> 200
            }
            val body = when {
                plan.providerId == "oakland_county_roads" && malformedOaklandRoads -> "{malformed"
                plan.providerId == "oakland_county_roads" && emptyRoads -> arcGisRoadBody(emptyList())
                plan.providerId == "oakland_county_roads" -> oaklandRoads()
                plan.providerId == "census_tigerweb_transportation" && emptyRoads -> censusRoadBody(emptyList())
                plan.providerId == "census_tigerweb_transportation" && plan.resourceId == "census-layer:8" -> censusRoads()
                plan.providerId == "census_tigerweb_transportation" -> censusRoadBody(emptyList())
                plan.providerId == "openstreetmap_overpass" && plan.stage == ProviderQueryStage.OSM_AREA_LOOKUP && malformedOsmArea -> "[]"
                plan.providerId == "openstreetmap_overpass" && plan.stage == ProviderQueryStage.OSM_AREA_LOOKUP -> osmArea()
                plan.providerId == "openstreetmap_overpass" && plan.stage == ProviderQueryStage.OSM_ROADS && emptyRoads -> "{\"elements\":[]}"
                plan.providerId == "openstreetmap_overpass" && plan.stage == ProviderQueryStage.OSM_ROADS -> osmRoads()
                plan.providerId == "oakland_county_site_addresses" && malformedSiteAddresses -> "{malformed"
                plan.providerId == "oakland_county_site_addresses" -> siteAddresses()
                plan.providerId == "oakland_county_buildings" && plan.stage == ProviderQueryStage.BUILDING_OUTLINE -> buildingOutlines()
                plan.providerId == "oakland_county_buildings" && plan.stage == ProviderQueryStage.BUILDING_METADATA -> buildingMetadata()
                else -> error("No fixture response for ${plan.providerId}/${plan.stage}/${plan.resourceId}")
            }
            return ProviderTransportResponse(
                statusCode = status,
                body = body,
                headers = emptyMap(),
                observedAtUtc = "2026-09-25T11:30:00Z"
            )
        }
    }

    private fun oaklandRoads(): String = arcGisRoadBody(
        listOf(
            ArcRoad(1, "S Main St", "S", "Main", "St", listOf(-83.1400 to 42.6800, -83.1400 to 42.6810)),
            ArcRoad(2, "W University Dr", "W", "University", "Dr", listOf(-83.1410 to 42.6805, -83.1390 to 42.6805))
        )
    )

    private fun censusRoads(): String = censusRoadBody(
        listOf(
            CensusRoad(21, "S Main St", "Main", listOf(-83.1400 to 42.6800, -83.1400 to 42.6810)),
            CensusRoad(22, "W University Dr", "University", listOf(-83.1410 to 42.6805, -83.1390 to 42.6805))
        )
    )

    private fun osmArea(): String = """
        [
          {
            "osm_type":"relation",
            "osm_id":180107,
            "class":"boundary",
            "type":"administrative",
            "display_name":"Oakland County, Michigan, United States",
            "address":{"county":"Oakland County","state":"Michigan","country":"United States","country_code":"us"}
          }
        ]
    """.trimIndent()

    private fun osmRoads(): String = """
        {
          "elements":[
            {"type":"way","id":1001,"tags":{"highway":"primary","name":"S Main St"},"geometry":[{"lat":42.6800,"lon":-83.1400},{"lat":42.6810,"lon":-83.1400}]},
            {"type":"way","id":1002,"tags":{"highway":"secondary","name":"W University Dr"},"geometry":[{"lat":42.6805,"lon":-83.1410},{"lat":42.6805,"lon":-83.1390}]}
          ]
        }
    """.trimIndent()

    private fun siteAddresses(): String {
        val numbers = listOf(407, 409, 413, 415, 419, 421, 425, 427, 431, 433)
        val features = numbers.mapIndexed { index, number ->
            """{"attributes":{"OBJECTID":${index + 1},"PIN":"PIN${number}","SITESTREETNUMBER":$number,"SITEPREFIXONE":"","SITESTREETNAME":"Walton","SITESTREETTYPE":"Blvd","SITESUFFIXONE":"","SITESTREETADDRESS":"$number Walton Blvd"},"geometry":{"x":-83.${1400 + index},"y":42.${6800 + index}}}"""
        }
        return "{\"exceededTransferLimit\":false,\"features\":[${features.joinToString(",")}]}"
    }

    private fun buildingOutlines(): String {
        val numbers = listOf(407, 409, 413, 415, 419, 421, 425, 427, 431, 433)
        val features = numbers.mapIndexed { index, number ->
            val x = -83.14 - index * 0.0001
            val y = 42.68 + index * 0.0001
            """{"attributes":{"objectid":${index + 1},"keypin":"PIN${number}","status":"ACTIVE"},"geometry":{"rings":[[[$x,$y],[${x + 0.00002},$y],[${x + 0.00002},${y + 0.00002}],[$x,${y + 0.00002}],[$x,$y]]]}}"""
        }
        return "{\"exceededTransferLimit\":false,\"features\":[${features.joinToString(",")}]}"
    }

    private fun buildingMetadata(): String = """
        {"description":"Building footprints derived from 2017 imagery; dataset updated December 2022."}
    """.trimIndent()

    private data class ArcRoad(
        val id: Int,
        val cartographicName: String,
        val prefix: String,
        val streetName: String,
        val streetType: String,
        val path: List<Pair<Double, Double>>
    )

    private fun arcGisRoadBody(roads: List<ArcRoad>): String {
        val features = roads.joinToString(",") { road ->
            val coords = road.path.joinToString(",") { (x, y) -> "[$x,$y]" }
            """{"attributes":{"OBJECTID":${road.id},"DirectionalPrefix":"${road.prefix}","StreetName":"${road.streetName}","StreetType":"${road.streetType}","DirectionalSuffix":null,"CartographicName":"${road.cartographicName}","RevisionDate":null},"geometry":{"paths":[[$coords]]}}"""
        }
        return "{\"exceededTransferLimit\":false,\"features\":[$features]}"
    }

    private data class CensusRoad(
        val id: Int,
        val name: String,
        val baseName: String,
        val path: List<Pair<Double, Double>>
    )

    private fun censusRoadBody(roads: List<CensusRoad>): String {
        val features = roads.joinToString(",") { road ->
            val coords = road.path.joinToString(",") { (x, y) -> "[$x,$y]" }
            """{"attributes":{"OBJECTID":${road.id},"OID":${road.id},"NAME":"${road.name}","BASENAME":"${road.baseName}","MTFCC":"S1400"},"geometry":{"paths":[[$coords]]}}"""
        }
        return "{\"exceededTransferLimit\":false,\"features\":[$features]}"
    }

    private class FixedClock(private val fixed: Instant) : Clock() {
        override fun getZone(): ZoneId = ZoneId.of("UTC")
        override fun withZone(zone: ZoneId): Clock = this
        override fun instant(): Instant = fixed
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
