package com.koenterprises.territorycardstudio.core

import java.io.File

object CandidatePdfRendererTest {
    fun run(assets: File) {
        val template = File(assets, "render-authority/Canonical-New-Designed-Template-R48.pdf").readBytes()
        val spec = syntheticFixtureSpec()
        val first = CandidatePdfRenderer.renderNonFieldFixture(template, spec)
        val second = CandidatePdfRenderer.renderNonFieldFixture(template, spec)
        check(first.pdfBytes.contentEquals(second.pdfBytes)) { "Candidate PDF renderer is not byte-deterministic" }
        check(first.pdfSha256 == second.pdfSha256)
        check(first.renderSpecSha256 == spec.canonicalSha256())
        check(first.exactValidation.passed) { first.exactValidation.errors.joinToString() }
        check(first.pdfBytes.size in 1 until 300_000) { "Fixture PDF outside release-size ceiling: ${first.pdfBytes.size}" }
        check(first.pdfBytes.toString(Charsets.ISO_8859_1).contains("NOT FOR FIELD USE"))

        val mutatedTemplate = template.copyOf().also { it[64] = (it[64].toInt() xor 1).toByte() }
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(mutatedTemplate, spec) }.isFailure) {
            "Mutated locked template unexpectedly rendered"
        }
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, spec.copy(locality = "München")) }.isFailure) {
            "Non-ASCII text unexpectedly bypassed locked embedded-font gate"
        }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(
                template,
                spec.copy(labels = spec.labels.mapIndexed { i, l -> if (i == 0) l.copy(assignedRoadGapPx = 5.0) else l })
            )
        }.isFailure) { "5 px direct label gap unexpectedly rendered" }

        val complex = curvedCalloutFixtureSpec()
        val complexFirst = CandidatePdfRenderer.renderNonFieldFixture(template, complex)
        val complexSecond = CandidatePdfRenderer.renderNonFieldFixture(template, complex)
        check(complexFirst.pdfBytes.contentEquals(complexSecond.pdfBytes)) { "Curved/callout PDF renderer is not byte-deterministic" }
        check(complexFirst.exactValidation.passed)
        check(complexFirst.pdfBytes.toString(Charsets.ISO_8859_1).contains("(C) Tj ET"))
        check(complexFirst.pdfBytes.toString(Charsets.ISO_8859_1).contains("Tiny Ct"))
        val curveIndex = complex.labels.indexOfFirst { it.mode == LabelPlacementMode.CURVED_ROAD_FOLLOWING }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(
                template, complex.copy(labels = complex.labels.mapIndexed { i, l -> if (i == curveIndex) l.copy(curvePath = listOf(250.0 to 205.0)) else l })
            )
        }.isFailure) { "Malformed one-point curved path unexpectedly rendered" }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(
                template, complex.copy(labels = complex.labels.mapIndexed { i, l -> if (i == curveIndex) l.copy(curveNormalSign = 0) else l })
            )
        }.isFailure) { "Curved label without verified side unexpectedly rendered" }
        val calloutIndex = complex.labels.indexOfFirst { it.mode == LabelPlacementMode.NEARBY_ATTACHED_ARROW_CALLOUT }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(
                template, complex.copy(labels = complex.labels.mapIndexed { i, l -> if (i == calloutIndex) l.copy(callout = null) else l })
            )
        }.isFailure) { "Callout without exact leader geometry unexpectedly rendered" }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(
                template, complex.copy(labels = complex.labels.mapIndexed { i, l -> if (i == calloutIndex) l.copy(callout = l.callout!!.copy(tailStart = 514.0 to 284.0)) else l })
            )
        }.isFailure) { "Callout with malformed too-short leader unexpectedly rendered" }

        val detail = dedicatedDetailFixtureSpec()
        val detailFirst = CandidatePdfRenderer.renderNonFieldFixture(template, detail)
        val detailSecond = CandidatePdfRenderer.renderNonFieldFixture(template, detail)
        check(detailFirst.pdfBytes.contentEquals(detailSecond.pdfBytes)) { "Dedicated-detail renderer is not byte-deterministic" }
        check(detailFirst.exactValidation.passed)
        check(detailFirst.pdfBytes.toString(Charsets.ISO_8859_1).contains("Detail Ct"))
        val d = detail.dedicatedDetails.single()
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, detail.copy(dedicatedDetails = listOf(d.copy(destinationBounds = PdfDetailRect(430.0, 220.0, 755.0, 350.0))))) }.isFailure) {
            "Dedicated detail outside locked map unexpectedly rendered"
        }
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, detail.copy(dedicatedDetails = listOf(d.copy(sourceSegmentIds = listOf("unknown-segment"))))) }.isFailure) {
            "Dedicated detail with unknown source segment unexpectedly rendered"
        }
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, detail.copy(dedicatedDetails = listOf(d.copy(labels = d.labels.map { it.copy(mode = LabelPlacementMode.DIRECT_ROAD_FOLLOWING) })))) }.isFailure) {
            "Dedicated detail with non-dedicated label mode unexpectedly rendered"
        }
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, detail.copy(dedicatedDetails = listOf(d.copy(roads = d.roads.map { it.copy(status = PdfRoadStatus.DO_NOT_WORK) })))) }.isFailure) {
            "Dedicated detail work-status drift unexpectedly rendered"
        }


        val split = splitDetailFixtureSpec()
        val splitFirst = CandidatePdfRenderer.renderNonFieldFixture(template, split)
        val splitSecond = CandidatePdfRenderer.renderNonFieldFixture(template, split)
        check(splitFirst.pdfBytes.contentEquals(splitSecond.pdfBytes)) { "Split-detail renderer is not byte-deterministic" }
        check(splitFirst.exactValidation.passed)
        val splitRaw = splitFirst.pdfBytes.toString(Charsets.ISO_8859_1)
        check(splitRaw.contains("% TCS_SPLIT_DETAIL_LOCKED 350 228"))
        check(splitRaw.contains("NORTH DETAIL") && splitRaw.contains("SOUTH DETAIL"))
        val splitLayout = requireNotNull(split.splitDetail)
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, split.copy(splitDetail = null)) }.isFailure) {
            "split_detail without explicit geometry unexpectedly rendered"
        }
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, split.copy(splitDetail = splitLayout.copy(dividerX = 349.0))) }.isFailure) {
            "split_detail wrong divider geometry unexpectedly rendered"
        }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(template, split.copy(splitDetail = splitLayout.copy(
                southPanel = splitLayout.southPanel.copy(sourceSegmentIds = listOf("seg-north")),
                sharedSourceSegmentIds = emptyList()
            )))
        }.isFailure) { "split_detail ambiguous source ownership unexpectedly rendered" }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(template, split.copy(splitDetail = splitLayout.copy(
                northPanel = splitLayout.northPanel.copy(roads = splitLayout.northPanel.roads.map { it.copy(status = PdfRoadStatus.DO_NOT_WORK) })
            )))
        }.isFailure) { "split_detail work-status drift unexpectedly rendered" }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(template, split.copy(splitDetail = splitLayout.copy(
                northPanel = splitLayout.northPanel.copy(buildings = emptyList())
            )))
        }.isFailure) { "split_detail dropped declared building unexpectedly rendered" }

        val fullPlus = fullPlusDetailFixtureSpec()
        val fullPlusFirst = CandidatePdfRenderer.renderNonFieldFixture(template, fullPlus)
        val fullPlusSecond = CandidatePdfRenderer.renderNonFieldFixture(template, fullPlus)
        check(fullPlusFirst.pdfBytes.contentEquals(fullPlusSecond.pdfBytes)) { "full_plus_detail renderer is not byte-deterministic" }
        check(fullPlusFirst.exactValidation.passed)
        val fullPlusRaw = fullPlusFirst.pdfBytes.toString(Charsets.ISO_8859_1)
        check(fullPlusRaw.contains("% TCS_FULL_PLUS_DETAIL_EXPLICIT_MAPPING"))
        check(fullPlusRaw.contains("MAIN CONTEXT") && fullPlusRaw.contains("VERIFIED DETAIL"))
        val fullPlusLayout = requireNotNull(fullPlus.fullPlusDetail)
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, fullPlus.copy(fullPlusDetail = null)) }.isFailure) {
            "full_plus_detail without explicit geometry unexpectedly rendered"
        }
        check(runCatching { CandidatePdfRenderer.renderNonFieldFixture(template, fullPlus.copy(fullPlusDetail = fullPlusLayout.copy(mainContextRect = PdfDetailRect(176.0, 20.0, 540.0, 363.0)))) }.isFailure) {
            "full_plus_detail colliding main/detail rectangles unexpectedly rendered"
        }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(template, fullPlus.copy(fullPlusDetail = fullPlusLayout.copy(
                detail = fullPlusLayout.detail.copy(roads = fullPlusLayout.detail.roads.map { it.copy(status = PdfRoadStatus.DO_NOT_WORK) })
            )))
        }.isFailure) { "full_plus_detail work-status drift unexpectedly rendered" }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(template, fullPlus.copy(fullPlusDetail = fullPlusLayout.copy(
                detail = fullPlusLayout.detail.copy(roads = fullPlusLayout.detail.roads.map { it.copy(x1 = it.x1 + 2.0) })
            )))
        }.isFailure) { "full_plus_detail unverified mapping drift unexpectedly rendered" }
        check(runCatching {
            CandidatePdfRenderer.renderNonFieldFixture(template, fullPlus.copy(fullPlusDetail = fullPlusLayout.copy(
                detail = fullPlusLayout.detail.copy(sourceLabelIds = listOf("missing-label"))
            )))
        }.isFailure) { "full_plus_detail unknown source label unexpectedly rendered" }
    }

    fun curvedCalloutFixtureSpec(): CandidatePdfRenderSpec = CandidatePdfRenderSpec(
        identity = TerritoryIdentity(998, TerritoryClass.Residential, 'a'),
        locality = "Oakland Township",
        updated = "9/25/2026",
        directionsLines = listOf(
            "Directions: Curved/callout Android renderer regression.",
            "Synthetic geometry only.",
            "NOT FOR FIELD USE."
        ),
        layoutMode = "full_map",
        sourceMasterLabel = "SYNTHETIC-ANDROID-CURVED-CALLOUT-FIXTURE",
        roads = buildList {
            add(PdfRoadStroke("seg-alpha", "Alpha Rd", 225.0, 105.0, 650.0, 105.0, PdfRoadStatus.WORK_INSIDE_ONLY))
            val curve = listOf(250.0 to 205.0, 275.0 to 203.0, 300.0 to 198.0, 325.0 to 190.0, 350.0 to 179.0, 375.0 to 165.0, 400.0 to 148.0)
            curve.zipWithNext().forEach { (a, b) -> add(PdfRoadStroke("seg-curve", "Curve Ct", a.first, a.second, b.first, b.second, PdfRoadStatus.WORK_BOTH_SIDES)) }
            add(PdfRoadStroke("seg-delta", "Delta Ln", 225.0, 245.0, 445.0, 245.0, PdfRoadStatus.WORK_INSIDE_ONLY))
            add(PdfRoadStroke("seg-tiny", "Tiny Ct", 505.0, 285.0, 525.0, 285.0, PdfRoadStatus.DO_NOT_WORK))
        },
        labels = listOf(
            PdfStreetLabel("label-alpha", "seg-alpha", "Alpha Rd", 416.5, 117.5, assignedRoadGapPx = 3.0),
            PdfStreetLabel(
                "label-curve", "seg-curve", "Curve Ct", 325.0, 200.0, fontSizePt = 9.0, assignedRoadGapPx = 3.0,
                mode = LabelPlacementMode.CURVED_ROAD_FOLLOWING,
                curvePath = listOf(250.0 to 205.0, 275.0 to 203.0, 300.0 to 198.0, 325.0 to 190.0, 350.0 to 179.0, 375.0 to 165.0, 400.0 to 148.0),
                curveNormalSign = 1, curveBaselineOffsetPt = 12.5
            ),
            PdfStreetLabel("label-delta", "seg-delta", "Delta Ln", 314.0, 238.5, assignedRoadGapPx = 3.0),
            PdfStreetLabel(
                "label-tiny", "seg-tiny", "Tiny Ct", 515.0919, 307.0919, assignedRoadGapPx = 0.0,
                mode = LabelPlacementMode.NEARBY_ATTACHED_ARROW_CALLOUT,
                callout = PdfArrowCallout(
                    roadAnchor = 515.0 to 285.0,
                    tailStart = 528.8848 to 298.8848,
                    labelAttach = 529.5919 to 299.5919,
                    lengthPt = 19.6360724708,
                    tailGapPt = 1.0
                )
            )
        ),
        nonFieldFixture = true
    )

    fun dedicatedDetailFixtureSpec(): CandidatePdfRenderSpec = CandidatePdfRenderSpec(
        identity = TerritoryIdentity(997, TerritoryClass.Residential, 'a'),
        locality = "Oakland Township",
        updated = "9/26/2026",
        directionsLines = listOf(
            "Directions: Dedicated-detail renderer regression.",
            "Synthetic geometry only.",
            "NOT FOR FIELD USE."
        ),
        layoutMode = "full_map",
        sourceMasterLabel = "SYNTHETIC-ANDROID-DEDICATED-DETAIL-FIXTURE",
        roads = listOf(
            PdfRoadStroke("seg-main", "Main Rd", 220.0, 90.0, 410.0, 90.0, PdfRoadStatus.WORK_INSIDE_ONLY),
            PdfRoadStroke("seg-west", "West Dr", 220.0, 150.0, 410.0, 150.0, PdfRoadStatus.WORK_BOTH_SIDES),
            PdfRoadStroke("seg-south", "South Ln", 220.0, 210.0, 410.0, 210.0, PdfRoadStatus.DO_NOT_WORK),
            PdfRoadStroke("seg-detail", "Detail Ct", 590.0, 150.0, 625.0, 150.0, PdfRoadStatus.WORK_BOTH_SIDES)
        ),
        labels = listOf(
            PdfStreetLabel("label-main", "seg-main", "Main Rd", 275.0, 83.0, assignedRoadGapPx = 3.0),
            PdfStreetLabel("label-west", "seg-west", "West Dr", 275.0, 143.0, assignedRoadGapPx = 3.0),
            PdfStreetLabel("label-south", "seg-south", "South Ln", 275.0, 203.0, assignedRoadGapPx = 3.0)
        ),
        dedicatedDetails = listOf(
            PdfDedicatedDetail(
                detailId = "detail-seg-detail",
                sourceBounds = PdfDetailRect(580.0, 135.0, 640.0, 170.0),
                destinationBounds = PdfDetailRect(440.0, 215.0, 700.0, 345.0),
                sourceSegmentIds = listOf("seg-detail"),
                roads = listOf(
                    PdfRoadStroke("seg-detail", "Detail Ct", 485.0, 280.0, 655.0, 280.0, PdfRoadStatus.WORK_BOTH_SIDES)
                ),
                labels = listOf(
                    PdfStreetLabel(
                        "label-detail", "seg-detail", "Detail Ct", 535.0, 273.0,
                        fontSizePt = 9.0, assignedRoadGapPx = 3.0, mode = LabelPlacementMode.DEDICATED_DETAIL
                    )
                )
            )
        ),
        nonFieldFixture = true
    )

    fun splitDetailFixtureSpec(): CandidatePdfRenderSpec {
        val fullRect = PdfDetailRect(176.0, 20.0, 350.0, 365.0)
        val rightRect = PdfDetailRect(357.0, 20.0, 748.0, 365.0)
        val northRect = PdfDetailRect(357.0, 20.0, 748.0, 228.0)
        val southRect = PdfDetailRect(357.0, 228.0, 748.0, 365.0)
        val baseBuilding = PdfBuildingShape(
            "building-north", "101",
            listOf(290.0 to 120.0, 320.0 to 120.0, 320.0 to 142.0, 290.0 to 142.0)
        )
        return CandidatePdfRenderSpec(
            identity = TerritoryIdentity(996, TerritoryClass.Residential, 'a'),
            locality = "Oakland Township",
            updated = "9/26/2026",
            directionsLines = listOf(
                "Directions: Split-detail renderer regression.",
                "Synthetic geometry only.",
                "NOT FOR FIELD USE."
            ),
            layoutMode = "split_detail",
            sourceMasterLabel = "SYNTHETIC-ANDROID-SPLIT-DETAIL-FIXTURE",
            roads = listOf(
                PdfRoadStroke("seg-north", "North Rd", 195.0, 105.0, 330.0, 105.0, PdfRoadStatus.WORK_BOTH_SIDES),
                PdfRoadStroke("seg-south", "South Ln", 195.0, 270.0, 330.0, 270.0, PdfRoadStatus.WORK_INSIDE_ONLY)
            ),
            labels = listOf(
                PdfStreetLabel("label-north-base", "seg-north", "North Rd", 215.0, 98.0, assignedRoadGapPx = 3.0),
                PdfStreetLabel("label-south-base", "seg-south", "South Ln", 215.0, 263.0, assignedRoadGapPx = 3.0)
            ),
            buildings = listOf(baseBuilding),
            splitDetail = PdfSplitDetailLayout(
                fullMapRect = fullRect,
                rightRect = rightRect,
                dividerX = 350.0,
                detailDividerY = 228.0,
                northDetailRect = northRect,
                southDetailRect = southRect,
                northPanel = PdfSplitDetailPanel(
                    panelId = "north-detail",
                    sourceBounds = PdfDetailRect(185.0, 80.0, 340.0, 155.0),
                    destinationBounds = northRect,
                    sourceSegmentIds = listOf("seg-north"),
                    sourceBuildingIds = listOf("building-north"),
                    roads = listOf(PdfRoadStroke("seg-north", "North Rd", 395.0, 110.0, 700.0, 110.0, PdfRoadStatus.WORK_BOTH_SIDES)),
                    labels = listOf(PdfStreetLabel("label-north-detail", "seg-north", "North Rd", 500.0, 103.0, assignedRoadGapPx = 3.0)),
                    buildings = listOf(PdfBuildingShape("building-north", "101", listOf(615.0 to 135.0, 675.0 to 135.0, 675.0 to 175.0, 615.0 to 175.0)))
                ),
                southPanel = PdfSplitDetailPanel(
                    panelId = "south-detail",
                    sourceBounds = PdfDetailRect(185.0, 245.0, 340.0, 300.0),
                    destinationBounds = southRect,
                    sourceSegmentIds = listOf("seg-south"),
                    roads = listOf(PdfRoadStroke("seg-south", "South Ln", 395.0, 295.0, 700.0, 295.0, PdfRoadStatus.WORK_INSIDE_ONLY)),
                    labels = listOf(PdfStreetLabel("label-south-detail", "seg-south", "South Ln", 500.0, 288.0, assignedRoadGapPx = 3.0))
                )
            ),
            nonFieldFixture = true
        )
    }

    fun fullPlusDetailFixtureSpec(): CandidatePdfRenderSpec {
        val main = PdfDetailRect(176.0, 20.0, 500.0, 363.0)
        val source = PdfDetailRect(220.0, 80.0, 330.0, 160.0)
        val dest = PdfDetailRect(515.0, 70.0, 747.0, 330.0)
        fun mx(x: Double) = dest.left + (x - source.left) * dest.width / source.width
        fun my(y: Double) = dest.top + (y - source.top) * dest.height / source.height
        val sourceBuilding = PdfBuildingShape("building-detail", "201", listOf(270.0 to 125.0, 300.0 to 125.0, 300.0 to 145.0, 270.0 to 145.0))
        return CandidatePdfRenderSpec(
            identity = TerritoryIdentity(995, TerritoryClass.Residential, 'a'),
            locality = "Oakland Township",
            updated = "9/26/2026",
            directionsLines = listOf(
                "Directions: Full-plus-detail renderer regression.",
                "Synthetic geometry only.",
                "NOT FOR FIELD USE."
            ),
            layoutMode = "full_plus_detail",
            sourceMasterLabel = "SYNTHETIC-ANDROID-FULL-PLUS-DETAIL-FIXTURE",
            roads = listOf(
                PdfRoadStroke("seg-detail", "Detail Rd", 235.0, 110.0, 315.0, 110.0, PdfRoadStatus.WORK_BOTH_SIDES),
                PdfRoadStroke("seg-context", "Context Ln", 205.0, 250.0, 455.0, 250.0, PdfRoadStatus.WORK_INSIDE_ONLY)
            ),
            labels = listOf(
                PdfStreetLabel("label-detail-source", "seg-detail", "Detail Rd", 250.0, 103.0, assignedRoadGapPx = 3.0),
                PdfStreetLabel("label-context", "seg-context", "Context Ln", 280.0, 243.0, assignedRoadGapPx = 3.0)
            ),
            buildings = listOf(sourceBuilding),
            fullPlusDetail = PdfFullPlusDetailLayout(
                mainContextRect = main,
                detail = PdfFullPlusDetailPanel(
                    panelId = "detail-panel",
                    sourceBounds = source,
                    destinationBounds = dest,
                    sourceSegmentIds = listOf("seg-detail"),
                    sourceBuildingIds = listOf("building-detail"),
                    sourceLabelIds = listOf("label-detail-source"),
                    roads = listOf(PdfRoadStroke("seg-detail", "Detail Rd", mx(235.0), my(110.0), mx(315.0), my(110.0), PdfRoadStatus.WORK_BOTH_SIDES)),
                    detailLabels = listOf(PdfStreetLabel("label-detail-enlarged", "seg-detail", "Detail Rd", mx(250.0), my(103.0), assignedRoadGapPx = 3.0)),
                    buildings = listOf(PdfBuildingShape("building-detail", "201", sourceBuilding.points.map { mx(it.first) to my(it.second) }))
                )
            ),
            nonFieldFixture = true
        )
    }

    fun syntheticFixtureSpec(): CandidatePdfRenderSpec = CandidatePdfRenderSpec(
        identity = TerritoryIdentity(999, TerritoryClass.Residential, 'a'),
        locality = "Oakland Township",
        updated = "9/25/2026",
        directionsLines = listOf(
            "Directions: Synthetic Android renderer regression fixture.",
            "No geography or assignment authority is certified.",
            "NOT FOR FIELD USE."
        ),
        layoutMode = "full_map",
        sourceMasterLabel = "SYNTHETIC-ANDROID-R48-FIXTURE",
        roads = listOf(
            PdfRoadStroke("seg-alpha", "Alpha Rd", 225.0, 115.0, 650.0, 115.0, PdfRoadStatus.WORK_INSIDE_ONLY),
            PdfRoadStroke("seg-beta", "Beta Dr", 225.0, 200.0, 650.0, 200.0, PdfRoadStatus.WORK_BOTH_SIDES),
            PdfRoadStroke("seg-gamma", "Gamma Ct", 225.0, 285.0, 650.0, 285.0, PdfRoadStatus.DO_NOT_WORK)
        ),
        labels = listOf(
            PdfStreetLabel("label-alpha", "seg-alpha", "Alpha Rd", 330.0, 108.0, assignedRoadGapPx = 3.0),
            PdfStreetLabel("label-beta", "seg-beta", "Beta Dr", 330.0, 193.0, assignedRoadGapPx = 3.0),
            PdfStreetLabel("label-gamma", "seg-gamma", "Gamma Ct", 330.0, 278.0, assignedRoadGapPx = 3.0)
        ),
        buildings = listOf(
            PdfBuildingShape("building-101", "101", listOf(520.0 to 230.0, 565.0 to 230.0, 565.0 to 260.0, 520.0 to 260.0))
        ),
        nonFieldFixture = true
    )
}

fun main(args: Array<String>) {
    require(args.size == 2) { "usage: CandidatePdfFixtureGenerator ASSETS_DIR OUTPUT.pdf" }
    val assets = File(args[0])
    val output = File(args[1])
    val template = File(assets, "render-authority/Canonical-New-Designed-Template-R48.pdf").readBytes()
    val result = CandidatePdfRenderer.renderNonFieldFixture(template, CandidatePdfRendererTest.syntheticFixtureSpec())
    output.parentFile?.mkdirs()
    output.writeBytes(result.pdfBytes)
    println("pdf=${output.absolutePath}")
    println("bytes=${result.pdfBytes.size}")
    println("spec_sha256=${result.renderSpecSha256}")
    println("pdf_sha256=${result.pdfSha256}")
    println("validation_passed=${result.exactValidation.passed}")
}
