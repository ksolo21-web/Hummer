package com.koenterprises.territorycardstudio.core

import java.io.Reader
import java.security.MessageDigest
import java.time.Instant
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

private val PROVIDER_SHA256_HEX = Regex("^[0-9a-f]{64}$")

internal object RoadNameCanonicalizer {
    private val direction = mapOf(
        "north" to "n", "n" to "n",
        "south" to "s", "s" to "s",
        "east" to "e", "e" to "e",
        "west" to "w", "w" to "w"
    )
    private val types = mapOf(
        "road" to "rd", "rd" to "rd",
        "street" to "st", "st" to "st",
        "avenue" to "ave", "ave" to "ave",
        "drive" to "dr", "dr" to "dr",
        "court" to "ct", "ct" to "ct",
        "lane" to "ln", "ln" to "ln",
        "boulevard" to "blvd", "blvd" to "blvd",
        "circle" to "cir", "cir" to "cir",
        "place" to "pl", "pl" to "pl",
        "parkway" to "pkwy", "pkwy" to "pkwy",
        "highway" to "hwy", "hwy" to "hwy",
        "terrace" to "ter", "ter" to "ter",
        "trail" to "trl", "trl" to "trl"
    )

    fun canonical(raw: String): String {
        val tokens = TopologyOverlapDecisionEngine.normalizeRoadName(raw).split(' ').filter(String::isNotBlank).toMutableList()
        if (tokens.isEmpty()) return ""
        tokens.indices.forEach { index ->
            val token = tokens[index]
            tokens[index] = direction[token] ?: types[token] ?: token
        }
        return tokens.joinToString(" ")
    }

    fun searchCore(raw: String): String {
        val tokens = canonical(raw).split(' ').filter(String::isNotBlank).toMutableList()
        if (tokens.isEmpty()) return ""
        if (tokens.first() in setOf("n", "s", "e", "w")) tokens.removeAt(0)
        if (tokens.isNotEmpty() && tokens.last() in types.values) tokens.removeAt(tokens.lastIndex)
        if (tokens.isNotEmpty() && tokens.last() in setOf("n", "s", "e", "w")) tokens.removeAt(tokens.lastIndex)
        return tokens.joinToString(" ").ifBlank { canonical(raw) }
    }

    fun osmRegex(raw: String): String {
        val canonical = canonical(raw)
        val tokens = canonical.split(' ').filter(String::isNotBlank)
        return tokens.joinToString("[[:space:]]+") { token ->
            when (token) {
                "n" -> "(N|North)"
                "s" -> "(S|South)"
                "e" -> "(E|East)"
                "w" -> "(W|West)"
                "rd" -> "(Rd|Road)"
                "st" -> "(St|Street)"
                "ave" -> "(Ave|Avenue)"
                "dr" -> "(Dr|Drive)"
                "ct" -> "(Ct|Court)"
                "ln" -> "(Ln|Lane)"
                "blvd" -> "(Blvd|Boulevard)"
                "cir" -> "(Cir|Circle)"
                "pl" -> "(Pl|Place)"
                "pkwy" -> "(Pkwy|Parkway)"
                "hwy" -> "(Hwy|Highway)"
                "ter" -> "(Ter|Terrace)"
                "trl" -> "(Trl|Trail)"
                else -> token
            }
        }.let { "^($it)$" }
    }
}

enum class ProviderQueryStage {
    ROAD_GEOMETRY,
    SITE_ADDRESS,
    BUILDING_OUTLINE,
    BUILDING_METADATA,
    OSM_AREA_LOOKUP,
    OSM_ROADS
}

enum class ProviderHttpMethod { GET, POST_FORM }

data class ProviderQueryPlan(
    val providerId: String,
    val stage: ProviderQueryStage,
    val method: ProviderHttpMethod,
    val endpoint: String,
    val queryParameters: List<Pair<String, String>>,
    val formParameters: List<Pair<String, String>>,
    val headers: List<Pair<String, String>>,
    val requestFingerprint: String,
    val resourceId: String,
    val planFingerprint: String
) {
    init {
        require(providerId.isNotBlank())
        require(endpoint.startsWith("https://")) { "$providerId query endpoint must use HTTPS" }
        require(PROVIDER_SHA256_HEX.matches(requestFingerprint)) { "Invalid provider-plan request fingerprint" }
        require(resourceId.isNotBlank())
        require(PROVIDER_SHA256_HEX.matches(planFingerprint)) { "Invalid provider plan fingerprint" }
        require(queryParameters.map { it.first }.distinct().size == queryParameters.size) { "$providerId has duplicate query parameters" }
        require(formParameters.map { it.first }.distinct().size == formParameters.size) { "$providerId has duplicate form parameters" }
        require(headers.map { it.first.lowercase() }.distinct().size == headers.size) { "$providerId has duplicate HTTP headers" }
        require(queryParameters.none { it.first.equals("key", true) } && formParameters.none { it.first.equals("key", true) }) {
            "API keys must never be embedded in deterministic provider plans"
        }
    }
}

data class ProviderInitialQueryBundle(
    val oaklandRoads: ProviderQueryPlan?,
    val censusRoads: List<ProviderQueryPlan>,
    val osmAreaLookup: ProviderQueryPlan,
    val oaklandSiteAddresses: ProviderQueryPlan?
)

data class OsmAdministrativeArea(
    val relationId: Long,
    val areaId: Long,
    val displayName: String,
    val requestFingerprint: String,
    val responseSha256: String
) {
    init {
        require(relationId > 0)
        require(areaId == 3_600_000_000L + relationId) { "OSM area ID must be derived from relation ID" }
        require(displayName.isNotBlank())
        require(PROVIDER_SHA256_HEX.matches(requestFingerprint))
        require(PROVIDER_SHA256_HEX.matches(responseSha256))
    }
}

data class SiteAddressRecord(
    val objectId: String,
    val pin: String,
    val streetNumber: Int,
    val streetAddress: String,
    val canonicalRoadName: String,
    val longitude: Double,
    val latitude: Double
)

data class SiteAddressParseResult(
    val requestFingerprint: String,
    val records: List<SiteAddressRecord>,
    val responseSha256: String,
    val transferLimitExceeded: Boolean
)

data class BuildingOutlineRecord(
    val objectId: String,
    val keypin: String,
    val status: String?,
    val rings: List<List<GeoCoordinate>>
)

data class BuildingOutlineParseResult(
    val requestFingerprint: String,
    val records: List<BuildingOutlineRecord>,
    val responseSha256: String,
    val transferLimitExceeded: Boolean
)

data class BuildingSourceMetadata(
    val requestFingerprint: String,
    val sourceDataVintage: String,
    val responseSha256: String
)


data class MatchedSiteAddressPins(
    val requestFingerprint: String,
    val siteResponseSha256: String,
    val pins: Set<String>
) {
    init {
        require(PROVIDER_SHA256_HEX.matches(requestFingerprint))
        require(PROVIDER_SHA256_HEX.matches(siteResponseSha256))
        require(pins.isNotEmpty() && pins.all { it.isNotBlank() })
    }
}

data class GeoCoordinate(val longitude: Double, val latitude: Double) {
    init {
        require(longitude in -180.0..180.0) { "Longitude outside WGS84 range" }
        require(latitude in -90.0..90.0) { "Latitude outside WGS84 range" }
    }
}

data class ProviderRoadFeature(
    val providerId: String,
    val featureId: String,
    val canonicalRoadName: String,
    val displayRoadName: String,
    val sourceLayer: String,
    val paths: List<List<GeoCoordinate>>
) {
    init {
        require(providerId.isNotBlank())
        require(featureId.isNotBlank())
        require(canonicalRoadName.isNotBlank())
        require(sourceLayer.isNotBlank())
        require(paths.isNotEmpty() && paths.all { it.size >= 2 }) { "$providerId/$featureId road geometry is empty" }
    }
}

data class ProviderRoadParseResult(
    val providerId: String,
    val requestFingerprint: String,
    val features: List<ProviderRoadFeature>,
    val responseDigests: List<String>,
    val transferLimitExceeded: Boolean,
    val dependencyResponseDigests: List<String> = emptyList()
) {
    init {
        require(providerId.isNotBlank())
        require(PROVIDER_SHA256_HEX.matches(requestFingerprint))
        require(responseDigests.isNotEmpty() && responseDigests.all(PROVIDER_SHA256_HEX::matches))
        require(dependencyResponseDigests.all(PROVIDER_SHA256_HEX::matches))
        require(features.all { it.providerId == providerId })
    }

    val compositeResponseSha256: String
        get() {
            val all = dependencyResponseDigests + responseDigests
            return if (all.size == 1) all.single() else sha256Provider(all.joinToString("\n"))
        }
}

data class ProviderRawResponse(
    val plan: ProviderQueryPlan,
    val body: String,
    val observedAtUtc: String
) {
    init {
        require(ProviderQueryPlanner.fingerprintMatches(plan)) { "Provider query plan fingerprint mismatch" }
        require(body.isNotBlank()) { "Provider response body is blank" }
        Instant.parse(observedAtUtc)
    }

    val responseSha256: String get() = sha256Provider(body)
}

object ProviderQueryPlanner {
    private const val USER_AGENT = "TerritoryCardStudio/0.1.9 (Android geography verification)"

    fun initialPlans(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy
    ): ProviderInitialQueryBundle {
        require(LiveGeometryVerificationRequestFactory.fingerprintMatches(request)) { "Verification request fingerprint mismatch" }
        require(request.onlinePolicyRevision == policy.revision) { "Verification request policy revision mismatch" }
        val searchNames = roadSearchNames(request)
        return ProviderInitialQueryBundle(
            oaklandRoads = if (request.jurisdiction.oaklandCountyMichiganApplicable) oaklandRoadPlan(request, policy, searchNames) else null,
            censusRoads = censusRoadPlans(request, policy, searchNames),
            osmAreaLookup = osmAreaLookupPlan(request, policy),
            oaklandSiteAddresses = if (request.siteAddressCrosscheckRequired) oaklandSiteAddressPlan(request, policy, searchNames) else null
        )
    }

    fun osmRoadPlan(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy,
        area: OsmAdministrativeArea
    ): ProviderQueryPlan {
        require(LiveGeometryVerificationRequestFactory.fingerprintMatches(request)) { "Verification request fingerprint mismatch" }
        require(area.requestFingerprint == request.requestFingerprint) { "OSM area resolution belongs to a different verification request" }
        val provider = policy.providers.getValue("openstreetmap_overpass")
        val patterns = roadSearchNames(request).map(RoadNameCanonicalizer::osmRegex).distinct().sorted()
        require(patterns.isNotEmpty()) { "OSM road query has no road names" }
        val query = buildString {
            append("[out:json][timeout:25];\n")
            append("area(").append(area.areaId).append(")->.searchArea;\n(\n")
            patterns.forEach { pattern ->
                val escaped = pattern.replace("\\", "\\\\").replace("\"", "\\\"")
                append("  way[\"highway\"][\"name\"~\"").append(escaped).append("\",i](area.searchArea);\n")
            }
            append(");\nout body geom qt;")
        }
        return plan(
            providerId = provider.id,
            stage = ProviderQueryStage.OSM_ROADS,
            method = ProviderHttpMethod.POST_FORM,
            endpoint = provider.primaryEndpoint,
            query = emptyList(),
            form = listOf("data" to query),
            headers = listOf("User-Agent" to USER_AGENT, "Accept" to "application/json"),
            request = request,
            resourceId = "osm-area:${area.areaId}:area-response:${area.responseSha256}"
        )
    }

    fun oaklandBuildingPlans(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy,
        matchedPins: MatchedSiteAddressPins
    ): Pair<ProviderQueryPlan, ProviderQueryPlan> {
        require(request.buildingOutlineCrosscheckRequired) { "Building-outline crosscheck is not required for this request" }
        require(request.jurisdiction.oaklandCountyMichiganApplicable) { "Oakland building provider used outside Oakland County" }
        require(matchedPins.requestFingerprint == request.requestFingerprint) { "Site-address PINs belong to a different verification request" }
        val provider = policy.providers.getValue("oakland_county_buildings")
        val pins = matchedPins.pins.map { it.trim() }.filter(String::isNotBlank).distinct().sorted()
        require(pins.isNotEmpty())
        val where = "UPPER(keypin) IN (${pins.joinToString(",") { sqlQuote(it.uppercase()) }})"
        val data = plan(
            providerId = provider.id,
            stage = ProviderQueryStage.BUILDING_OUTLINE,
            method = ProviderHttpMethod.GET,
            endpoint = provider.primaryEndpoint.trimEnd('/') + "/query",
            query = arcGisCommon(where, "objectid,keypin,status", orderBy = "objectid ASC"),
            form = emptyList(),
            headers = listOf("Accept" to "application/json"),
            request = request,
            resourceId = "building-outline:site-response:${matchedPins.siteResponseSha256}:keypins:${sha256Provider(pins.joinToString("|"))}"
        )
        val metadata = plan(
            providerId = provider.id,
            stage = ProviderQueryStage.BUILDING_METADATA,
            method = ProviderHttpMethod.GET,
            endpoint = provider.primaryEndpoint,
            query = listOf("f" to "json"),
            form = emptyList(),
            headers = listOf("Accept" to "application/json"),
            request = request,
            resourceId = "building-outline:metadata"
        )
        return data to metadata
    }

    fun fingerprintMatches(plan: ProviderQueryPlan): Boolean = planFingerprint(
        providerId = plan.providerId,
        stage = plan.stage,
        method = plan.method,
        endpoint = plan.endpoint,
        query = plan.queryParameters,
        form = plan.formParameters,
        headers = plan.headers,
        requestFingerprint = plan.requestFingerprint,
        resourceId = plan.resourceId
    ) == plan.planFingerprint

    private fun oaklandRoadPlan(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy,
        names: List<String>
    ): ProviderQueryPlan {
        val provider = policy.providers.getValue("oakland_county_roads")
        val where = names.joinToString(" OR ") { raw ->
            val core = RoadNameCanonicalizer.searchCore(raw).uppercase()
            "UPPER(CartographicName) LIKE ${sqlQuote("%$core%")} OR UPPER(StreetName) LIKE ${sqlQuote("%$core%")}".let { "($it)" }
        }
        return plan(
            providerId = provider.id,
            stage = ProviderQueryStage.ROAD_GEOMETRY,
            method = ProviderHttpMethod.GET,
            endpoint = provider.primaryEndpoint.trimEnd('/') + "/query",
            query = arcGisCommon(
                where = where,
                outFields = "OBJECTID,DirectionalPrefix,StreetName,StreetType,DirectionalSuffix,CartographicName,RevisionDate",
                orderBy = "OBJECTID ASC"
            ),
            form = emptyList(),
            headers = listOf("Accept" to "application/json"),
            request = request,
            resourceId = "oakland-roads"
        )
    }

    private fun censusRoadPlans(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy,
        names: List<String>
    ): List<ProviderQueryPlan> {
        val provider = policy.providers.getValue("census_tigerweb_transportation")
        val where = names.joinToString(" OR ") { raw ->
            val core = RoadNameCanonicalizer.searchCore(raw).uppercase()
            "(UPPER(NAME) LIKE ${sqlQuote("%$core%")} OR UPPER(BASENAME) LIKE ${sqlQuote("%$core%")})"
        }
        return provider.layers.map { layer ->
            plan(
                providerId = provider.id,
                stage = ProviderQueryStage.ROAD_GEOMETRY,
                method = ProviderHttpMethod.GET,
                endpoint = provider.primaryEndpoint.trimEnd('/') + "/$layer/query",
                query = arcGisCommon(where, "OBJECTID,OID,NAME,BASENAME,MTFCC", orderBy = "OBJECTID ASC"),
                form = emptyList(),
                headers = listOf("Accept" to "application/json"),
                request = request,
                resourceId = "census-layer:$layer"
            )
        }
    }

    private fun osmAreaLookupPlan(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy
    ): ProviderQueryPlan {
        val provider = policy.providers.getValue("openstreetmap_overpass")
        val county = request.jurisdiction.county?.trim().orEmpty()
        require(county.isNotBlank()) { "OSM area lookup requires a county-level jurisdiction" }
        val q = listOf(county, request.jurisdiction.state, request.jurisdiction.country).joinToString(", ")
        return plan(
            providerId = provider.id,
            stage = ProviderQueryStage.OSM_AREA_LOOKUP,
            method = ProviderHttpMethod.GET,
            endpoint = requireNotNull(provider.secondaryEndpoint),
            query = listOf(
                "q" to q,
                "format" to "jsonv2",
                "addressdetails" to "1",
                "limit" to "10",
                "dedupe" to "1"
            ),
            form = emptyList(),
            headers = listOf("User-Agent" to USER_AGENT, "Accept" to "application/json", "Accept-Language" to "en"),
            request = request,
            resourceId = "jurisdiction:${county.lowercase()}|${request.jurisdiction.state.lowercase()}|${request.jurisdiction.country.lowercase()}"
        )
    }

    private fun oaklandSiteAddressPlan(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy,
        names: List<String>
    ): ProviderQueryPlan {
        require(request.jurisdiction.oaklandCountyMichiganApplicable)
        val provider = policy.providers.getValue("oakland_county_site_addresses")
        val specs = request.candidateBuildingMemberIds.map(::parseAddressNumberSpec)
        require(specs.all { it != null }) { "Every building/site member must expose a numeric address/range for Oakland site-address verification" }
        val numberWhere = specs.filterNotNull().distinct().sortedWith(compareBy<AddressNumberSpec> { it.low }.thenBy { it.high }).joinToString(" OR ") { spec ->
            if (spec.low == spec.high) "SITESTREETNUMBER=${spec.low}" else "(SITESTREETNUMBER>=${spec.low} AND SITESTREETNUMBER<=${spec.high})"
        }
        val roadWhere = names.joinToString(" OR ") { raw ->
            val core = RoadNameCanonicalizer.searchCore(raw).uppercase()
            "UPPER(SITESTREETNAME) LIKE ${sqlQuote("%$core%")}" 
        }
        val where = "($numberWhere) AND ($roadWhere)"
        return plan(
            providerId = provider.id,
            stage = ProviderQueryStage.SITE_ADDRESS,
            method = ProviderHttpMethod.GET,
            endpoint = provider.primaryEndpoint.trimEnd('/') + "/query",
            query = arcGisCommon(
                where,
                "OBJECTID,PIN,SITEPREFIXONE,SITESTREETNUMBER,SITESTREETNAME,SITESTREETTYPE,SITESUFFIXONE,SITESTREETADDRESS,SITECITY,SITESTATE,SITEZIPCODE",
                orderBy = "OBJECTID ASC"
            ),
            form = emptyList(),
            headers = listOf("Accept" to "application/json"),
            request = request,
            resourceId = "site-address:${sha256Provider(request.candidateBuildingMemberIds.sorted().joinToString("|"))}"
        )
    }

    private fun roadSearchNames(request: LiveGeometryVerificationRequest): List<String> =
        (request.roadTargets.flatMap { listOf(it.normalizedRoadName) + it.endpointANeighbors + it.endpointBNeighbors })
            .map(RoadNameCanonicalizer::canonical)
            .filter(String::isNotBlank)
            .distinct()
            .sorted()

    private fun arcGisCommon(where: String, outFields: String, orderBy: String): List<Pair<String, String>> = listOf(
        "where" to where,
        "outFields" to outFields,
        "returnGeometry" to "true",
        "outSR" to "4326",
        "f" to "json",
        "orderByFields" to orderBy,
        "resultOffset" to "0",
        "resultRecordCount" to "2000",
        "returnZ" to "false",
        "returnM" to "false"
    )

    private fun plan(
        providerId: String,
        stage: ProviderQueryStage,
        method: ProviderHttpMethod,
        endpoint: String,
        query: List<Pair<String, String>>,
        form: List<Pair<String, String>>,
        headers: List<Pair<String, String>>,
        request: LiveGeometryVerificationRequest,
        resourceId: String
    ): ProviderQueryPlan {
        val fingerprint = planFingerprint(providerId, stage, method, endpoint, query, form, headers, request.requestFingerprint, resourceId)
        return ProviderQueryPlan(
            providerId = providerId,
            stage = stage,
            method = method,
            endpoint = endpoint,
            queryParameters = query,
            formParameters = form,
            headers = headers,
            requestFingerprint = request.requestFingerprint,
            resourceId = resourceId,
            planFingerprint = fingerprint
        )
    }

    private fun planFingerprint(
        providerId: String,
        stage: ProviderQueryStage,
        method: ProviderHttpMethod,
        endpoint: String,
        query: List<Pair<String, String>>,
        form: List<Pair<String, String>>,
        headers: List<Pair<String, String>>,
        requestFingerprint: String,
        resourceId: String
    ): String = sha256Provider(buildString {
        append("provider=").append(providerId).append('\n')
        append("stage=").append(stage.name).append('\n')
        append("method=").append(method.name).append('\n')
        append("endpoint=").append(endpoint).append('\n')
        append("request=").append(requestFingerprint).append('\n')
        append("resource=").append(resourceId).append('\n')
        query.forEach { (key, value) -> append("q:").append(key).append('=').append(value).append('\n') }
        form.forEach { (key, value) -> append("f:").append(key).append('=').append(value).append('\n') }
        headers.forEach { (key, value) -> append("h:").append(key.lowercase()).append('=').append(value).append('\n') }
    })

    private fun sqlQuote(value: String): String = "'${value.replace("'", "''")}'"
}

object ProviderResponseParser {
    fun parseOaklandRoads(response: ProviderRawResponse): ProviderRoadParseResult {
        require(response.plan.providerId == "oakland_county_roads" && response.plan.stage == ProviderQueryStage.ROAD_GEOMETRY)
        return parseArcGisRoadResponses("oakland_county_roads", listOf(response)) { attrs ->
            val display = attrs.optionalStringCase("CartographicName")?.takeIf(String::isNotBlank)
                ?: listOf(
                    attrs.optionalStringCase("DirectionalPrefix"),
                    attrs.optionalStringCase("StreetName"),
                    attrs.optionalStringCase("StreetType"),
                    attrs.optionalStringCase("DirectionalSuffix")
                ).filterNotNull().filter(String::isNotBlank).joinToString(" ")
            display
        }
    }

    fun parseCensusRoads(responses: List<ProviderRawResponse>): ProviderRoadParseResult {
        require(responses.isNotEmpty())
        require(responses.all { it.plan.providerId == "census_tigerweb_transportation" && it.plan.stage == ProviderQueryStage.ROAD_GEOMETRY })
        val resources = responses.map { it.plan.resourceId }.toSet()
        require(resources == setOf("census-layer:2", "census-layer:6", "census-layer:8")) {
            "Census road parse requires exactly policy layers 2, 6, and 8; got $resources"
        }
        return parseArcGisRoadResponses("census_tigerweb_transportation", responses) { attrs ->
            attrs.optionalStringCase("NAME")?.takeIf(String::isNotBlank)
                ?: attrs.optionalStringCase("BASENAME").orEmpty()
        }
    }

    fun parseOsmArea(response: ProviderRawResponse, jurisdiction: VerificationJurisdiction): OsmAdministrativeArea {
        require(response.plan.providerId == "openstreetmap_overpass" && response.plan.stage == ProviderQueryStage.OSM_AREA_LOOKUP)
        val root = StrictJson.parse(response.body.reader()).arr("nominatim")
        val matches = root.mapIndexedNotNull { index, value ->
            val o = value.obj("nominatim[$index]")
            val osmType = o.optionalStringCase("osm_type") ?: return@mapIndexedNotNull null
            if (osmType.lowercase() != "relation") return@mapIndexedNotNull null
            val osmId = o.optionalLongCase("osm_id") ?: return@mapIndexedNotNull null
            val display = o.optionalStringCase("display_name").orEmpty()
            val clazz = o.optionalStringCase("class").orEmpty()
            val category = o.optionalStringCase("category").orEmpty()
            val type = o.optionalStringCase("type").orEmpty()
            if (clazz != "boundary" && category != "boundary" && type != "administrative") return@mapIndexedNotNull null
            val address = (o.entries.firstOrNull { it.key.equals("address", true) }?.value as? JsonValue.Obj)?.values
            val county = address?.optionalStringCase("county") ?: address?.optionalStringCase("state_district")
            val state = address?.optionalStringCase("state")
            val country = address?.optionalStringCase("country")
            val countryCode = address?.optionalStringCase("country_code")
            if (!jurisdictionPartMatches(county, jurisdiction.county, removeCounty = true)) return@mapIndexedNotNull null
            if (!jurisdictionPartMatches(state, jurisdiction.state, removeCounty = false)) return@mapIndexedNotNull null
            if (!countryMatches(country, countryCode, jurisdiction.country)) return@mapIndexedNotNull null
            Triple(osmId, 3_600_000_000L + osmId, display)
        }
        require(matches.size == 1) { "Nominatim jurisdiction lookup must resolve exactly one administrative relation; matches=${matches.size}" }
        val (relation, area, display) = matches.single()
        return OsmAdministrativeArea(relation, area, display, response.plan.requestFingerprint, response.responseSha256)
    }

    fun parseOsmRoads(areaResponse: ProviderRawResponse, roadResponse: ProviderRawResponse): ProviderRoadParseResult {
        require(areaResponse.plan.providerId == "openstreetmap_overpass" && areaResponse.plan.stage == ProviderQueryStage.OSM_AREA_LOOKUP)
        require(roadResponse.plan.providerId == "openstreetmap_overpass" && roadResponse.plan.stage == ProviderQueryStage.OSM_ROADS)
        require(areaResponse.plan.requestFingerprint == roadResponse.plan.requestFingerprint) { "OSM staged responses bind to different verification requests" }
        require(roadResponse.plan.resourceId.contains("area-response:${areaResponse.responseSha256}")) { "OSM road plan is not bound to the supplied area lookup response" }
        val root = StrictJson.parse(roadResponse.body.reader()).obj("overpass")
        val remark = root.optionalStringCase("remark")?.trim().orEmpty()
        require(remark.isBlank()) { "Overpass response is incomplete/error-marked: $remark" }
        val elements = root.required("elements", "overpass").arr("overpass.elements")
        val seenIds = mutableSetOf<String>()
        val features = elements.mapIndexedNotNull { index, value ->
            val o = value.obj("overpass.elements[$index]")
            if (o.optionalStringCase("type") != "way") return@mapIndexedNotNull null
            val id = o.optionalLongCase("id")?.toString() ?: error("Overpass way missing id")
            require(seenIds.add(id)) { "Duplicate OSM way id=$id" }
            val tags = (o.entries.firstOrNull { it.key.equals("tags", true) }?.value as? JsonValue.Obj)?.values ?: return@mapIndexedNotNull null
            val name = tags.optionalStringCase("name")?.takeIf(String::isNotBlank) ?: return@mapIndexedNotNull null
            val highway = tags.optionalStringCase("highway")?.takeIf(String::isNotBlank) ?: return@mapIndexedNotNull null
            require(highway != "proposed" && highway != "construction") { "OSM query unexpectedly returned non-current highway=$highway" }
            val geometry = o.required("geometry", "overpass.way[$id]").arr("overpass.way[$id].geometry").mapIndexed { geoIndex, point ->
                val p = point.obj("overpass.way[$id].geometry[$geoIndex]")
                GeoCoordinate(
                    longitude = p.required("lon", "overpass.geometry").double("lon"),
                    latitude = p.required("lat", "overpass.geometry").double("lat")
                )
            }
            require(geometry.size >= 2) { "OSM way $id has insufficient geometry" }
            ProviderRoadFeature(
                providerId = "openstreetmap_overpass",
                featureId = id,
                canonicalRoadName = RoadNameCanonicalizer.canonical(name),
                displayRoadName = name,
                sourceLayer = "overpass-way",
                paths = listOf(geometry)
            )
        }.sortedWith(compareBy<ProviderRoadFeature> { it.canonicalRoadName }.thenBy { it.featureId })
        return ProviderRoadParseResult(
            providerId = "openstreetmap_overpass",
            requestFingerprint = roadResponse.plan.requestFingerprint,
            features = features,
            responseDigests = listOf(roadResponse.responseSha256),
            transferLimitExceeded = false,
            dependencyResponseDigests = listOf(areaResponse.responseSha256)
        )
    }

    fun parseSiteAddresses(response: ProviderRawResponse): SiteAddressParseResult {
        require(response.plan.providerId == "oakland_county_site_addresses" && response.plan.stage == ProviderQueryStage.SITE_ADDRESS)
        val root = StrictJson.parse(response.body.reader()).obj("site-address-response")
        failOnArcGisError(root, "site-address-response")
        val exceeded = root.optionalBoolCase("exceededTransferLimit") ?: false
        val features = root.required("features", "site-address-response").arr("site-address-response.features")
        val records = features.mapIndexed { index, value ->
            val f = value.obj("site-address-response.features[$index]")
            val attrs = f.required("attributes", "site-address feature").obj("site-address attributes")
            val geometry = f.required("geometry", "site-address feature").obj("site-address geometry")
            val objectId = attrs.requiredScalarString("OBJECTID")
            val pin = attrs.optionalStringCase("PIN")?.trim().orEmpty()
            require(pin.isNotBlank()) { "Site address $objectId is missing PIN" }
            val number = attrs.optionalIntCase("SITESTREETNUMBER") ?: error("Site address $objectId missing SITESTREETNUMBER")
            val streetPrefix = attrs.optionalStringCase("SITEPREFIXONE").orEmpty()
            val streetName = attrs.optionalStringCase("SITESTREETNAME").orEmpty()
            val streetType = attrs.optionalStringCase("SITESTREETTYPE").orEmpty()
            val streetSuffix = attrs.optionalStringCase("SITESUFFIXONE").orEmpty()
            val streetAddress = attrs.optionalStringCase("SITESTREETADDRESS")?.takeIf(String::isNotBlank)
                ?: "$number $streetPrefix $streetName $streetType $streetSuffix".replace(Regex("\\s+"), " ").trim()
            SiteAddressRecord(
                objectId = objectId,
                pin = pin,
                streetNumber = number,
                streetAddress = streetAddress,
                canonicalRoadName = RoadNameCanonicalizer.canonical("$streetPrefix $streetName $streetType $streetSuffix"),
                longitude = geometry.required("x", "site-address geometry").double("x"),
                latitude = geometry.required("y", "site-address geometry").double("y")
            )
        }.sortedWith(compareBy<SiteAddressRecord> { it.streetNumber }.thenBy { it.pin }.thenBy { it.objectId })
        return SiteAddressParseResult(response.plan.requestFingerprint, records, response.responseSha256, exceeded)
    }

    fun parseBuildingOutlines(response: ProviderRawResponse): BuildingOutlineParseResult {
        require(response.plan.providerId == "oakland_county_buildings" && response.plan.stage == ProviderQueryStage.BUILDING_OUTLINE)
        val root = StrictJson.parse(response.body.reader()).obj("building-outline-response")
        failOnArcGisError(root, "building-outline-response")
        val exceeded = root.optionalBoolCase("exceededTransferLimit") ?: false
        val features = root.required("features", "building-outline-response").arr("building-outline-response.features")
        val records = features.mapIndexed { index, value ->
            val f = value.obj("building-outline-response.features[$index]")
            val attrs = f.required("attributes", "building-outline feature").obj("building-outline attributes")
            val geometry = f.required("geometry", "building-outline feature").obj("building-outline geometry")
            val objectId = attrs.requiredScalarString("objectid")
            val keypin = attrs.optionalStringCase("keypin")?.trim().orEmpty()
            require(keypin.isNotBlank()) { "Building outline $objectId is missing keypin" }
            val rings = parseArcGisRings(geometry.required("rings", "building-outline geometry"), "building-outline $objectId")
            require(rings.isNotEmpty()) { "Building outline $objectId has no rings" }
            BuildingOutlineRecord(objectId, keypin, attrs.optionalStringCase("status"), rings)
        }.sortedWith(compareBy<BuildingOutlineRecord> { it.keypin }.thenBy { it.objectId })
        return BuildingOutlineParseResult(response.plan.requestFingerprint, records, response.responseSha256, exceeded)
    }

    fun parseBuildingMetadata(response: ProviderRawResponse): BuildingSourceMetadata {
        require(response.plan.providerId == "oakland_county_buildings" && response.plan.stage == ProviderQueryStage.BUILDING_METADATA)
        val root = StrictJson.parse(response.body.reader()).obj("building-metadata")
        failOnArcGisError(root, "building-metadata")
        val description = root.optionalStringCase("description")?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
        require(description.isNotBlank()) { "Building metadata description is missing" }
        require(Regex("\\b20\\d{2}\\b").findAll(description).count() >= 1) { "Building metadata does not retain a source/update year" }
        return BuildingSourceMetadata(response.plan.requestFingerprint, description, response.responseSha256)
    }

    private fun parseArcGisRoadResponses(
        providerId: String,
        responses: List<ProviderRawResponse>,
        displayName: (Map<String, JsonValue>) -> String
    ): ProviderRoadParseResult {
        require(responses.isNotEmpty())
        require(responses.map { it.plan.requestFingerprint }.distinct().size == 1) { "Provider road responses bind to different verification requests" }
        require(responses.map { it.plan.planFingerprint }.distinct().size == responses.size) { "Duplicate provider response plan" }
        val features = mutableListOf<ProviderRoadFeature>()
        var exceeded = false
        responses.sortedBy { it.plan.resourceId }.forEach { response ->
            val root = StrictJson.parse(response.body.reader()).obj("$providerId response")
            failOnArcGisError(root, "$providerId response")
            exceeded = exceeded || (root.optionalBoolCase("exceededTransferLimit") ?: false)
            val values = root.required("features", "$providerId response").arr("$providerId features")
            values.forEachIndexed { index, value ->
                val f = value.obj("$providerId feature[$index]")
                val attrs = f.required("attributes", "$providerId feature").obj("$providerId attributes")
                val name = displayName(attrs).trim()
                if (name.isBlank()) return@forEachIndexed
                val geometry = f.required("geometry", "$providerId feature").obj("$providerId geometry")
                val paths = parseArcGisPaths(geometry.required("paths", "$providerId geometry"), "$providerId feature")
                val featureId = attrs.firstScalarString("OBJECTID", "OID") ?: error("$providerId feature missing OBJECTID/OID")
                features += ProviderRoadFeature(
                    providerId = providerId,
                    featureId = "${response.plan.resourceId}:$featureId",
                    canonicalRoadName = RoadNameCanonicalizer.canonical(name),
                    displayRoadName = name,
                    sourceLayer = response.plan.resourceId,
                    paths = paths
                )
            }
        }
        val deduped = features.distinctBy { it.featureId }.sortedWith(compareBy<ProviderRoadFeature> { it.canonicalRoadName }.thenBy { it.featureId })
        return ProviderRoadParseResult(
            providerId = providerId,
            requestFingerprint = responses.first().plan.requestFingerprint,
            features = deduped,
            responseDigests = responses.sortedBy { it.plan.resourceId }.map { it.responseSha256 },
            transferLimitExceeded = exceeded
        )
    }

    private fun parseArcGisPaths(value: JsonValue, context: String): List<List<GeoCoordinate>> =
        value.arr("$context.paths").mapIndexed { pathIndex, path ->
            path.arr("$context.paths[$pathIndex]").mapIndexed { pointIndex, point ->
                val p = point.arr("$context.paths[$pathIndex][$pointIndex]")
                require(p.size >= 2) { "$context coordinate needs x/y" }
                GeoCoordinate(p[0].double("x"), p[1].double("y"))
            }.also { require(it.size >= 2) { "$context path has fewer than two points" } }
        }.also { require(it.isNotEmpty()) { "$context has no paths" } }

    private fun parseArcGisRings(value: JsonValue, context: String): List<List<GeoCoordinate>> =
        value.arr("$context.rings").mapIndexed { ringIndex, ring ->
            ring.arr("$context.rings[$ringIndex]").mapIndexed { pointIndex, point ->
                val p = point.arr("$context.rings[$ringIndex][$pointIndex]")
                require(p.size >= 2) { "$context ring coordinate needs x/y" }
                GeoCoordinate(p[0].double("x"), p[1].double("y"))
            }.also { require(it.size >= 4) { "$context ring has fewer than four points" } }
        }

    private fun failOnArcGisError(root: Map<String, JsonValue>, context: String) {
        val errorValue = root.entries.firstOrNull { it.key.equals("error", true) }?.value ?: return
        val error = errorValue.obj("$context.error")
        val code = error.optionalIntCase("code")
        val message = error.optionalStringCase("message")
        error("$context ArcGIS error code=$code message=${message.orEmpty()}")
    }
}

object ProviderEvidenceAssembler {
    private const val ROAD_NEAR_TOLERANCE_METERS = 12.0

    fun roadEvidence(
        request: LiveGeometryVerificationRequest,
        parseResult: ProviderRoadParseResult,
        observedAtUtc: String
    ): ProviderVerificationEvidence {
        require(LiveGeometryVerificationRequestFactory.fingerprintMatches(request)) { "Verification request fingerprint mismatch" }
        require(parseResult.requestFingerprint == request.requestFingerprint) { "Parsed road response belongs to a different verification request" }
        Instant.parse(observedAtUtc)
        val allTargetIds = request.roadTargets.mapTo(linkedSetOf()) { it.targetId }
        if (parseResult.transferLimitExceeded) {
            return unavailableRoadEvidence(
                request = request,
                providerId = parseResult.providerId,
                queried = allTargetIds,
                errorCode = "TRANSFER_LIMIT_EXCEEDED",
                observedAtUtc = observedAtUtc,
                responseSha256 = parseResult.compositeResponseSha256
            )
        }
        val byName = parseResult.features.groupBy { it.canonicalRoadName }
        val repeatedNames = request.roadTargets.groupingBy { RoadNameCanonicalizer.canonical(it.normalizedRoadName) }.eachCount()
        val targetNeighborSignatures = request.roadTargets.groupingBy { target ->
            val canonical = RoadNameCanonicalizer.canonical(target.normalizedRoadName)
            val neighbors = (target.endpointANeighbors + target.endpointBNeighbors)
                .map(RoadNameCanonicalizer::canonical).filter(String::isNotBlank).sorted()
            "$canonical|${neighbors.joinToString(",")}"
        }.eachCount()
        val confirmed = linkedSetOf<String>()
        val notFound = linkedSetOf<String>()
        val conflicting = linkedSetOf<String>()
        request.roadTargets.forEach { target ->
            val canonical = RoadNameCanonicalizer.canonical(target.normalizedRoadName)
            val roadFeatures = byName[canonical].orEmpty()
            if (roadFeatures.isEmpty()) {
                notFound += target.targetId
                return@forEach
            }
            val components = connectedSameRoadComponents(roadFeatures)
            val requiredNeighbors = (target.endpointANeighbors + target.endpointBNeighbors)
                .map(RoadNameCanonicalizer::canonical).filter(String::isNotBlank).toSet()
            val signature = "$canonical|${requiredNeighbors.sorted().joinToString(",")}"
            val indistinguishableLockedTargets = targetNeighborSignatures.getValue(signature) > 1
            val candidateComponents = components.filter { component ->
                requiredNeighbors.all { it in observedNeighborNames(component, parseResult.features) }
            }
            when {
                requiredNeighbors.isEmpty() && (repeatedNames.getValue(canonical) > 1 || components.size != 1) -> conflicting += target.targetId
                indistinguishableLockedTargets -> conflicting += target.targetId
                candidateComponents.size != 1 -> conflicting += target.targetId
                else -> confirmed += target.targetId
            }
        }
        return ProviderVerificationEvidence(
            providerId = parseResult.providerId,
            requestFingerprint = request.requestFingerprint,
            available = true,
            observedAtUtc = observedAtUtc,
            responseSha256 = parseResult.compositeResponseSha256,
            sourceDataVintage = null,
            queriedTargetIds = allTargetIds,
            confirmedTargetIds = confirmed,
            notFoundTargetIds = notFound,
            conflictingTargetIds = conflicting,
            unknownMeaningChangingRoads = emptySet(),
            siteAddressCrosscheckPassed = null,
            buildingOutlineCrosscheckPassed = null,
            errorCode = null
        )
    }

    fun siteAddressEvidence(
        request: LiveGeometryVerificationRequest,
        parseResult: SiteAddressParseResult,
        observedAtUtc: String
    ): Pair<ProviderVerificationEvidence, MatchedSiteAddressPins?> {
        require(request.siteAddressCrosscheckRequired)
        require(parseResult.requestFingerprint == request.requestFingerprint) { "Parsed site-address response belongs to a different verification request" }
        Instant.parse(observedAtUtc)
        if (parseResult.transferLimitExceeded) {
            return ProviderVerificationEvidence(
                providerId = "oakland_county_site_addresses",
                requestFingerprint = request.requestFingerprint,
                available = false,
                observedAtUtc = observedAtUtc,
                responseSha256 = parseResult.responseSha256,
                sourceDataVintage = null,
                queriedTargetIds = emptySet(),
                confirmedTargetIds = emptySet(),
                notFoundTargetIds = emptySet(),
                conflictingTargetIds = emptySet(),
                unknownMeaningChangingRoads = emptySet(),
                siteAddressCrosscheckPassed = null,
                buildingOutlineCrosscheckPassed = null,
                errorCode = "TRANSFER_LIMIT_EXCEEDED"
            ) to null
        }
        val expectedRoads = request.roadTargets.map { RoadNameCanonicalizer.canonical(it.normalizedRoadName) }.toSet()
        val records = parseResult.records.filter { it.canonicalRoadName in expectedRoads }
        val specs = request.candidateBuildingMemberIds.associateWith(::parseAddressNumberSpec)
        val unparseable = specs.filterValues { it == null }.keys
        val matchedMembers = specs.filterValues { spec ->
            spec != null && records.any { it.streetNumber in spec.low..spec.high }
        }.keys
        val passed = unparseable.isEmpty() && matchedMembers.size == request.candidateBuildingMemberIds.size
        val matchedPins = records.filter { record -> specs.values.filterNotNull().any { record.streetNumber in it.low..it.high } }
            .mapTo(sortedSetOf()) { it.pin }
        val evidence = ProviderVerificationEvidence(
            providerId = "oakland_county_site_addresses",
            requestFingerprint = request.requestFingerprint,
            available = true,
            observedAtUtc = observedAtUtc,
            responseSha256 = parseResult.responseSha256,
            sourceDataVintage = null,
            queriedTargetIds = emptySet(),
            confirmedTargetIds = emptySet(),
            notFoundTargetIds = emptySet(),
            conflictingTargetIds = emptySet(),
            unknownMeaningChangingRoads = emptySet(),
            siteAddressCrosscheckPassed = passed,
            buildingOutlineCrosscheckPassed = null,
            errorCode = null
        )
        val boundPins = if (matchedPins.isEmpty()) null else MatchedSiteAddressPins(
            requestFingerprint = request.requestFingerprint,
            siteResponseSha256 = parseResult.responseSha256,
            pins = matchedPins
        )
        return evidence to boundPins
    }

    fun buildingOutlineEvidence(
        request: LiveGeometryVerificationRequest,
        parseResult: BuildingOutlineParseResult,
        metadata: BuildingSourceMetadata,
        requiredPins: MatchedSiteAddressPins,
        observedAtUtc: String
    ): ProviderVerificationEvidence {
        require(request.buildingOutlineCrosscheckRequired)
        require(parseResult.requestFingerprint == request.requestFingerprint) { "Parsed building response belongs to a different verification request" }
        require(metadata.requestFingerprint == request.requestFingerprint) { "Building metadata belongs to a different verification request" }
        require(requiredPins.requestFingerprint == request.requestFingerprint) { "Required building PINs belong to a different verification request" }
        Instant.parse(observedAtUtc)
        if (parseResult.transferLimitExceeded) {
            return ProviderVerificationEvidence(
                providerId = "oakland_county_buildings",
                requestFingerprint = request.requestFingerprint,
                available = false,
                observedAtUtc = observedAtUtc,
                responseSha256 = sha256Provider(listOf(metadata.responseSha256, parseResult.responseSha256).joinToString("\n")),
                sourceDataVintage = null,
                queriedTargetIds = emptySet(),
                confirmedTargetIds = emptySet(),
                notFoundTargetIds = emptySet(),
                conflictingTargetIds = emptySet(),
                unknownMeaningChangingRoads = emptySet(),
                siteAddressCrosscheckPassed = null,
                buildingOutlineCrosscheckPassed = null,
                errorCode = "TRANSFER_LIMIT_EXCEEDED"
            )
        }
        val availablePins = parseResult.records.mapTo(mutableSetOf()) { it.keypin.uppercase() }
        val expected = requiredPins.pins.mapTo(mutableSetOf()) { it.uppercase() }
        val passed = expected.isNotEmpty() && expected.all { it in availablePins }
        val composite = sha256Provider(listOf(metadata.responseSha256, parseResult.responseSha256).joinToString("\n"))
        return ProviderVerificationEvidence(
            providerId = "oakland_county_buildings",
            requestFingerprint = request.requestFingerprint,
            available = true,
            observedAtUtc = observedAtUtc,
            responseSha256 = composite,
            sourceDataVintage = metadata.sourceDataVintage,
            queriedTargetIds = emptySet(),
            confirmedTargetIds = emptySet(),
            notFoundTargetIds = emptySet(),
            conflictingTargetIds = emptySet(),
            unknownMeaningChangingRoads = emptySet(),
            siteAddressCrosscheckPassed = null,
            buildingOutlineCrosscheckPassed = passed,
            errorCode = null
        )
    }

    private fun unavailableRoadEvidence(
        request: LiveGeometryVerificationRequest,
        providerId: String,
        queried: Set<String>,
        errorCode: String,
        observedAtUtc: String,
        responseSha256: String
    ): ProviderVerificationEvidence = ProviderVerificationEvidence(
        providerId = providerId,
        requestFingerprint = request.requestFingerprint,
        available = false,
        observedAtUtc = observedAtUtc,
        responseSha256 = responseSha256,
        sourceDataVintage = null,
        queriedTargetIds = queried,
        confirmedTargetIds = emptySet(),
        notFoundTargetIds = emptySet(),
        conflictingTargetIds = emptySet(),
        unknownMeaningChangingRoads = emptySet(),
        siteAddressCrosscheckPassed = null,
        buildingOutlineCrosscheckPassed = null,
        errorCode = errorCode
    )

    private fun connectedSameRoadComponents(features: List<ProviderRoadFeature>): List<List<ProviderRoadFeature>> {
        if (features.isEmpty()) return emptyList()
        val canonical = features.first().canonicalRoadName
        require(features.all { it.canonicalRoadName == canonical }) { "Same-road component input mixes road names" }
        val remaining = features.sortedBy { it.featureId }.toMutableList()
        val components = mutableListOf<List<ProviderRoadFeature>>()
        while (remaining.isNotEmpty()) {
            val component = mutableListOf(remaining.removeAt(0))
            var index = 0
            while (index < component.size) {
                val current = component[index++]
                val iterator = remaining.iterator()
                while (iterator.hasNext()) {
                    val candidate = iterator.next()
                    if (roadsNear(current, candidate, ROAD_NEAR_TOLERANCE_METERS)) {
                        component += candidate
                        iterator.remove()
                    }
                }
            }
            components += component.sortedBy { it.featureId }
        }
        return components
    }

    private fun observedNeighborNames(
        roadFeatures: List<ProviderRoadFeature>,
        allFeatures: List<ProviderRoadFeature>
    ): Set<String> {
        val canonical = roadFeatures.first().canonicalRoadName
        val neighbors = sortedSetOf<String>()
        allFeatures.forEach { other ->
            if (other.canonicalRoadName == canonical) return@forEach
            if (roadFeatures.any { roadsNear(it, other, ROAD_NEAR_TOLERANCE_METERS) }) neighbors += other.canonicalRoadName
        }
        return neighbors
    }

    private fun roadsNear(a: ProviderRoadFeature, b: ProviderRoadFeature, toleranceMeters: Double): Boolean =
        a.paths.any { pa -> b.paths.any { pb -> polylineDistanceMeters(pa, pb) <= toleranceMeters } }

    private fun polylineDistanceMeters(a: List<GeoCoordinate>, b: List<GeoCoordinate>): Double {
        var best = Double.POSITIVE_INFINITY
        for (i in 0 until a.lastIndex) {
            for (j in 0 until b.lastIndex) {
                best = min(best, segmentDistanceMeters(a[i], a[i + 1], b[j], b[j + 1]))
                if (best <= 0.01) return 0.0
            }
        }
        return best
    }

    private fun segmentDistanceMeters(a0: GeoCoordinate, a1: GeoCoordinate, b0: GeoCoordinate, b1: GeoCoordinate): Double {
        val refLat = Math.toRadians((a0.latitude + a1.latitude + b0.latitude + b1.latitude) / 4.0)
        fun xy(p: GeoCoordinate): Pair<Double, Double> =
            (p.longitude * 111_320.0 * cos(refLat)) to (p.latitude * 110_540.0)
        val aa0 = xy(a0); val aa1 = xy(a1); val bb0 = xy(b0); val bb1 = xy(b1)
        if (segmentsIntersect(aa0, aa1, bb0, bb1)) return 0.0
        return min(
            min(pointSegmentDistance(aa0, bb0, bb1), pointSegmentDistance(aa1, bb0, bb1)),
            min(pointSegmentDistance(bb0, aa0, aa1), pointSegmentDistance(bb1, aa0, aa1))
        )
    }

    private fun segmentsIntersect(a: Pair<Double, Double>, b: Pair<Double, Double>, c: Pair<Double, Double>, d: Pair<Double, Double>): Boolean {
        fun cross(p: Pair<Double, Double>, q: Pair<Double, Double>, r: Pair<Double, Double>): Double =
            (q.first - p.first) * (r.second - p.second) - (q.second - p.second) * (r.first - p.first)
        val c1 = cross(a, b, c)
        val c2 = cross(a, b, d)
        val c3 = cross(c, d, a)
        val c4 = cross(c, d, b)
        return ((c1 <= 0 && c2 >= 0) || (c1 >= 0 && c2 <= 0)) && ((c3 <= 0 && c4 >= 0) || (c3 >= 0 && c4 <= 0))
    }

    private fun pointSegmentDistance(p: Pair<Double, Double>, a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
        val dx = b.first - a.first
        val dy = b.second - a.second
        val denom = dx.pow(2) + dy.pow(2)
        if (denom == 0.0) return sqrt((p.first - a.first).pow(2) + (p.second - a.second).pow(2))
        val t = max(0.0, min(1.0, ((p.first - a.first) * dx + (p.second - a.second) * dy) / denom))
        val x = a.first + t * dx
        val y = a.second + t * dy
        return sqrt((p.first - x).pow(2) + (p.second - y).pow(2))
    }
}

private data class AddressNumberSpec(val low: Int, val high: Int)

private fun parseAddressNumberSpec(raw: String): AddressNumberSpec? {
    val normalized = raw.trim().replace('–', '-').replace('—', '-')
    val range = Regex("^(\\d+)[A-Za-z]?\\s*-\\s*(\\d+)[A-Za-z]?$", RegexOption.IGNORE_CASE).matchEntire(normalized)
    if (range != null) {
        val a = range.groupValues[1].toInt()
        val b = range.groupValues[2].toInt()
        return AddressNumberSpec(min(a, b), max(a, b))
    }
    val single = Regex("^(\\d+)[A-Za-z]?$", RegexOption.IGNORE_CASE).matchEntire(normalized) ?: return null
    val n = single.groupValues[1].toInt()
    return AddressNumberSpec(n, n)
}

private fun jurisdictionPartMatches(actual: String?, expected: String?, removeCounty: Boolean): Boolean {
    if (expected.isNullOrBlank()) return actual.isNullOrBlank()
    if (actual.isNullOrBlank()) return false
    fun normalize(value: String): String {
        var out = value.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        if (removeCounty) out = out.replace(Regex("\\bcounty\\b"), "").replace(Regex("\\s+"), " ").trim()
        return out
    }
    val a = normalize(actual)
    val e = normalize(expected)
    if (a == e) return true
    return e == "mi" && a == "michigan"
}

private fun countryMatches(actual: String?, countryCode: String?, expected: String): Boolean {
    val e = expected.lowercase().replace(Regex("[^a-z]+"), " ").trim()
    val a = actual?.lowercase()?.replace(Regex("[^a-z]+"), " ")?.trim()
    val code = countryCode?.lowercase()?.trim()
    return when (e) {
        "us", "usa", "united states", "united states of america" -> code == "us" || a in setOf("united states", "united states of america")
        else -> a == e
    }
}

private fun Map<String, JsonValue>.optionalStringCase(name: String): String? {
    val value = entries.firstOrNull { it.key.equals(name, true) }?.value ?: return null
    return when (value) {
        JsonValue.Null -> null
        is JsonValue.Str -> value.value
        else -> error("$name must be string or null")
    }
}

private fun Map<String, JsonValue>.optionalIntCase(name: String): Int? {
    val value = entries.firstOrNull { it.key.equals(name, true) }?.value ?: return null
    return when (value) {
        JsonValue.Null -> null
        is JsonValue.Num -> value.asInt()
        else -> error("$name must be integer or null")
    }
}

private fun Map<String, JsonValue>.optionalLongCase(name: String): Long? {
    val value = entries.firstOrNull { it.key.equals(name, true) }?.value ?: return null
    return when (value) {
        JsonValue.Null -> null
        is JsonValue.Num -> value.raw.toLongOrNull() ?: error("$name must be long")
        is JsonValue.Str -> value.value.toLongOrNull() ?: error("$name must be long string")
        else -> error("$name must be long or null")
    }
}

private fun Map<String, JsonValue>.optionalBoolCase(name: String): Boolean? {
    val value = entries.firstOrNull { it.key.equals(name, true) }?.value ?: return null
    return when (value) {
        JsonValue.Null -> null
        is JsonValue.Bool -> value.value
        else -> error("$name must be boolean or null")
    }
}

private fun Map<String, JsonValue>.requiredScalarString(name: String): String {
    val value = entries.firstOrNull { it.key.equals(name, true) }?.value ?: error("Missing $name")
    return when (value) {
        is JsonValue.Str -> value.value
        is JsonValue.Num -> value.raw
        else -> error("$name must be scalar")
    }
}

private fun Map<String, JsonValue>.firstScalarString(vararg names: String): String? {
    for (name in names) {
        val value = entries.firstOrNull { it.key.equals(name, true) }?.value ?: continue
        when (value) {
            is JsonValue.Str -> return value.value
            is JsonValue.Num -> return value.raw
            JsonValue.Null -> continue
            else -> error("$name must be scalar")
        }
    }
    return null
}

private fun sha256Provider(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray(Charsets.UTF_8))
    .joinToString("") { "%02x".format(it) }
