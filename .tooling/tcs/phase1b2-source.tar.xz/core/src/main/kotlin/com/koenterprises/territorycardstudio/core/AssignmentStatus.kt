package com.koenterprises.territorycardstudio.core

import java.io.Reader

data class AssignmentStatus(
    val displayId: String,
    val status: String,
    val roadAssignmentStatus: String,
    val buildingAssignmentStatus: String,
    val needsNewCard: Boolean,
    val canonicalFilename: String,
    val referenceFile: String
) {
    val identity: TerritoryIdentity = TerritoryIdentity.parse(displayId)

    init {
        require(identity.canonicalFilename == canonicalFilename) {
            "Canonical filename mismatch for $displayId: expected ${identity.canonicalFilename}, got $canonicalFilename"
        }
        if (needsNewCard) {
            require(status == "needs_new_card") {
                "$displayId is needsNewCard but status=$status"
            }
        }
    }
}

class AssignmentStatusIndex private constructor(
    val records: List<AssignmentStatus>
) {
    private val byDisplayId = records.associateBy { it.displayId }

    fun get(displayId: String): AssignmentStatus? = byDisplayId[displayId]

    val needsNewCard: List<AssignmentStatus>
        get() = records.filter { it.needsNewCard }

    companion object {
        fun load(reader: Reader): AssignmentStatusIndex {
            val rows = Csv4180.parse(reader)
            require(rows.isNotEmpty()) { "Assignment CSV is empty" }
            val header = rows.first()
            val expected = listOf(
                "display_id",
                "status",
                "road_assignment_status",
                "building_assignment_status",
                "needs_new_card",
                "canonical_filename",
                "reference_file"
            )
            require(header == expected) { "Assignment CSV schema drift: $header" }

            val records = rows.drop(1).filter { row -> row.any { it.isNotEmpty() } }.map { row ->
                require(row.size == expected.size) { "Assignment CSV row has ${row.size} fields, expected ${expected.size}" }
                AssignmentStatus(
                    displayId = row[0],
                    status = row[1],
                    roadAssignmentStatus = row[2],
                    buildingAssignmentStatus = row[3],
                    needsNewCard = when (row[4]) {
                        "True" -> true
                        "False" -> false
                        else -> error("Invalid needs_new_card boolean for ${row[0]}: ${row[4]}")
                    },
                    canonicalFilename = row[5],
                    referenceFile = row[6]
                )
            }
            require(records.map { it.displayId }.distinct().size == records.size) {
                "Duplicate display IDs in assignment CSV"
            }
            return AssignmentStatusIndex(records)
        }
    }
}

private object Csv4180 {
    fun parse(reader: Reader): List<List<String>> {
        val text = reader.readText()
        val rows = mutableListOf<MutableList<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0

        fun endField() {
            row.add(field.toString())
            field.setLength(0)
        }

        fun endRow() {
            endField()
            rows.add(row)
            row = mutableListOf()
        }

        while (i < text.length) {
            val c = text[i]
            if (quoted) {
                when {
                    c == '"' && i + 1 < text.length && text[i + 1] == '"' -> {
                        field.append('"')
                        i++
                    }
                    c == '"' -> quoted = false
                    else -> field.append(c)
                }
            } else {
                when (c) {
                    '"' -> {
                        require(field.isEmpty()) { "Unexpected quote in CSV field" }
                        quoted = true
                    }
                    ',' -> endField()
                    '\n' -> endRow()
                    '\r' -> {
                        if (i + 1 < text.length && text[i + 1] == '\n') i++
                        endRow()
                    }
                    else -> field.append(c)
                }
            }
            i++
        }
        require(!quoted) { "Unclosed quoted CSV field" }
        if (field.isNotEmpty() || row.isNotEmpty()) endRow()
        return rows
    }
}
