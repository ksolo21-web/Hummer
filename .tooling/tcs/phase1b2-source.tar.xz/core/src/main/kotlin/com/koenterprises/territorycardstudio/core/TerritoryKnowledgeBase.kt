package com.koenterprises.territorycardstudio.core

import java.io.Reader

data class HousingRenderingPolicy(
    val ordinaryResidential: String,
    val apartmentCondo: String,
    val mobileManufacturedHome: String,
    val mixed: String
)

data class KnowledgeBasePolicy(
    val crossTerritoryGeographyInference: Boolean,
    val unknownAssignmentBehavior: String,
    val plainMapPlusNumberIsAssignmentEvidence: Boolean,
    val roadColorPartition: String,
    val styleReferenceSuppliesGeography: Boolean,
    val unassignedAreaGetsAutomaticNumber: Boolean,
    val unassignedAreaFieldReleaseAllowed: Boolean,
    val promotionRequiresExplicitAssignmentAuthority: Boolean,
    val duplicateWorkBehavior: String,
    val housingRendering: HousingRenderingPolicy
)

data class ReferenceRole(
    val role: String,
    val displayId: String,
    val sha256: String,
    val crossTerritoryGeographyAllowed: Boolean,
    val fieldReleaseAllowed: Boolean
)

data class Point2D(val x: Double, val y: Double)

data class RoadGeometry(
    val segmentId: String,
    val name: String,
    val normalizedName: String,
    val status: String,
    val role: String,
    val insideSide: String,
    val accessOnly: Boolean,
    val endpointAKind: String,
    val endpointBKind: String,
    val widthPt: Double,
    val points: List<Point2D>
)

data class BuildingLabelItem(
    val text: String,
    val center: Point2D,
    val origin: Point2D?,
    val angleDeg: Double,
    val fontSizePt: Double
)

data class BuildingGeometry(
    val buildingId: String,
    val label: String,
    val housingType: String,
    val assigned: Boolean,
    val attachedGroup: String,
    val sourceMembers: List<String>,
    val labelItems: List<BuildingLabelItem>,
    val polygon: List<Point2D>
)

data class AssignmentSignature(
    val namedRoadStatusPairs: List<Pair<String, String>>,
    val statusSegmentCounts: Map<String, Int>,
    val buildingMemberIds: List<String>,
    val housingType: String
)

data class TopologySegment(
    val road: String,
    val status: String,
    val role: String,
    val insideSide: String,
    val accessOnly: Boolean,
    val endpointAKind: String,
    val endpointBKind: String,
    val endpointANeighbors: List<String>,
    val endpointBNeighbors: List<String>
)

data class TopologySignature(
    val junctionBoundedSegments: List<TopologySegment>,
    val segmentCount: Int
)

data class ColorRoleReview(
    val segmentCount: Int,
    val failures: List<String>,
    val passed: Boolean,
    val midSegmentColorTransitionCount: Int,
    val accessOnlyYellowCount: Int
)

data class KnowledgeBaseAssignment(
    val status: String,
    val displayId: String,
    val identity: TerritoryIdentity,
    val baseNumber: Int,
    val cardClass: String,
    val suffix: String,
    val slot: String,
    val canonicalFilename: String,
    val referenceFile: String,
    val referenceSha256: String,
    val sourceHashes: List<String>,
    val sourceClass: String,
    val crossTerritoryInference: Boolean,
    val fieldReleaseAllowedForExactArtifact: Boolean,
    val roadAssignmentStatus: String,
    val buildingAssignmentStatus: String,
    val buildingReauditFailures: List<String>,
    val extractor: String,
    val housingType: String,
    val assignmentSignature: AssignmentSignature?,
    val topologySignature: TopologySignature?,
    val roads: List<RoadGeometry>,
    val buildings: List<BuildingGeometry>,
    val geometryAvailable: Boolean,
    val namedRoadCount: Int,
    val roadCount: Int,
    val buildingCount: Int,
    val geometryFailure: String,
    val colorRoleReview: ColorRoleReview?,
    val roadNameInventory: List<String>,
    val needsNewCard: Boolean,
    val newCardApproved: Boolean?,
    val legacyVisibleId: String?,
    val legacyReferenceFile: String?,
    val approvalNote: String?,
    val visualBenchmark300301: JsonValue?
)

data class CoverageCandidate(
    val candidateId: String,
    val status: String,
    val category: String,
    val area: String,
    val orientation: String,
    val overlapCheck: String,
    val officialTerritoryNumber: String?,
    val assignmentStatus: String,
    val fieldReleaseAllowed: Boolean,
    val source: String
)

data class PermanentPatch(
    val id: String,
    val status: String,
    val rule: String,
    val territory: String?,
    val territories: List<String>,
    val road: String?
)

data class ClassSupersession(
    val slot: String,
    val oldDisplayId: String,
    val newDisplayId: String,
    val reason: String
)

data class NeedsNewCardEntry(
    val displayId: String,
    val status: String,
    val canonicalFilename: String,
    val legacyReferenceFile: String,
    val fieldReleaseAllowed: Boolean
)

data class OverlapCandidate(
    val road: String,
    val territories: List<String>,
    val confidence: String,
    val reason: String
)

data class CrossTerritoryOverlapAudit(
    val blockingDuplicateWork: List<OverlapCandidate>,
    val reviewCandidates: List<OverlapCandidate>,
    val nameOnlyOverlapGroups: List<OverlapCandidate>,
    val allowedSharedContext: List<JsonValue>,
    val blockingCount: Int,
    val reviewCandidateCount: Int,
    val nameOnlyOverlapGroupCount: Int,
    val policy: String
)

data class PopulationSummary(
    val approvedInputCards: Int,
    val activeAssignments: Int,
    val needsNewCardCount: Int,
    val roadGeometryLocked: Int,
    val exactArtifactOnly: Int,
    val vectorExtracted: Int,
    val rasterExtracted: Int,
    val apartmentOrTa: Int,
    val building300301Locked: Int,
    val buildingReauditRequired: Int,
    val coverageScreeningCandidates: Int,
    val classSupersessions: Int,
    val highConfidenceDuplicateWorkBlockers: Int,
    val overlapReviewCandidates: Int,
    val nameOnlyOverlapGroups: Int
)

data class TerritoryKnowledgeBase(
    val schemaVersion: Int,
    val revision: String,
    val policy: KnowledgeBasePolicy,
    val referenceRoles: Map<String, ReferenceRole>,
    val assignments: Map<String, KnowledgeBaseAssignment>,
    val pendingSources: Map<String, JsonValue>,
    val coverageCandidates: Map<String, CoverageCandidate>,
    val masterCoverage: Map<String, JsonValue>,
    val permanentPatches: Map<String, PermanentPatch>,
    val classSupersessions: List<ClassSupersession>,
    val needsNewCardQueue: Map<String, NeedsNewCardEntry>,
    val crossTerritoryOverlapAudit: CrossTerritoryOverlapAudit,
    val populationSummary: PopulationSummary
) {
    init {
        require(schemaVersion == 3) { "Unsupported Territory Knowledge Base schema: $schemaVersion" }
        require(policy.crossTerritoryGeographyInference.not()) { "Cross-territory geography inference must remain disabled" }
        require(policy.unknownAssignmentBehavior == "BLOCK") { "Unknown assignments must BLOCK" }
        require(policy.roadColorPartition == "real_junction_to_real_junction_only") { "Road color partition rule drift" }
        require(policy.promotionRequiresExplicitAssignmentAuthority) { "Explicit assignment authority must be required" }
        require(!policy.unassignedAreaFieldReleaseAllowed) { "Unassigned areas cannot be field released" }
        require(!policy.unassignedAreaGetsAutomaticNumber) { "Unassigned areas cannot be auto-numbered" }
        require(assignments.size == populationSummary.activeAssignments) { "Assignment count mismatch" }
        require(needsNewCardQueue.size == populationSummary.needsNewCardCount) { "needs_new_card count mismatch" }
        require(permanentPatches["GLOBAL-INTERSECTION-COLOR"]?.status == "active") { "Global intersection-color patch missing/inactive" }
        require(permanentPatches["300-301-APARTMENT"]?.status == "active") { "300/301 building patch missing/inactive" }
        require(crossTerritoryOverlapAudit.blockingDuplicateWork.size == crossTerritoryOverlapAudit.blockingCount) { "Overlap blocker count mismatch" }
        require(crossTerritoryOverlapAudit.reviewCandidates.size == crossTerritoryOverlapAudit.reviewCandidateCount) { "Overlap review count mismatch" }
        require(crossTerritoryOverlapAudit.nameOnlyOverlapGroups.size == crossTerritoryOverlapAudit.nameOnlyOverlapGroupCount) { "Name-only overlap count mismatch" }

        assignments.forEach { (key, a) ->
            require(key == a.displayId) { "Assignment key/display_id mismatch: $key vs ${a.displayId}" }
            require(a.identity.displayId == a.displayId) { "Assignment identity mismatch for $key" }
            require(a.identity.canonicalFilename == a.canonicalFilename) { "Assignment canonical filename mismatch for $key" }
            require(a.baseNumber == a.identity.baseNumber) { "Assignment base number mismatch for $key" }
            require(a.cardClass == a.identity.territoryClass.token) { "Assignment class mismatch for $key" }
            require(a.suffix == (a.identity.suffix?.toString() ?: "")) { "Assignment suffix mismatch for $key" }
            require(!a.crossTerritoryInference) { "Cross-territory inference unexpectedly enabled for $key" }
            require(a.roadCount == a.roads.size) { "Road count mismatch for $key" }
            require(a.buildingCount == a.buildings.size) { "Building count mismatch for $key" }
            require(a.buildingAssignmentStatus in setOf("not_applicable", "locked_300_301", "needs_300_301_reaudit")) {
                "Unsupported building assignment status for $key: ${a.buildingAssignmentStatus}"
            }
            if (!a.needsNewCard) {
                val buildingReport = BuildingValidationEngine.validateAssignment(a)
                when (a.buildingAssignmentStatus) {
                    "locked_300_301" -> require(buildingReport.passed) {
                        "$key is locked_300_301 but fails the Android building gate: ${buildingReport.failures}"
                    }
                    "needs_300_301_reaudit" -> {
                        require(!buildingReport.passed) { "$key is marked for 300/301 re-audit but recomputes clean" }
                        require(buildingReport.failures == a.buildingReauditFailures) {
                            "$key building re-audit evidence drift: ${buildingReport.failures} != ${a.buildingReauditFailures}"
                        }
                    }
                    "not_applicable" -> require(!buildingReport.applicable && buildingReport.passed) {
                        "$key not_applicable building policy drift"
                    }
                }
            }
            require(a.topologySignature == null || a.topologySignature.segmentCount == a.topologySignature.junctionBoundedSegments.size) {
                "Topology segment count mismatch for $key"
            }
            if (a.needsNewCard) {
                require(a.status == "needs_new_card") { "$key needs_new_card status drift" }
                require(a.newCardApproved == false) { "$key cannot be pre-approved" }
                require(!a.fieldReleaseAllowedForExactArtifact) { "$key cannot field-release a legacy artifact" }
                require(!a.legacyReferenceFile.isNullOrBlank()) { "$key needs a legacy-reference provenance pointer" }
            }
        }

        referenceRoles.forEach { (path, role) ->
            require(!role.crossTerritoryGeographyAllowed) { "$path cannot authorize cross-territory geography" }
            if (role.role == "style_only") {
                require(!role.fieldReleaseAllowed) { "$path is style-only and cannot field release" }
            }
        }

        coverageCandidates.forEach { (id, candidate) ->
            require(id == candidate.candidateId) { "Coverage candidate key/id mismatch: $id" }
            require(candidate.officialTerritoryNumber == null) { "$id cannot be auto-numbered" }
            require(candidate.assignmentStatus == "unassigned") { "$id must remain unassigned until authority exists" }
            require(!candidate.fieldReleaseAllowed) { "$id cannot field release" }
        }

        needsNewCardQueue.forEach { (id, q) ->
            require(id == q.displayId)
            require(q.status == "needs_new_card") { "$id queue status drift" }
            require(!q.fieldReleaseAllowed) { "$id queue field release must remain blocked" }
            val assignment = assignments[id] ?: error("$id missing from assignments")
            require(assignment.needsNewCard) { "$id queue assignment must have needs_new_card=true" }
            require(assignment.newCardApproved == false) { "$id cannot be pre-approved" }
            require(assignment.canonicalFilename == q.canonicalFilename) { "$id queue filename mismatch" }
        }
    }
}

object TerritoryKnowledgeBaseLoader {
    private val rootKeys = setOf(
        "schema_version", "revision", "policy", "reference_roles", "assignments", "pending_sources",
        "coverage_candidates", "master_coverage", "permanent_patches", "class_supersessions",
        "needs_new_card_queue", "cross_territory_overlap_audit", "population_summary"
    )

    fun load(reader: Reader): TerritoryKnowledgeBase {
        val root = StrictJson.parse(reader).obj("root")
        require(root.keys == rootKeys) { "Knowledge Base root schema drift. Expected $rootKeys, got ${root.keys}" }

        return TerritoryKnowledgeBase(
            schemaVersion = root.required("schema_version", "root").int("root.schema_version"),
            revision = root.required("revision", "root").string("root.revision"),
            policy = policy(root.required("policy", "root")),
            referenceRoles = objectMap(root.required("reference_roles", "root"), "reference_roles", ::referenceRole),
            assignments = objectMap(root.required("assignments", "root"), "assignments", ::assignment),
            pendingSources = root.required("pending_sources", "root").obj("pending_sources"),
            coverageCandidates = objectMap(root.required("coverage_candidates", "root"), "coverage_candidates", ::coverageCandidate),
            masterCoverage = root.required("master_coverage", "root").obj("master_coverage"),
            permanentPatches = root.required("permanent_patches", "root").obj("permanent_patches").mapValues { (id, v) -> permanentPatch(id, v) },
            classSupersessions = root.required("class_supersessions", "root").arr("class_supersessions").mapIndexed { i, v -> classSupersession(v, i) },
            needsNewCardQueue = root.required("needs_new_card_queue", "root").obj("needs_new_card_queue").mapValues { (id, v) -> needsNewCard(id, v) },
            crossTerritoryOverlapAudit = overlapAudit(root.required("cross_territory_overlap_audit", "root")),
            populationSummary = population(root.required("population_summary", "root"))
        )
    }

    private fun policy(v: JsonValue): KnowledgeBasePolicy {
        val o = v.obj("policy")
        val h = o.required("housing_rendering", "policy").obj("policy.housing_rendering")
        return KnowledgeBasePolicy(
            crossTerritoryGeographyInference = o.required("cross_territory_geography_inference", "policy").bool("policy.cross_territory_geography_inference"),
            unknownAssignmentBehavior = o.required("unknown_assignment_behavior", "policy").string("policy.unknown_assignment_behavior"),
            plainMapPlusNumberIsAssignmentEvidence = o.required("plain_map_plus_number_is_assignment_evidence", "policy").bool("policy.plain_map_plus_number_is_assignment_evidence"),
            roadColorPartition = o.required("road_color_partition", "policy").string("policy.road_color_partition"),
            styleReferenceSuppliesGeography = o.required("style_reference_supplies_geography", "policy").bool("policy.style_reference_supplies_geography"),
            unassignedAreaGetsAutomaticNumber = o.required("unassigned_area_gets_automatic_number", "policy").bool("policy.unassigned_area_gets_automatic_number"),
            unassignedAreaFieldReleaseAllowed = o.required("unassigned_area_field_release_allowed", "policy").bool("policy.unassigned_area_field_release_allowed"),
            promotionRequiresExplicitAssignmentAuthority = o.required("promotion_requires_explicit_assignment_authority", "policy").bool("policy.promotion_requires_explicit_assignment_authority"),
            duplicateWorkBehavior = o.required("duplicate_work_behavior", "policy").string("policy.duplicate_work_behavior"),
            housingRendering = HousingRenderingPolicy(
                ordinaryResidential = h.required("ordinary_residential", "policy.housing_rendering").string("housing.ordinary_residential"),
                apartmentCondo = h.required("apartment_condo", "policy.housing_rendering").string("housing.apartment_condo"),
                mobileManufacturedHome = h.required("mobile_manufactured_home", "policy.housing_rendering").string("housing.mobile_manufactured_home"),
                mixed = h.required("mixed", "policy.housing_rendering").string("housing.mixed")
            )
        )
    }

    private fun referenceRole(v: JsonValue, context: String): ReferenceRole {
        val o = v.obj(context)
        return ReferenceRole(
            role = o.required("role", context).string("$context.role"),
            displayId = o.required("display_id", context).string("$context.display_id"),
            sha256 = o.required("sha256", context).string("$context.sha256"),
            crossTerritoryGeographyAllowed = o.required("cross_territory_geography_allowed", context).bool("$context.cross_territory_geography_allowed"),
            fieldReleaseAllowed = (o["field_release_allowed"] as? JsonValue.Bool)?.value ?: false
        )
    }

    private fun assignment(v: JsonValue, context: String): KnowledgeBaseAssignment {
        val o = v.obj(context)
        val displayId = o.required("display_id", context).string("$context.display_id")
        val id = TerritoryIdentity.parse(displayId)
        val assignmentSignature = o["assignment_signature"]?.let { raw ->
            if (raw.obj("$context.assignment_signature").isEmpty()) null else assignmentSignature(raw, "$context.assignment_signature")
        }
        val topologySignature = o["topology_signature"]?.let { topologySignature(it, "$context.topology_signature") }
        val colorRoleReview = o["color_role_review"]?.let { colorRoleReview(it, "$context.color_role_review") }
        return KnowledgeBaseAssignment(
            status = o.required("status", context).string("$context.status"),
            displayId = displayId,
            identity = id,
            baseNumber = o.required("base_number", context).int("$context.base_number"),
            cardClass = o.required("card_class", context).string("$context.card_class"),
            suffix = o.required("suffix", context).string("$context.suffix"),
            slot = o.required("slot", context).string("$context.slot"),
            canonicalFilename = o.required("canonical_filename", context).string("$context.canonical_filename"),
            referenceFile = o.required("reference_file", context).string("$context.reference_file"),
            referenceSha256 = o.required("reference_sha256", context).string("$context.reference_sha256"),
            sourceHashes = o.stringList("source_hashes", context),
            sourceClass = o.required("source_class", context).string("$context.source_class"),
            crossTerritoryInference = o.required("cross_territory_inference", context).bool("$context.cross_territory_inference"),
            fieldReleaseAllowedForExactArtifact = o.required("field_release_allowed_for_exact_artifact", context).bool("$context.field_release_allowed_for_exact_artifact"),
            roadAssignmentStatus = o.required("road_assignment_status", context).string("$context.road_assignment_status"),
            buildingAssignmentStatus = o.required("building_assignment_status", context).string("$context.building_assignment_status"),
            buildingReauditFailures = o["building_reaudit_failures"]?.arr("$context.building_reaudit_failures")?.mapIndexed { i, x -> x.string("$context.building_reaudit_failures[$i]") } ?: emptyList(),
            extractor = o.optionalString("extractor") ?: "",
            housingType = o.optionalString("housing_type") ?: "",
            assignmentSignature = assignmentSignature,
            topologySignature = topologySignature,
            roads = o.required("roads", context).arr("$context.roads").mapIndexed { i, x -> road(x, "$context.roads[$i]") },
            buildings = o.required("buildings", context).arr("$context.buildings").mapIndexed { i, x -> building(x, "$context.buildings[$i]") },
            geometryAvailable = o.required("geometry_available", context).bool("$context.geometry_available"),
            namedRoadCount = o.required("named_road_count", context).int("$context.named_road_count"),
            roadCount = o.required("road_count", context).int("$context.road_count"),
            buildingCount = o.required("building_count", context).int("$context.building_count"),
            geometryFailure = o.required("geometry_failure", context).string("$context.geometry_failure"),
            colorRoleReview = colorRoleReview,
            roadNameInventory = o.stringList("road_name_inventory", context),
            needsNewCard = (o["needs_new_card"] as? JsonValue.Bool)?.value ?: false,
            newCardApproved = (o["new_card_approved"] as? JsonValue.Bool)?.value,
            legacyVisibleId = o.optionalString("legacy_visible_id"),
            legacyReferenceFile = o.optionalString("legacy_reference_file"),
            approvalNote = o.optionalString("approval_note"),
            visualBenchmark300301 = o["visual_benchmark_300_301"]
        )
    }

    private fun assignmentSignature(v: JsonValue, context: String): AssignmentSignature {
        val o = v.obj(context)
        val pairs = o.required("named_road_status_pairs", context).arr("$context.named_road_status_pairs").mapIndexed { i, x ->
            val pair = x.arr("$context.named_road_status_pairs[$i]")
            require(pair.size == 2) { "$context.named_road_status_pairs[$i] must have 2 values" }
            pair[0].string("pair road") to pair[1].string("pair status")
        }
        val counts = o.required("status_segment_counts", context).obj("$context.status_segment_counts").mapValues { (k, n) -> n.int("$context.status_segment_counts.$k") }
        return AssignmentSignature(
            namedRoadStatusPairs = pairs,
            statusSegmentCounts = counts,
            buildingMemberIds = o.stringList("building_member_ids", context),
            housingType = o.required("housing_type", context).string("$context.housing_type")
        )
    }

    private fun topologySignature(v: JsonValue, context: String): TopologySignature {
        val o = v.obj(context)
        val segments = o.required("junction_bounded_segments", context).arr("$context.junction_bounded_segments").mapIndexed { i, x -> topologySegment(x, "$context.junction_bounded_segments[$i]") }
        return TopologySignature(segments, o.required("segment_count", context).int("$context.segment_count"))
    }

    private fun topologySegment(v: JsonValue, context: String): TopologySegment {
        val o = v.obj(context)
        return TopologySegment(
            road = o.required("road", context).string("$context.road"),
            status = o.required("status", context).string("$context.status"),
            role = o.required("role", context).string("$context.role"),
            insideSide = o.required("inside_side", context).string("$context.inside_side"),
            accessOnly = o.required("access_only", context).bool("$context.access_only"),
            endpointAKind = o.required("endpoint_a_kind", context).string("$context.endpoint_a_kind"),
            endpointBKind = o.required("endpoint_b_kind", context).string("$context.endpoint_b_kind"),
            endpointANeighbors = o.stringList("endpoint_a_neighbors", context),
            endpointBNeighbors = o.stringList("endpoint_b_neighbors", context)
        )
    }

    private fun road(v: JsonValue, context: String): RoadGeometry {
        val o = v.obj(context)
        return RoadGeometry(
            segmentId = o.required("segment_id", context).string("$context.segment_id"),
            name = o.required("name", context).string("$context.name"),
            normalizedName = o.required("normalized_name", context).string("$context.normalized_name"),
            status = o.required("status", context).string("$context.status"),
            role = o.required("role", context).string("$context.role"),
            insideSide = o.required("inside_side", context).string("$context.inside_side"),
            accessOnly = o.required("access_only", context).bool("$context.access_only"),
            endpointAKind = o.required("endpoint_a_kind", context).string("$context.endpoint_a_kind"),
            endpointBKind = o.required("endpoint_b_kind", context).string("$context.endpoint_b_kind"),
            widthPt = o.required("width_pt", context).double("$context.width_pt"),
            points = o.required("points", context).arr("$context.points").mapIndexed { i, p -> point(p, "$context.points[$i]") }
        )
    }

    private fun building(v: JsonValue, context: String): BuildingGeometry {
        val o = v.obj(context)
        return BuildingGeometry(
            buildingId = o.required("building_id", context).string("$context.building_id"),
            label = o.required("label", context).string("$context.label"),
            housingType = o.required("housing_type", context).string("$context.housing_type"),
            assigned = o.required("assigned", context).bool("$context.assigned"),
            attachedGroup = o.required("attached_group", context).string("$context.attached_group"),
            sourceMembers = o.stringList("source_members", context),
            labelItems = o.required("label_items", context).arr("$context.label_items").mapIndexed { i, x ->
                buildingLabelItem(x, "$context.label_items[$i]")
            },
            polygon = o.required("polygon", context).arr("$context.polygon").mapIndexed { i, p -> point(p, "$context.polygon[$i]") }
        )
    }

    private fun buildingLabelItem(v: JsonValue, context: String): BuildingLabelItem {
        val o = v.obj(context)
        return BuildingLabelItem(
            text = o.required("text", context).string("$context.text"),
            center = point(o.required("center", context), "$context.center"),
            origin = o["origin"]?.let { point(it, "$context.origin") },
            angleDeg = o.required("angle_deg", context).double("$context.angle_deg"),
            fontSizePt = o.required("font_size_pt", context).double("$context.font_size_pt")
        )
    }

    private fun point(v: JsonValue, context: String): Point2D {
        val a = v.arr(context)
        require(a.size == 2) { "$context must contain exactly x,y" }
        return Point2D(a[0].double("$context.x"), a[1].double("$context.y"))
    }

    private fun colorRoleReview(v: JsonValue, context: String): ColorRoleReview {
        val o = v.obj(context)
        return ColorRoleReview(
            segmentCount = o.required("segment_count", context).int("$context.segment_count"),
            failures = o.required("failures", context).arr("$context.failures").mapIndexed { i, x -> x.string("$context.failures[$i]") },
            passed = o.required("passed", context).bool("$context.passed"),
            midSegmentColorTransitionCount = o.required("mid_segment_color_transition_count", context).int("$context.mid_segment_color_transition_count"),
            accessOnlyYellowCount = o.required("access_only_yellow_count", context).int("$context.access_only_yellow_count")
        )
    }

    private fun coverageCandidate(v: JsonValue, context: String): CoverageCandidate {
        val o = v.obj(context)
        return CoverageCandidate(
            candidateId = o.required("candidate_id", context).string("$context.candidate_id"),
            status = o.required("status", context).string("$context.status"),
            category = o.required("category", context).string("$context.category"),
            area = o.required("area", context).string("$context.area"),
            orientation = o.required("orientation", context).string("$context.orientation"),
            overlapCheck = o.required("overlap_check", context).string("$context.overlap_check"),
            officialTerritoryNumber = o.optionalString("official_territory_number"),
            assignmentStatus = o.required("assignment_status", context).string("$context.assignment_status"),
            fieldReleaseAllowed = o.required("field_release_allowed", context).bool("$context.field_release_allowed"),
            source = o.required("source", context).string("$context.source")
        )
    }

    private fun permanentPatch(id: String, v: JsonValue): PermanentPatch {
        val context = "permanent_patches.$id"
        val o = v.obj(context)
        return PermanentPatch(
            id = id,
            status = o.required("status", context).string("$context.status"),
            rule = o.required("rule", context).string("$context.rule"),
            territory = o.optionalString("territory"),
            territories = o["territories"]?.arr("$context.territories")?.mapIndexed { i, x -> x.string("$context.territories[$i]") } ?: emptyList(),
            road = o.optionalString("road")
        )
    }

    private fun classSupersession(v: JsonValue, i: Int): ClassSupersession {
        val context = "class_supersessions[$i]"
        val o = v.obj(context)
        return ClassSupersession(
            slot = o.required("slot", context).string("$context.slot"),
            oldDisplayId = o.required("old_display_id", context).string("$context.old_display_id"),
            newDisplayId = o.required("new_display_id", context).string("$context.new_display_id"),
            reason = o.required("reason", context).string("$context.reason")
        )
    }

    private fun needsNewCard(id: String, v: JsonValue): NeedsNewCardEntry {
        val context = "needs_new_card_queue.$id"
        val o = v.obj(context)
        return NeedsNewCardEntry(
            displayId = id,
            status = o.required("status", context).string("$context.status"),
            canonicalFilename = o.required("canonical_filename", context).string("$context.canonical_filename"),
            legacyReferenceFile = o.required("legacy_reference_file", context).string("$context.legacy_reference_file"),
            fieldReleaseAllowed = o.required("field_release_allowed", context).bool("$context.field_release_allowed")
        )
    }

    private fun overlapAudit(v: JsonValue): CrossTerritoryOverlapAudit {
        val context = "cross_territory_overlap_audit"
        val o = v.obj(context)
        fun candidates(name: String): List<OverlapCandidate> = o.required(name, context).arr("$context.$name").mapIndexed { i, x -> overlapCandidate(x, "$context.$name[$i]") }
        return CrossTerritoryOverlapAudit(
            blockingDuplicateWork = candidates("blocking_duplicate_work"),
            reviewCandidates = candidates("review_candidates"),
            nameOnlyOverlapGroups = candidates("name_only_overlap_groups"),
            allowedSharedContext = o.required("allowed_shared_context", context).arr("$context.allowed_shared_context"),
            blockingCount = o.required("blocking_count", context).int("$context.blocking_count"),
            reviewCandidateCount = o.required("review_candidate_count", context).int("$context.review_candidate_count"),
            nameOnlyOverlapGroupCount = o.required("name_only_overlap_group_count", context).int("$context.name_only_overlap_group_count"),
            policy = o.required("policy", context).string("$context.policy")
        )
    }

    private fun overlapCandidate(v: JsonValue, context: String): OverlapCandidate {
        val o = v.obj(context)
        return OverlapCandidate(
            road = o.required("road", context).string("$context.road"),
            territories = o.stringList("territories", context),
            confidence = o.required("confidence", context).string("$context.confidence"),
            reason = o.required("reason", context).string("$context.reason")
        )
    }

    private fun population(v: JsonValue): PopulationSummary {
        val context = "population_summary"
        val o = v.obj(context)
        fun n(name: String) = o.required(name, context).int("$context.$name")
        return PopulationSummary(
            approvedInputCards = n("approved_input_cards"),
            activeAssignments = n("active_assignments"),
            needsNewCardCount = n("needs_new_card_count"),
            roadGeometryLocked = n("road_geometry_locked"),
            exactArtifactOnly = n("exact_artifact_only"),
            vectorExtracted = n("vector_extracted"),
            rasterExtracted = n("raster_extracted"),
            apartmentOrTa = n("apartment_or_ta"),
            building300301Locked = n("building_300_301_locked"),
            buildingReauditRequired = n("building_reaudit_required"),
            coverageScreeningCandidates = n("coverage_screening_candidates"),
            classSupersessions = n("class_supersessions"),
            highConfidenceDuplicateWorkBlockers = n("high_confidence_duplicate_work_blockers"),
            overlapReviewCandidates = n("overlap_review_candidates"),
            nameOnlyOverlapGroups = n("name_only_overlap_groups")
        )
    }

    private fun <T> objectMap(v: JsonValue, context: String, convert: (JsonValue, String) -> T): Map<String, T> =
        v.obj(context).mapValues { (k, x) -> convert(x, "$context.$k") }
}
