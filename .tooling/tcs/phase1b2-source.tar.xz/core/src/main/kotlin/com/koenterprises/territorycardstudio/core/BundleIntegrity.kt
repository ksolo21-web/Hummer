package com.koenterprises.territorycardstudio.core

import java.io.InputStream
import java.security.MessageDigest

object BundleIntegrity {
    val requiredSha256: Map<String, String> = linkedMapOf(
        "Territory-Knowledge-Base.json" to "1f228ee88905f98cb5affc7db016ff35303c45c460c149ec03f84afb5e2d9f4a",
        "Knowledge_Base_Assignment_Status.csv" to "426fd44ae4a5084b24c4f738e0eb8a11ca437050b4b5a53c6f010ab66e8800bf",
        "NEEDS_NEW_CARD_QUEUE.json" to "efd22d7ea6e9913305a0898f1b0728865138b59b065fd7083f79f2225ffb9a3b",
        "R48-Canonical-Style-Tokens.json" to "ced211f7df0d2dafffb6d05bde4640a8bd2c1b0a44719b986a57c11a65d792fe",
        "Online-Source-Policy.json" to "7a42a1462bdd679d56fb02c0b88e4090e2598c4cfc6793b0af4b8538e5f2d3f1",
        "REFERENCE-MANIFEST.json" to "f09bbe2ca432f5999576eaab0c1b7da2e09ec3c50f7d3500dce0b426c81f2907",
        "Territory-Source-Truth-Knowledge-Base-Contract.md" to "7ced301b10f07e6043ce374148529159194494f14e390e5b83e7547a88c53540",
        "Provider-Endpoint-Switches.properties" to "1e023870483def138eb6b512f6f6ce2af6edaede341c5836fc570e78f72781ad",
        "render-authority/Canonical-New-Designed-Template-R48.pdf" to "9de0e819a0301b6d6b7dfdce8851e94839d4de2b72f5e3f2ca55d27579973ee4",
        "render-authority/a33-directions-car.png" to "34c61891dcfd6d5c7a45cf0acbbead99184d5141f8578860a688880d715d636d",
        "render-authority/render_locked_template.py" to "8a79a906b0c2b80d3346283ddb9c83211f2c7a628674504d13a71dee155bc70a",
        "render-authority/Locked-Template-Style-Token-Contract.md" to "f337f59fd235347d2d04431c664101273bc83e43ca7713ef20016827a7da0bc7",
        "render-authority/validators/validate_style_token_layer.py" to "f65bad6f9cf2f2b6f7765a2e092c073a7e23c606f28df25d6fa0b072651b8184",
        "render-authority/validators/validate_pdf_identity.py" to "1e7faa125511cf937bef4eaa183388aa12e7b58a61bc6bd0a772d6f95ad69aa3",
        "render-authority/validators/validate_territory_identity.py" to "d80fbba2e0fc6bbe3ab947ee1a092d517e4952f6bfcb0478271cff3961ed7c9b",
        "render-authority/validators/territory_identity.py" to "4b61a1806574b9007fd3ab9602c46c4984892b435da43622411743948925fba8",
        "render-authority/validators/validate_pdf_label_metrics.py" to "510a028e53a42ecac376cb32995981caed7f9909d565d22f69804d7b7596d0c1",
        "render-authority/validators/validate_label_navigation_contract.py" to "38c2205b16b7e4e858a7027d0ad0495c50531f3d182b2a46fc230ed488f8ea4f",
        "render-authority/validators/validate_critic_visual_hard_overrides.py" to "65b2c640e8f3344ee2d71af14beba5a5b7bf02e36f9aedf9b28edcb61c8bc920"
    )

    fun sha256(input: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            digest.update(buffer, 0, read)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
