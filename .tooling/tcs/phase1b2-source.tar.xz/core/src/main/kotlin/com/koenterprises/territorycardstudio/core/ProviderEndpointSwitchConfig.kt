package com.koenterprises.territorycardstudio.core

import java.io.Reader
import java.net.URI
import java.util.Properties

private const val ENDPOINT_SWITCH_SCHEMA = 1
private const val ENDPOINT_SWITCH_BASE_REVISION = "2026-09-24-live-verification-v1"
private val ENDPOINT_PROVIDER_IDS = listOf(
    "oakland_county_roads",
    "oakland_county_site_addresses",
    "oakland_county_buildings",
    "census_tigerweb_transportation",
    "openstreetmap_overpass",
    "google_geocoding",
    "google_roads"
)

data class ProviderEndpointSwitchConfig(
    val schemaVersion: Int,
    val revision: String,
    val revisionSeq: Int,
    val basePolicyRevision: String,
    val primaryEndpoints: Map<String, String>,
    val secondaryEndpoints: Map<String, String>
) {
    init {
        require(schemaVersion == ENDPOINT_SWITCH_SCHEMA) { "Unsupported endpoint-switch schema $schemaVersion" }
        require(revision.matches(Regex("^\\d{4}-\\d{2}-\\d{2}-endpoint-switch-v\\d+$"))) { "Invalid endpoint-switch revision $revision" }
        require(revisionSeq >= 1) { "Endpoint-switch revision sequence must be positive" }
        require(basePolicyRevision == ENDPOINT_SWITCH_BASE_REVISION) { "Endpoint-switch base policy revision drift" }
        require(primaryEndpoints.keys == ENDPOINT_PROVIDER_IDS.toSet()) { "Endpoint-switch provider set drift: ${primaryEndpoints.keys}" }
        require(secondaryEndpoints.keys == setOf("openstreetmap_overpass")) { "Endpoint-switch secondary set drift: ${secondaryEndpoints.keys}" }
        (primaryEndpoints.values + secondaryEndpoints.values).forEach(::requireSafeHttpsEndpoint)
    }

    fun applyTo(policy: OnlineSourcePolicy): OnlineSourcePolicy {
        require(policy.revision == basePolicyRevision) { "Endpoint-switch policy revision mismatch" }
        require(policy.providers.keys == primaryEndpoints.keys) { "Endpoint-switch cannot change provider set" }
        val providers = policy.providers.mapValues { (id, original) ->
            val secondary = if (id == "openstreetmap_overpass") secondaryEndpoints.getValue(id) else original.secondaryEndpoint
            original.copy(
                primaryEndpoint = primaryEndpoints.getValue(id),
                secondaryEndpoint = secondary
            )
        }
        // Reconstructing OnlineSourcePolicy re-runs every provider-role/release-policy invariant.
        return policy.copy(providers = providers)
    }
}

object ProviderEndpointSwitchConfigLoader {
    private val expectedKeys = buildSet {
        add("schema_version")
        add("revision")
        add("revision_seq")
        add("base_policy_revision")
        ENDPOINT_PROVIDER_IDS.forEach { add("$it.primary") }
        add("openstreetmap_overpass.secondary")
    }

    fun load(reader: Reader): ProviderEndpointSwitchConfig {
        val text = reader.readText()
        val lines = text.lineSequence()
            .map(String::trim)
            .filter { it.isNotEmpty() && !it.startsWith('#') }
            .toList()
        val keys = lines.map { line ->
            val index = line.indexOf('=')
            require(index > 0) { "Malformed endpoint-switch line" }
            line.substring(0, index).trim()
        }
        require(keys.distinct().size == keys.size) { "Duplicate endpoint-switch key" }
        require(keys.toSet() == expectedKeys) { "Endpoint-switch schema drift: ${keys.toSet()}" }

        val props = Properties().apply { text.reader().use(::load) }
        val primary = ENDPOINT_PROVIDER_IDS.associateWith { id -> props.getProperty("$id.primary")?.trim().orEmpty() }
        val secondary = mapOf(
            "openstreetmap_overpass" to props.getProperty("openstreetmap_overpass.secondary")?.trim().orEmpty()
        )
        return ProviderEndpointSwitchConfig(
            schemaVersion = props.getProperty("schema_version")?.toIntOrNull() ?: error("Invalid endpoint-switch schema_version"),
            revision = props.getProperty("revision")?.trim().orEmpty(),
            revisionSeq = props.getProperty("revision_seq")?.toIntOrNull() ?: error("Invalid endpoint-switch revision_seq"),
            basePolicyRevision = props.getProperty("base_policy_revision")?.trim().orEmpty(),
            primaryEndpoints = primary,
            secondaryEndpoints = secondary
        )
    }
}

private fun requireSafeHttpsEndpoint(value: String) {
    require(value.isNotBlank()) { "Provider endpoint cannot be blank" }
    val uri = URI(value)
    require(uri.scheme.equals("https", ignoreCase = true)) { "Provider endpoint must use HTTPS" }
    require(uri.userInfo == null) { "Provider endpoint cannot contain user info" }
    require(uri.fragment == null) { "Provider endpoint cannot contain a fragment" }
    require(uri.host != null) { "Provider endpoint must contain a host" }
    val host = uri.host.lowercase()
    require(host != "localhost" && !host.endsWith(".localhost") && !host.endsWith(".local")) { "Private/local provider endpoint forbidden" }
    require(host != "::1" && host != "0.0.0.0" && !host.startsWith("127.")) { "Loopback provider endpoint forbidden" }
    require(!host.startsWith("10.") && !host.startsWith("192.168.")) { "Private provider endpoint forbidden" }
    val parts = host.split('.')
    if (parts.size == 4) {
        val first = parts[0].toIntOrNull()
        val second = parts[1].toIntOrNull()
        require(!(first == 172 && second != null && second in 16..31)) { "Private provider endpoint forbidden" }
        require(!(first == 169 && second == 254)) { "Link-local provider endpoint forbidden" }
    }
}
