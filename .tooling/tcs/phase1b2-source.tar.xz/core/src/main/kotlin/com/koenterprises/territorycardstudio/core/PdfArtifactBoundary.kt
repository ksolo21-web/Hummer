package com.koenterprises.territorycardstudio.core

enum class PdfArtifactAction {
    EXACT_APPROVED_PASSTHROUGH,
    VALIDATED_CANDIDATE_RENDER,
    BLOCKED
}

enum class PdfFieldReleaseState {
    ALLOWED,
    AWAITING_EXPLICIT_USER_APPROVAL,
    BLOCKED
}

class PdfArtifactAuthorization internal constructor(
    val displayId: String,
    val canonicalFilename: String,
    val action: PdfArtifactAction,
    val renderAllowed: Boolean,
    val fieldReleaseState: PdfFieldReleaseState,
    val expectedSha256: String?,
    val reason: String
)

data class CandidateRenderValidationReceipt(
    val displayId: String,
    val canonicalFilename: String,
    val knowledgeBaseRevision: String,
    val assignmentAuthorityRole: String,
    val assignmentAuthoritySha256: String,
    val sourceTruthPassed: Boolean,
    val liveGeometryVerificationPassed: Boolean,
    val topologyOverlapPassed: Boolean,
    val buildingValidationPassed: Boolean,
    val labelValidationPassed: Boolean,
    val styleTokenSha256: String,
    val templatePdfSha256: String,
    val rendererSha256: String,
    val rendererContractSha256: String,
    val directionsBadgeSha256: String
)

data class CandidatePdfArtifactReceipt(
    val displayId: String,
    val canonicalFilename: String,
    val pdfSha256: String,
    val renderValidation: CandidateRenderValidationReceipt
)

data class CandidateReleaseReview(
    val reviewedPdfSha256: String,
    val finalPdfValidatorsPassed: Boolean,
    val mandatoryReviewPassed: Boolean,
    val explicitUserApproval: Boolean,
    val approvalRecordedInAuthorityLayer: Boolean
)

object PdfArtifactBoundary {
    private val sha256Pattern = Regex("^[0-9a-f]{64}$")

    fun authorizeExactApprovedPassthrough(
        kb: TerritoryKnowledgeBase,
        displayId: String,
        fileName: String,
        artifactSha256: String
    ): PdfArtifactAuthorization {
        val assignment = kb.assignments[displayId]
            ?: return blocked(displayId, fileName, "Unknown territory assignment")
        if (assignment.needsNewCard) {
            return blocked(displayId, assignment.canonicalFilename, "needs_new_card legacy artifacts may never be released as current approved cards")
        }
        if (!assignment.fieldReleaseAllowedForExactArtifact) {
            return blocked(displayId, assignment.canonicalFilename, "Exact-artifact field release is not authorized")
        }
        val role = kb.referenceRoles[assignment.referenceFile]
            ?: return blocked(displayId, assignment.canonicalFilename, "Approved reference role is missing")
        if (role.role != "exact_assignment_reference" || !role.fieldReleaseAllowed) {
            return blocked(displayId, assignment.canonicalFilename, "Reference is not an exact releasable assignment artifact")
        }
        if (fileName != assignment.canonicalFilename) {
            return blocked(displayId, assignment.canonicalFilename, "Exact approved artifact filename mismatch")
        }
        if (artifactSha256 != assignment.referenceSha256 || artifactSha256 != role.sha256) {
            return blocked(displayId, assignment.canonicalFilename, "Exact approved artifact SHA-256 mismatch")
        }
        return PdfArtifactAuthorization(
            displayId = displayId,
            canonicalFilename = assignment.canonicalFilename,
            action = PdfArtifactAction.EXACT_APPROVED_PASSTHROUGH,
            renderAllowed = false,
            fieldReleaseState = PdfFieldReleaseState.ALLOWED,
            expectedSha256 = assignment.referenceSha256,
            reason = "Approved exact artifact must pass through byte-for-byte; renderer invocation is forbidden"
        )
    }

    fun authorizeCandidateRender(
        kb: TerritoryKnowledgeBase,
        receipt: CandidateRenderValidationReceipt
    ): PdfArtifactAuthorization {
        val assignment = kb.assignments[receipt.displayId]
            ?: return blocked(receipt.displayId, receipt.canonicalFilename, "Unknown territory assignment")
        if (!assignment.needsNewCard) {
            return blocked(
                receipt.displayId,
                assignment.canonicalFilename,
                "Current approved territory requires exact-artifact passthrough; silent regeneration is forbidden"
            )
        }
        if (receipt.canonicalFilename != assignment.canonicalFilename) {
            return blocked(receipt.displayId, assignment.canonicalFilename, "Candidate canonical filename mismatch")
        }
        if (receipt.knowledgeBaseRevision != kb.revision) {
            return blocked(receipt.displayId, assignment.canonicalFilename, "Candidate Knowledge Base revision mismatch")
        }
        if (receipt.assignmentAuthorityRole != "current_authoritative_assignment") {
            return blocked(receipt.displayId, assignment.canonicalFilename, "Candidate requires current authoritative assignment evidence")
        }
        if (!sha256Pattern.matches(receipt.assignmentAuthoritySha256)) {
            return blocked(receipt.displayId, assignment.canonicalFilename, "Candidate assignment authority SHA-256 is invalid")
        }
        val mandatoryGates = linkedMapOf(
            "source truth" to receipt.sourceTruthPassed,
            "live geometry verification" to receipt.liveGeometryVerificationPassed,
            "topology/overlap" to receipt.topologyOverlapPassed,
            "building validation" to receipt.buildingValidationPassed,
            "label validation" to receipt.labelValidationPassed
        )
        val failed = mandatoryGates.filterValues { !it }.keys
        if (failed.isNotEmpty()) {
            return blocked(receipt.displayId, assignment.canonicalFilename, "Candidate render blocked by: ${failed.joinToString()}")
        }
        if (receipt.styleTokenSha256 != LockedPdfRendererAuthorityHashes.STYLE_TOKENS_SHA256 ||
            receipt.templatePdfSha256 != LockedPdfRendererAuthorityHashes.TEMPLATE_PDF_SHA256 ||
            receipt.rendererSha256 != LockedPdfRendererAuthorityHashes.RENDERER_SHA256 ||
            receipt.rendererContractSha256 != LockedPdfRendererAuthorityHashes.CONTRACT_SHA256 ||
            receipt.directionsBadgeSha256 != LockedPdfRendererAuthorityHashes.DIRECTIONS_BADGE_SHA256
        ) {
            return blocked(receipt.displayId, assignment.canonicalFilename, "Locked renderer/style authority provenance mismatch")
        }

        return PdfArtifactAuthorization(
            displayId = receipt.displayId,
            canonicalFilename = assignment.canonicalFilename,
            action = PdfArtifactAction.VALIDATED_CANDIDATE_RENDER,
            renderAllowed = true,
            fieldReleaseState = PdfFieldReleaseState.AWAITING_EXPLICIT_USER_APPROVAL,
            expectedSha256 = null,
            reason = "Validation permits candidate PDF rendering only; field release remains blocked pending explicit user approval"
        )
    }

    fun authorizeCandidateRelease(
        kb: TerritoryKnowledgeBase,
        artifact: CandidatePdfArtifactReceipt,
        review: CandidateReleaseReview
    ): PdfArtifactAuthorization {
        val assignment = kb.assignments[artifact.displayId]
            ?: return blocked(artifact.displayId, artifact.canonicalFilename, "Unknown territory assignment")
        if (artifact.canonicalFilename != assignment.canonicalFilename) {
            return blocked(artifact.displayId, assignment.canonicalFilename, "Candidate release filename mismatch")
        }
        if (!sha256Pattern.matches(artifact.pdfSha256) || review.reviewedPdfSha256 != artifact.pdfSha256) {
            return blocked(artifact.displayId, assignment.canonicalFilename, "Reviewed PDF hash does not match candidate artifact")
        }
        val renderAuth = authorizeCandidateRender(kb, artifact.renderValidation)
        if (!renderAuth.renderAllowed) return PdfArtifactAuthorization(
            displayId = renderAuth.displayId,
            canonicalFilename = renderAuth.canonicalFilename,
            action = renderAuth.action,
            renderAllowed = renderAuth.renderAllowed,
            fieldReleaseState = renderAuth.fieldReleaseState,
            expectedSha256 = renderAuth.expectedSha256,
            reason = "Release blocked because render authorization is no longer valid: ${renderAuth.reason}"
        )
        if (!review.finalPdfValidatorsPassed) {
            return blocked(artifact.displayId, assignment.canonicalFilename, "Final exact-PDF validators have not passed")
        }
        if (!review.mandatoryReviewPassed) {
            return blocked(artifact.displayId, assignment.canonicalFilename, "Mandatory exact-PDF review has not passed")
        }
        if (!review.explicitUserApproval || !review.approvalRecordedInAuthorityLayer) {
            return PdfArtifactAuthorization(
                displayId = artifact.displayId,
                canonicalFilename = assignment.canonicalFilename,
                action = PdfArtifactAction.VALIDATED_CANDIDATE_RENDER,
                renderAllowed = true,
                fieldReleaseState = PdfFieldReleaseState.AWAITING_EXPLICIT_USER_APPROVAL,
                expectedSha256 = artifact.pdfSha256,
                reason = "Candidate remains unapproved; explicit user approval must be recorded before promotion"
            )
        }
        return blocked(
            artifact.displayId,
            assignment.canonicalFilename,
            "User approval is acknowledged, but field release remains blocked until the reviewed PDF is promoted into the authoritative current-assignment layer"
        )
    }

    private fun blocked(displayId: String, canonicalFilename: String, reason: String) = PdfArtifactAuthorization(
        displayId = displayId,
        canonicalFilename = canonicalFilename,
        action = PdfArtifactAction.BLOCKED,
        renderAllowed = false,
        fieldReleaseState = PdfFieldReleaseState.BLOCKED,
        expectedSha256 = null,
        reason = reason
    )
}

object ExactApprovedPdfPassthrough {
    fun copyVerified(
        authorization: PdfArtifactAuthorization,
        input: java.io.InputStream,
        output: java.io.OutputStream
    ): String {
        require(authorization.action == PdfArtifactAction.EXACT_APPROVED_PASSTHROUGH) {
            "Exact passthrough requires EXACT_APPROVED_PASSTHROUGH authorization"
        }
        require(!authorization.renderAllowed) { "Exact passthrough must never invoke the renderer" }
        val expected = requireNotNull(authorization.expectedSha256) { "Exact passthrough is missing an expected SHA-256" }
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            digest.update(buffer, 0, read)
            output.write(buffer, 0, read)
        }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        require(actual == expected) { "Exact approved PDF bytes changed or do not match authority: $actual != $expected" }
        return actual
    }
}
