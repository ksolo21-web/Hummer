package com.koenterprises.territorycardstudio.core

import java.io.Reader

data class StreetFontContract(
    val family: String,
    val regularOnly: Boolean,
    val minimumSizePt: Double,
    val normalSizePt: Double,
    val denseSizePt: Double,
    val colorHex: String,
    val noFontSubstitution: Boolean
)

data class LabelPlacementContract(
    val assignedRoadGapHardMinPx: Double,
    val assignedRoadGapHardMaxPx: Double,
    val assignedRoadGapPreferredMinPx: Double,
    val assignedRoadGapPreferredMaxPx: Double,
    val assignedRoadGapTargetPx: Double,
    val sameCardGapTolerancePx: Double,
    val ordinaryEndBreathingTargetPx: Double,
    val ordinaryEndBreathingMinPx: Double,
    val shortStreetEndBreathingMinPx: Double,
    val shortStreetExtraRunPx: Double,
    val calloutTailGapMinPx: Double,
    val calloutTailGapMaxPx: Double,
    val calloutPreferredMaxLengthPx: Double,
    val calloutHardMaxLengthPx: Double,
    val placementOrder: List<LabelPlacementMode>,
    val perimeterBorderLabelsExteriorRequired: Boolean,
    val streetLabelAnyObjectOverlapAllowed: Boolean,
    val mixedStatusColorOverlapAllowed: Boolean
)

data class LabelStyleContract(
    val streetFont: StreetFontContract,
    val placement: LabelPlacementContract
) {
    init {
        require(streetFont.family == "DejaVu Sans") { "Street font family drift: ${streetFont.family}" }
        require(streetFont.regularOnly) { "Street labels must remain regular-weight only" }
        require(streetFont.minimumSizePt >= 8.0) { "Street minimum font size cannot drop below 8 pt" }
        require(streetFont.normalSizePt >= streetFont.minimumSizePt) { "Normal street font is below the minimum" }
        require(streetFont.denseSizePt >= streetFont.minimumSizePt) { "Dense street font is below the minimum" }
        require(streetFont.noFontSubstitution) { "Font substitution must remain disabled" }

        require(placement.assignedRoadGapHardMinPx == 2.0) { "Direct/curved hard gap minimum must remain 2 px" }
        require(placement.assignedRoadGapHardMaxPx == 4.0) { "Direct/curved hard gap maximum must remain 4 px" }
        require(placement.assignedRoadGapTargetPx == 3.0) { "Direct/curved target gap must remain 3 px" }
        require(placement.assignedRoadGapPreferredMinPx <= placement.assignedRoadGapTargetPx)
        require(placement.assignedRoadGapTargetPx <= placement.assignedRoadGapPreferredMaxPx)
        require(placement.sameCardGapTolerancePx in 0.0..1.0) { "Same-card road-gap tolerance cannot exceed 1 px" }
        require(placement.ordinaryEndBreathingMinPx > 0.0)
        require(placement.ordinaryEndBreathingTargetPx >= placement.ordinaryEndBreathingMinPx)
        require(placement.shortStreetEndBreathingMinPx >= placement.ordinaryEndBreathingMinPx)
        require(placement.shortStreetExtraRunPx >= 0.0)
        require(placement.calloutTailGapMinPx == 0.0) { "Callout tail-gap minimum must remain 0 px" }
        require(placement.calloutTailGapMaxPx == 2.0) { "Callout tail-gap maximum must remain 2 px" }
        require(placement.calloutPreferredMaxLengthPx == 80.0) { "Callout preferred maximum must remain 80 px" }
        require(placement.calloutHardMaxLengthPx == 110.0) { "Callout hard maximum must remain 110 px" }
        require(placement.perimeterBorderLabelsExteriorRequired) { "Perimeter labels must remain exterior" }
        require(!placement.streetLabelAnyObjectOverlapAllowed) { "Street-label/object overlap must remain forbidden" }
        require(!placement.mixedStatusColorOverlapAllowed) { "Mixed-status color overlap must remain forbidden" }

        val expectedOrder = listOf(
            LabelPlacementMode.DIRECT_ROAD_FOLLOWING,
            LabelPlacementMode.CURVED_ROAD_FOLLOWING,
            LabelPlacementMode.SAME_ROAD_RELOCATION,
            LabelPlacementMode.NEARBY_ATTACHED_ARROW_CALLOUT,
            LabelPlacementMode.DEDICATED_DETAIL
        )
        require(placement.placementOrder == expectedOrder) {
            "Street-label placement order drift: ${placement.placementOrder}"
        }
    }
}

object LabelStyleContractLoader {
    fun load(reader: Reader): LabelStyleContract {
        val root = StrictJson.parse(reader).obj("style tokens")
        val fonts = root.required("fonts", "style tokens").obj("fonts")
        val type = root.required("type", "style tokens").obj("type")
        val street = type.required("street", "type").obj("type.street")
        val labels = root.required("label_rules", "style tokens").obj("label_rules")
        val locked = root.required("locked_new_output", "style tokens").obj("locked_new_output")

        val hardGap = numberPair(labels, "assigned_road_gap_hard_px", "label_rules")
        val preferredGap = numberPair(labels, "assigned_road_gap_preferred_px", "label_rules")
        val tailGap = numberPair(labels, "callout_tail_gap_px", "label_rules")
        val order = labels.required("placement_order", "label_rules")
            .arr("label_rules.placement_order")
            .mapIndexed { index, value ->
                LabelPlacementMode.fromStyleToken(value.string("label_rules.placement_order[$index]"))
            }

        return LabelStyleContract(
            streetFont = StreetFontContract(
                family = fonts.required("new_output_family", "fonts").string("fonts.new_output_family"),
                regularOnly = fonts.required("street_regular_only", "fonts").bool("fonts.street_regular_only"),
                minimumSizePt = fonts.required("minimum_street_pt", "fonts").double("fonts.minimum_street_pt"),
                normalSizePt = street.required("size_pt", "type.street").double("type.street.size_pt"),
                denseSizePt = street.required("dense_size_pt", "type.street").double("type.street.dense_size_pt"),
                colorHex = street.required("color", "type.street").string("type.street.color"),
                noFontSubstitution = locked.required("no_font_substitution", "locked_new_output")
                    .bool("locked_new_output.no_font_substitution")
            ),
            placement = LabelPlacementContract(
                assignedRoadGapHardMinPx = hardGap.first,
                assignedRoadGapHardMaxPx = hardGap.second,
                assignedRoadGapPreferredMinPx = preferredGap.first,
                assignedRoadGapPreferredMaxPx = preferredGap.second,
                assignedRoadGapTargetPx = labels.required("assigned_road_gap_target_px", "label_rules")
                    .double("label_rules.assigned_road_gap_target_px"),
                sameCardGapTolerancePx = labels.required("same_card_gap_tolerance_px", "label_rules")
                    .double("label_rules.same_card_gap_tolerance_px"),
                ordinaryEndBreathingTargetPx = labels.required("ordinary_end_breathing_target_px", "label_rules")
                    .double("label_rules.ordinary_end_breathing_target_px"),
                ordinaryEndBreathingMinPx = labels.required("ordinary_end_breathing_min_px", "label_rules")
                    .double("label_rules.ordinary_end_breathing_min_px"),
                shortStreetEndBreathingMinPx = labels.required("short_street_end_breathing_min_px", "label_rules")
                    .double("label_rules.short_street_end_breathing_min_px"),
                shortStreetExtraRunPx = labels.required("short_street_extra_run_px", "label_rules")
                    .double("label_rules.short_street_extra_run_px"),
                calloutTailGapMinPx = tailGap.first,
                calloutTailGapMaxPx = tailGap.second,
                calloutPreferredMaxLengthPx = labels.required("callout_preferred_max_length_px", "label_rules")
                    .double("label_rules.callout_preferred_max_length_px"),
                calloutHardMaxLengthPx = labels.required("callout_hard_max_length_px", "label_rules")
                    .double("label_rules.callout_hard_max_length_px"),
                placementOrder = order,
                perimeterBorderLabelsExteriorRequired = labels.required("perimeter_border_labels_exterior_required", "label_rules")
                    .bool("label_rules.perimeter_border_labels_exterior_required"),
                streetLabelAnyObjectOverlapAllowed = labels.required("street_label_any_object_overlap_allowed", "label_rules")
                    .bool("label_rules.street_label_any_object_overlap_allowed"),
                mixedStatusColorOverlapAllowed = labels.required("mixed_status_color_overlap_allowed", "label_rules")
                    .bool("label_rules.mixed_status_color_overlap_allowed")
            )
        )
    }

    private fun numberPair(map: Map<String, JsonValue>, name: String, context: String): Pair<Double, Double> {
        val values = map.required(name, context).arr("$context.$name")
        require(values.size == 2) { "$context.$name must contain exactly two numbers" }
        return values[0].double("$context.$name[0]") to values[1].double("$context.$name[1]")
    }
}
