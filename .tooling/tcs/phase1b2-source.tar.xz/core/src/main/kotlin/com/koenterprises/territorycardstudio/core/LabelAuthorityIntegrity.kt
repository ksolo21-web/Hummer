package com.koenterprises.territorycardstudio.core

object LabelAuthorityIntegrity {
    val requiredSha256: Map<String, String> = linkedMapOf(
        "Territory-Critic-Visual-Hard-Override-2026-09-21.md" to "0e26a779ae27fb7e4bcb4f6353f84f7a1bf3d1297fbc77ad922fc46cc0ba4b2d",
        "Territory-Label-Completeness-Preflight-Contract.md" to "72146df5a5c7921111f156d32aeb227d9570f286f9725edcf0c4499ef8373eaa",
        "Territory-Label-Uniformity-and-Road-Line-Quality-Override-2026-09-18.md" to "b485f1be9828e1a4a33fcbb47c64befc6098b46529c08a0390d7b19f32a6bb80",
        "Territory-PDF-Label-Metric-Contract.md" to "621b430f87268abe6ebf57387c59993428e2dc9962b77fb4503c2600222ca252",
        "Territory-Segment-Role-Whole-Label-Contract.md" to "ef99639bc11dc6d00c98d7d0062ad61d266399862c242d7dc88b722b827341ca"
    )
}
