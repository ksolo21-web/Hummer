package com.koenterprises.territorycardstudio.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private val SHA256_HEX = Regex("^[0-9a-f]{64}$")

enum class LabelPlacementMode(val styleToken: String) {
    DIRECT_ROAD_FOLLOWING("direct_road_following"),
    CURVED_ROAD_FOLLOWING("curved_road_following"),
    SAME_ROAD_RELOCATION("same_road_relocation"),
    NEARBY_ATTACHED_ARROW_CALLOUT("nearby_attached_arrow_callout"),
    DEDICATED_DETAIL("dedicated_detail");

    companion object {
        fun fromStyleToken(value: String): LabelPlacementMode =
            entries.firstOrNull { it.styleToken == value }
                ?: error("Unsupported label placement mode '$value'")
    }
}

enum class LabelObstacleKind {
    STREET_LABEL,
    ROAD,
    JUNCTION,
    BUILDING,
    SITE_LABEL,
    LEADER,
    ANNOTATION,
    ICON,
    COMPASS,
    BORDER,
    DETAIL,
    OTHER
}

enum class LabelSide {
    POSITIVE_NORMAL,
    NEGATIVE_NORMAL;

    val normalSign: Int get() = if (this == POSITIVE_NORMAL) 1 else -1

    companion object {
        fun fromNormalSign(sign: Int): LabelSide = when (sign) {
            1 -> POSITIVE_NORMAL
            -1 -> NEGATIVE_NORMAL
            else -> error("Label side normal sign must be +1 or -1")
        }
    }
}

enum class TextMetricsProvenance {
    ACTUAL_PDF_FONT_WIDTHS,
    VERIFIED_SHAPING_ENGINE
}

data class AxisAlignedRect(
    val left: Double,
    val top: Double,
    val right: Double,
    val bottom: Double
) {
    init {
        require(left <= right) { "Invalid rectangle horizontal bounds" }
        require(top <= bottom) { "Invalid rectangle vertical bounds" }
    }

    val width: Double get() = right - left
    val height: Double get() = bottom - top
    val center: Point2D get() = Point2D((left + right) / 2.0, (top + bottom) / 2.0)

    fun contains(other: AxisAlignedRect, epsilon: Double = 1e-9): Boolean =
        other.left >= left - epsilon && other.right <= right + epsilon &&
            other.top >= top - epsilon && other.bottom <= bottom + epsilon

    fun overlaps(other: AxisAlignedRect, epsilon: Double = 1e-9): Boolean =
        left < other.right - epsilon && right > other.left + epsilon &&
            top < other.bottom - epsilon && bottom > other.top + epsilon

    fun touchesOrOverlaps(other: AxisAlignedRect, epsilon: Double = 1e-9): Boolean =
        left <= other.right + epsilon && right >= other.left - epsilon &&
            top <= other.bottom + epsilon && bottom >= other.top - epsilon

    fun edgeClearanceWithin(container: AxisAlignedRect): Double =
        min(min(left - container.left, container.right - right), min(top - container.top, container.bottom - bottom))

    fun gapTo(other: AxisAlignedRect): Double {
        if (touchesOrOverlaps(other)) return 0.0
        val dx = max(max(other.left - right, left - other.right), 0.0)
        val dy = max(max(other.top - bottom, top - other.bottom), 0.0)
        return hypot(dx, dy)
    }
}

data class LabelObstacle(
    val id: String,
    val kind: LabelObstacleKind,
    val bounds: AxisAlignedRect,
    val roadStatus: String? = null
)

data class StreetLabelTextMetrics(
    val width: Double,
    val height: Double,
    val fontSizePt: Double,
    val fontFamily: String,
    val provenance: TextMetricsProvenance,
    val isBold: Boolean = false
) {
    init {
        require(width > 0.0 && height > 0.0) { "Text metrics must be positive" }
        require(fontSizePt > 0.0) { "Font size must be positive" }
    }
}

data class LabelNavigationLock(
    val labelId: String,
    val streetName: String,
    val navigationRole: String,
    val segmentId: String,
    val sourceEvidence: String,
    val sourceSha256: String,
    val territoryFacingSide: String? = null,
    val exteriorSide: String? = null
) {
    init {
        require(labelId.isNotBlank()) { "Navigation lock labelId is blank" }
        require(streetName.isNotBlank()) { "Navigation lock streetName is blank" }
        require(navigationRole.isNotBlank()) { "Navigation lock navigationRole is blank" }
        require(segmentId.isNotBlank()) { "Navigation lock segmentId is blank" }
        require(sourceEvidence.isNotBlank()) { "Navigation lock source evidence is blank" }
        require(SHA256_HEX.matches(sourceSha256)) { "Navigation lock sourceSha256 must be lowercase SHA-256 hex" }
    }
}

data class LabelLayoutScale(val pixelsPerGeometryUnit: Double) {
    init {
        require(pixelsPerGeometryUnit > 0.0) { "pixelsPerGeometryUnit must be positive" }
    }

    fun geometryUnits(px: Double): Double = px / pixelsPerGeometryUnit
    fun pixels(units: Double): Double = units * pixelsPerGeometryUnit
}

data class StreetLabelRequest(
    val labelId: String,
    val road: RoadGeometry,
    val navigationLock: LabelNavigationLock,
    val textMetrics: StreetLabelTextMetrics,
    val cardStreetFontSizePt: Double,
    val mapBounds: AxisAlignedRect,
    val scale: LabelLayoutScale,
    val obstacles: List<LabelObstacle> = emptyList(),
    /** +1 or -1 selects the exterior local normal for perimeter roads. Required when policy demands exterior labels. */
    val perimeterExteriorNormalSign: Int? = null,
    /** Explicit user approval is required before one label may deviate from the card-wide street-label point size. */
    val userApprovedIndividualSizeException: Boolean = false
) {
    init {
        require(labelId.isNotBlank()) { "labelId is blank" }
        require(cardStreetFontSizePt > 0.0) { "cardStreetFontSizePt must be positive" }
    }
}

data class ArrowCalloutGeometry(
    val roadAnchor: Point2D,
    val tailStart: Point2D,
    val labelAttach: Point2D,
    val length: Double,
    val tailGapGeometryUnits: Double
)

data class SideCandidateEvidence(
    val side: LabelSide,
    val policyAllowed: Boolean,
    val candidateTested: Boolean,
    val mapBoundsClear: Boolean,
    val roadTouchCount: Int,
    val roadOverlapCount: Int,
    val labelContactOrOverlapCount: Int,
    val anyObjectContactCount: Int,
    val anyObjectOverlapCount: Int,
    val junctionClutter: Boolean,
    val endClearancePx: Double,
    val clearanceScorePx: Double,
    val fitClean: Boolean,
    val failureReason: String?
)

data class SideSelectionEvidence(
    val sideOptionsReviewed: Set<LabelSide>,
    val preferredSide: LabelSide,
    val usedSide: LabelSide,
    val preferredSideClear: Boolean,
    val preferredSideReason: String,
    val oppositeSideExceptionReason: String?,
    val calloutJustified: Boolean,
    val preferredSideCandidateTested: Boolean,
    val preferredSideCandidateRoadTouchCount: Int,
    val preferredSideCandidateRoadOverlapCount: Int,
    val preferredSideCandidateLabelOverlapCount: Int,
    val preferredSideCandidateJunctionClutter: Boolean,
    val preferredSideCandidateFitClean: Boolean,
    val candidates: List<SideCandidateEvidence>
)

data class CalloutJustificationEvidence(
    val directCandidateTested: Boolean,
    val directCandidateSide: LabelSide,
    val directCandidateStandardGapPassed: Boolean,
    val directCandidateRoadTouchCount: Int,
    val directCandidateRoadOverlapCount: Int,
    val directCandidateLabelOverlapCount: Int,
    val directCandidateJunctionClutter: Boolean,
    val directCandidateEndClearanceMinPx: Double,
    val directCandidateFitClean: Boolean,
    val directCandidateFailureReason: String,
    val sameRoadCandidateCountTested: Int,
    val calloutJustified: Boolean
)

data class LabelPlacement(
    val mode: LabelPlacementMode,
    val center: Point2D,
    val angleDeg: Double,
    val bounds: AxisAlignedRect,
    val roadGapGeometryUnits: Double,
    val sourceSegmentIndex: Int?,
    val navigationLock: LabelNavigationLock,
    val sideEvidence: SideSelectionEvidence? = null,
    val calloutEvidence: CalloutJustificationEvidence? = null,
    val callout: ArrowCalloutGeometry? = null,
    val requiresReview: Boolean = false,
    val reviewNote: String? = null
)

enum class LabelReviewReason {
    EMPTY_ROAD_NAME,
    INSUFFICIENT_ROAD_GEOMETRY,
    NAVIGATION_LOCK_VIOLATION,
    FONT_CONTRACT_VIOLATION,
    CARD_FONT_UNIFORMITY_VIOLATION,
    PERIMETER_EXTERIOR_DIRECTION_REQUIRED,
    CURVED_ROAD_RENDERER_REQUIRED,
    NO_COLLISION_FREE_PLACEMENT,
    CALLOUT_EXCEEDS_HARD_MAX,
    DEDICATED_DETAIL_REQUIRED
}

data class LabelPlacementAttempt(
    val mode: LabelPlacementMode,
    val accepted: Boolean,
    val note: String
)

sealed class LabelPlacementDecision {
    data class Placed(
        val placement: LabelPlacement,
        val attempts: List<LabelPlacementAttempt>
    ) : LabelPlacementDecision()

    data class ReviewRequired(
        val reason: LabelReviewReason,
        val recommendedMode: LabelPlacementMode,
        val attempts: List<LabelPlacementAttempt>
    ) : LabelPlacementDecision()
}

/**
 * Platform-independent street-label placement gate.
 *
 * Android/PDF renderers must supply metrics from the exact PDF font widths or a verified shaping engine using
 * the locked DejaVu Sans face. The engine owns deterministic placement order, target-lock binding, both-side
 * testing, collision/contact rejection, callout justification and fail-closed review routing. Curved glyph-path
 * generation and exact saved-PDF ink measurements remain renderer/reviewer responsibilities.
 */
class RoadLabelPlacementEngine(private val style: LabelStyleContract) {
    fun place(request: StreetLabelRequest): LabelPlacementDecision {
        val attempts = mutableListOf<LabelPlacementAttempt>()
        val road = request.road
        if (road.name.isBlank()) {
            return LabelPlacementDecision.ReviewRequired(
                LabelReviewReason.EMPTY_ROAD_NAME,
                LabelPlacementMode.DEDICATED_DETAIL,
                listOf(LabelPlacementAttempt(LabelPlacementMode.DIRECT_ROAD_FOLLOWING, false, "road name is blank"))
            )
        }
        if (road.points.size < 2 || polylineLength(road.points) <= 0.0) {
            return LabelPlacementDecision.ReviewRequired(
                LabelReviewReason.INSUFFICIENT_ROAD_GEOMETRY,
                LabelPlacementMode.DEDICATED_DETAIL,
                listOf(LabelPlacementAttempt(LabelPlacementMode.DIRECT_ROAD_FOLLOWING, false, "road has insufficient geometry"))
            )
        }
        val lockViolation = navigationLockViolation(request)
        if (lockViolation != null) {
            return LabelPlacementDecision.ReviewRequired(
                LabelReviewReason.NAVIGATION_LOCK_VIOLATION,
                LabelPlacementMode.DEDICATED_DETAIL,
                listOf(LabelPlacementAttempt(LabelPlacementMode.DIRECT_ROAD_FOLLOWING, false, lockViolation))
            )
        }
        val fontViolation = fontViolation(request.textMetrics)
        if (fontViolation != null) {
            return LabelPlacementDecision.ReviewRequired(
                LabelReviewReason.FONT_CONTRACT_VIOLATION,
                LabelPlacementMode.DEDICATED_DETAIL,
                listOf(LabelPlacementAttempt(LabelPlacementMode.DIRECT_ROAD_FOLLOWING, false, fontViolation))
            )
        }
        if (abs(request.textMetrics.fontSizePt - request.cardStreetFontSizePt) > 1e-9 &&
            !request.userApprovedIndividualSizeException
        ) {
            return LabelPlacementDecision.ReviewRequired(
                LabelReviewReason.CARD_FONT_UNIFORMITY_VIOLATION,
                LabelPlacementMode.DEDICATED_DETAIL,
                listOf(
                    LabelPlacementAttempt(
                        LabelPlacementMode.DIRECT_ROAD_FOLLOWING,
                        false,
                        "label size ${request.textMetrics.fontSizePt} pt differs from card-wide ${request.cardStreetFontSizePt} pt without explicit user approval"
                    )
                )
            )
        }
        if (road.role == "perimeter" && style.placement.perimeterBorderLabelsExteriorRequired) {
            if (request.perimeterExteriorNormalSign !in setOf(-1, 1)) {
                return LabelPlacementDecision.ReviewRequired(
                    LabelReviewReason.PERIMETER_EXTERIOR_DIRECTION_REQUIRED,
                    LabelPlacementMode.DIRECT_ROAD_FOLLOWING,
                    listOf(LabelPlacementAttempt(LabelPlacementMode.DIRECT_ROAD_FOLLOWING, false, "perimeter exterior normal is unresolved"))
                )
            }
        }

        val segments = road.points.zipWithNext().mapIndexedNotNull { index, (a, b) ->
            val length = distance(a, b)
            if (length <= 1e-9) null else SegmentCandidate(index, a, b, length)
        }
        if (segments.isEmpty()) {
            return LabelPlacementDecision.ReviewRequired(
                LabelReviewReason.INSUFFICIENT_ROAD_GEOMETRY,
                LabelPlacementMode.DEDICATED_DETAIL,
                listOf(LabelPlacementAttempt(LabelPlacementMode.DIRECT_ROAD_FOLLOWING, false, "road has only zero-length segments"))
            )
        }

        val midpointSegment = segmentContainingPathMidpoint(segments)
        val direct = tryStraightSegment(request, midpointSegment, LabelPlacementMode.DIRECT_ROAD_FOLLOWING)
        attempts += direct.attempt
        direct.placement?.let { return LabelPlacementDecision.Placed(it, attempts) }

        if (isMeaningfullyCurved(segments) && canFitAlongPolyline(request)) {
            val curved = tryCurvedPolyline(request, midpointSegment)
            attempts += curved.attempt
            curved.placement?.let { return LabelPlacementDecision.Placed(it, attempts) }
        }
        attempts += LabelPlacementAttempt(
            LabelPlacementMode.CURVED_ROAD_FOLLOWING,
            false,
            if (isMeaningfullyCurved(segments)) "curved road path cannot hold the complete normal-size label with positive end clearance" else "road does not require curved-path text"
        )

        val relocationCandidates = segments
            .filter { it.index != midpointSegment.index }
            .sortedWith(compareByDescending<SegmentCandidate> { it.length }.thenBy { it.index })
        var relocationTests = 0
        for (segment in relocationCandidates) {
            val relocated = tryStraightSegment(request, segment, LabelPlacementMode.SAME_ROAD_RELOCATION)
            relocationTests += 1
            attempts += relocated.attempt
            relocated.placement?.let { return LabelPlacementDecision.Placed(it, attempts) }
        }
        if (relocationCandidates.isEmpty()) {
            attempts += LabelPlacementAttempt(LabelPlacementMode.SAME_ROAD_RELOCATION, false, "no alternate road segment exists")
        }

        val callout = tryCallout(request, direct, relocationTests)
        attempts += callout.attempt
        callout.placement?.let { return LabelPlacementDecision.Placed(it, attempts) }

        attempts += LabelPlacementAttempt(LabelPlacementMode.DEDICATED_DETAIL, false, "no safe automatic street-label placement remains")
        return LabelPlacementDecision.ReviewRequired(
            if (callout.exceededHardMax) LabelReviewReason.CALLOUT_EXCEEDS_HARD_MAX else LabelReviewReason.DEDICATED_DETAIL_REQUIRED,
            LabelPlacementMode.DEDICATED_DETAIL,
            attempts
        )
    }

    private fun navigationLockViolation(request: StreetLabelRequest): String? {
        val lock = request.navigationLock
        if (lock.labelId != request.labelId) return "navigation lock labelId does not match request labelId"
        if (lock.streetName != request.road.name) return "navigation lock street name does not match road name"
        if (lock.segmentId != request.road.segmentId) return "navigation lock segmentId does not match exact road segment"
        if (request.road.role == "perimeter") {
            if (lock.territoryFacingSide.isNullOrBlank() || lock.exteriorSide.isNullOrBlank()) {
                return "perimeter target lock must record territory-facing and exterior sides"
            }
            if (lock.territoryFacingSide == lock.exteriorSide) {
                return "perimeter target lock territory-facing side and exterior side cannot match"
            }
        }
        return null
    }

    private fun fontViolation(metrics: StreetLabelTextMetrics): String? {
        if (metrics.fontFamily != style.streetFont.family) {
            return "font family ${metrics.fontFamily} does not match locked ${style.streetFont.family}"
        }
        if (style.streetFont.regularOnly && metrics.isBold) return "street text cannot be bold"
        if (metrics.fontSizePt + 1e-9 < style.streetFont.minimumSizePt) {
            return "street font ${metrics.fontSizePt} pt is below ${style.streetFont.minimumSizePt} pt"
        }
        return null
    }

    private fun tryStraightSegment(
        request: StreetLabelRequest,
        segment: SegmentCandidate,
        mode: LabelPlacementMode
    ): StraightAttempt {
        val p = style.placement
        val dx = segment.b.x - segment.a.x
        val dy = segment.b.y - segment.a.y
        val inv = 1.0 / segment.length
        val nx = -dy * inv
        val ny = dx * inv
        val mid = Point2D((segment.a.x + segment.b.x) / 2.0, (segment.a.y + segment.b.y) / 2.0)
        val gap = request.scale.geometryUnits(p.assignedRoadGapTargetPx)
        val normalOffset = (request.road.widthPt / 2.0) + gap + (request.textMetrics.height / 2.0)
        val angle = uprightAngleDegrees(atan2(dy, dx) * 180.0 / PI)
        val endClearanceUnits = (segment.length - request.textMetrics.width) / 2.0
        val endClearancePx = request.scale.pixels(endClearanceUnits)
        val allowedSigns = when {
            request.road.role == "perimeter" && p.perimeterBorderLabelsExteriorRequired ->
                setOf(requireNotNull(request.perimeterExteriorNormalSign))
            else -> setOf(1, -1)
        }

        val candidates = listOf(1, -1).map { sign ->
            buildSideCandidate(
                request = request,
                sign = sign,
                policyAllowed = sign in allowedSigns,
                center = Point2D(mid.x + nx * normalOffset * sign, mid.y + ny * normalOffset * sign),
                angle = angle,
                endClearancePx = endClearancePx
            )
        }
        val preferred = choosePreferredSide(request, segment, candidates)
        val opposite = candidates.first { it.side != preferred.side }
        val used = when {
            preferred.fitClean -> preferred
            opposite.fitClean -> opposite
            else -> null
        }
        val evidence = sideSelectionEvidence(preferred, used ?: preferred, candidates)

        if (used == null) {
            return StraightAttempt(
                placement = null,
                attempt = LabelPlacementAttempt(
                    mode,
                    false,
                    "segment ${segment.index}: " + candidates.joinToString("; ") { candidateSummary(it) }
                ),
                sideEvidence = evidence
            )
        }

        val center = sideCandidateCenter(request, segment, used.side.normalSign)
        val bounds = rotatedBounds(center, request.textMetrics.width, request.textMetrics.height, angle)
        return StraightAttempt(
            placement = LabelPlacement(
                mode = mode,
                center = center,
                angleDeg = angle,
                bounds = bounds,
                roadGapGeometryUnits = gap,
                sourceSegmentIndex = segment.index,
                navigationLock = request.navigationLock,
                sideEvidence = evidence
            ),
            attempt = LabelPlacementAttempt(
                mode,
                true,
                "segment ${segment.index} placed at locked ${p.assignedRoadGapTargetPx}px target gap; preferred=${preferred.side}; used=${used.side}; endClearance=${fmt(endClearancePx)}px"
            ),
            sideEvidence = evidence
        )
    }

    private fun buildSideCandidate(
        request: StreetLabelRequest,
        sign: Int,
        policyAllowed: Boolean,
        center: Point2D,
        angle: Double,
        endClearancePx: Double
    ): SideCandidateEvidence {
        val side = LabelSide.fromNormalSign(sign)
        val bounds = rotatedBounds(center, request.textMetrics.width, request.textMetrics.height, angle)
        val mapClearance = bounds.edgeClearanceWithin(request.mapBounds)
        val mapBoundsClear = request.mapBounds.contains(bounds) && mapClearance > 1e-9
        val contacts = request.obstacles.filter { bounds.touchesOrOverlaps(it.bounds) && !bounds.overlaps(it.bounds) }
        val overlaps = request.obstacles.filter { bounds.overlaps(it.bounds) }
        val roadTouch = contacts.count { it.kind == LabelObstacleKind.ROAD }
        val roadOverlap = overlaps.count { it.kind == LabelObstacleKind.ROAD }
        val labelContactOrOverlap = (contacts + overlaps).count { it.kind == LabelObstacleKind.STREET_LABEL }
        val junctionClutter = (contacts + overlaps).any { it.kind == LabelObstacleKind.JUNCTION }
        val allContact = contacts.size
        val allOverlap = overlaps.size
        val positiveEndClearance = endClearancePx > 0.0
        val fit = policyAllowed && mapBoundsClear && positiveEndClearance && allContact == 0 && allOverlap == 0 && !junctionClutter
        val obstacleClearance = request.obstacles.minOfOrNull { bounds.gapTo(it.bounds) } ?: Double.POSITIVE_INFINITY
        val clearanceUnits = min(mapClearance.coerceAtLeast(0.0), obstacleClearance)
        val clearancePx = if (clearanceUnits.isFinite()) request.scale.pixels(clearanceUnits) else request.scale.pixels(mapClearance.coerceAtLeast(0.0))
        val failures = buildList {
            if (!policyAllowed) add("policy-prohibited side")
            if (!mapBoundsClear) add("clips/touches map bounds")
            if (!positiveEndClearance) add("label overhangs road-run endpoints")
            if (roadTouch > 0) add("road contact=$roadTouch")
            if (roadOverlap > 0) add("road overlap=$roadOverlap")
            if (labelContactOrOverlap > 0) add("label contact/overlap=$labelContactOrOverlap")
            if (junctionClutter) add("junction clutter")
            val otherContact = allContact - roadTouch - contacts.count { it.kind == LabelObstacleKind.STREET_LABEL }
            val otherOverlap = allOverlap - roadOverlap - overlaps.count { it.kind == LabelObstacleKind.STREET_LABEL }
            if (otherContact > 0) add("other object contact=$otherContact")
            if (otherOverlap > 0) add("other object overlap=$otherOverlap")
        }
        return SideCandidateEvidence(
            side = side,
            policyAllowed = policyAllowed,
            candidateTested = true,
            mapBoundsClear = mapBoundsClear,
            roadTouchCount = roadTouch,
            roadOverlapCount = roadOverlap,
            labelContactOrOverlapCount = labelContactOrOverlap,
            anyObjectContactCount = allContact,
            anyObjectOverlapCount = allOverlap,
            junctionClutter = junctionClutter,
            endClearancePx = endClearancePx,
            clearanceScorePx = clearancePx,
            fitClean = fit,
            failureReason = failures.takeIf { it.isNotEmpty() }?.joinToString(", ")
        )
    }

    private fun choosePreferredSide(
        request: StreetLabelRequest,
        segment: SegmentCandidate,
        candidates: List<SideCandidateEvidence>
    ): SideCandidateEvidence {
        if (request.road.role == "perimeter" && style.placement.perimeterBorderLabelsExteriorRequired) {
            return candidates.first { it.side.normalSign == request.perimeterExteriorNormalSign }
        }
        val clean = candidates.filter { it.fitClean }
        if (clean.size == 1) return clean.single()
        if (clean.size == 2) {
            val a = clean[0]
            val b = clean[1]
            if (abs(a.clearanceScorePx - b.clearanceScorePx) > 2.0) {
                return if (a.clearanceScorePx > b.clearanceScorePx) a else b
            }
        }
        val centers = candidates.associateWith { sideCandidateCenter(request, segment, it.side.normalSign) }
        val dx = abs(segment.b.x - segment.a.x)
        val dy = abs(segment.b.y - segment.a.y)
        return if (dx >= dy) {
            candidates.minBy { centers.getValue(it).y }
        } else {
            candidates.maxBy { centers.getValue(it).x }
        }
    }

    private fun sideSelectionEvidence(
        preferred: SideCandidateEvidence,
        used: SideCandidateEvidence,
        candidates: List<SideCandidateEvidence>
    ): SideSelectionEvidence {
        val reason = when {
            preferred.side == used.side && preferred.fitClean &&
                candidates.count { it.fitClean } == 1 -> "only clean policy-allowed side"
            preferred.side == used.side && candidates.count { it.fitClean } == 2 ->
                if (abs(candidates[0].clearanceScorePx - candidates[1].clearanceScorePx) > 2.0) "cleaner usable whitespace" else "orientation tie-breaker"
            else -> "preferred side was not clean; opposite clean side used"
        }
        val exception = if (used.side != preferred.side) preferred.failureReason ?: "preferred side failed exact candidate fit" else null
        return SideSelectionEvidence(
            sideOptionsReviewed = setOf(LabelSide.POSITIVE_NORMAL, LabelSide.NEGATIVE_NORMAL),
            preferredSide = preferred.side,
            usedSide = used.side,
            preferredSideClear = preferred.fitClean,
            preferredSideReason = reason,
            oppositeSideExceptionReason = exception,
            calloutJustified = false,
            preferredSideCandidateTested = preferred.candidateTested,
            preferredSideCandidateRoadTouchCount = preferred.roadTouchCount,
            preferredSideCandidateRoadOverlapCount = preferred.roadOverlapCount,
            preferredSideCandidateLabelOverlapCount = preferred.labelContactOrOverlapCount,
            preferredSideCandidateJunctionClutter = preferred.junctionClutter,
            preferredSideCandidateFitClean = preferred.fitClean,
            candidates = candidates
        )
    }

    private fun sideCandidateCenter(request: StreetLabelRequest, segment: SegmentCandidate, sign: Int): Point2D {
        val dx = segment.b.x - segment.a.x
        val dy = segment.b.y - segment.a.y
        val inv = 1.0 / segment.length
        val nx = -dy * inv
        val ny = dx * inv
        val mid = Point2D((segment.a.x + segment.b.x) / 2.0, (segment.a.y + segment.b.y) / 2.0)
        val gap = request.scale.geometryUnits(style.placement.assignedRoadGapTargetPx)
        val normalOffset = (request.road.widthPt / 2.0) + gap + (request.textMetrics.height / 2.0)
        return Point2D(mid.x + nx * normalOffset * sign, mid.y + ny * normalOffset * sign)
    }

    private fun candidateSummary(candidate: SideCandidateEvidence): String =
        "${candidate.side}=${candidate.failureReason ?: "clean"}"

    private fun tryCurvedPolyline(
        request: StreetLabelRequest,
        midpointSegment: SegmentCandidate
    ): StraightAttempt {
        val totalLength = polylineLength(request.road.points)
        val endClearancePx = request.scale.pixels((totalLength - request.textMetrics.width) / 2.0)
        val dx = midpointSegment.b.x - midpointSegment.a.x
        val dy = midpointSegment.b.y - midpointSegment.a.y
        val inv = 1.0 / midpointSegment.length
        val nx = -dy * inv
        val ny = dx * inv
        val pathMid = pointAtPathFraction(request.road.points, 0.5)
        val gap = request.scale.geometryUnits(style.placement.assignedRoadGapTargetPx)
        val normalOffset = (request.road.widthPt / 2.0) + gap + (request.textMetrics.height / 2.0)
        val angle = uprightAngleDegrees(atan2(dy, dx) * 180.0 / PI)
        val allowedSigns = when {
            request.road.role == "perimeter" && style.placement.perimeterBorderLabelsExteriorRequired ->
                setOf(requireNotNull(request.perimeterExteriorNormalSign))
            else -> setOf(1, -1)
        }
        val candidates = listOf(1, -1).map { sign ->
            buildSideCandidate(
                request = request,
                sign = sign,
                policyAllowed = sign in allowedSigns,
                center = Point2D(pathMid.x + nx * normalOffset * sign, pathMid.y + ny * normalOffset * sign),
                angle = angle,
                endClearancePx = endClearancePx
            )
        }
        val preferred = choosePreferredSide(request, midpointSegment, candidates)
        val opposite = candidates.first { it.side != preferred.side }
        val used = when { preferred.fitClean -> preferred; opposite.fitClean -> opposite; else -> null }
        val evidence = sideSelectionEvidence(preferred, used ?: preferred, candidates)
        if (used == null) {
            return StraightAttempt(
                null,
                LabelPlacementAttempt(LabelPlacementMode.CURVED_ROAD_FOLLOWING, false, candidates.joinToString("; ") { candidateSummary(it) }),
                evidence
            )
        }
        val center = Point2D(pathMid.x + nx * normalOffset * used.side.normalSign, pathMid.y + ny * normalOffset * used.side.normalSign)
        val bounds = rotatedBounds(center, request.textMetrics.width, request.textMetrics.height, angle)
        return StraightAttempt(
            LabelPlacement(
                mode = LabelPlacementMode.CURVED_ROAD_FOLLOWING,
                center = center,
                angleDeg = angle,
                bounds = bounds,
                roadGapGeometryUnits = gap,
                sourceSegmentIndex = midpointSegment.index,
                navigationLock = request.navigationLock,
                sideEvidence = evidence
            ),
            LabelPlacementAttempt(
                LabelPlacementMode.CURVED_ROAD_FOLLOWING,
                true,
                "complete normal-size label fits verified curved path at locked ${style.placement.assignedRoadGapTargetPx}px target gap"
            ),
            evidence
        )
    }

    private fun canFitAlongPolyline(request: StreetLabelRequest): Boolean =
        polylineLength(request.road.points) - request.textMetrics.width > 1e-9

    private fun tryCallout(
        request: StreetLabelRequest,
        direct: StraightAttempt,
        sameRoadCandidateCountTested: Int
    ): CalloutAttempt {
        val p = style.placement
        val directPreferred = direct.sideEvidence.candidates.first { it.side == direct.sideEvidence.preferredSide }
        check(!directPreferred.fitClean) { "Callout is prohibited when preferred direct candidate is clean" }
        val calloutEvidence = CalloutJustificationEvidence(
            directCandidateTested = directPreferred.candidateTested,
            directCandidateSide = directPreferred.side,
            directCandidateStandardGapPassed = true,
            directCandidateRoadTouchCount = directPreferred.roadTouchCount,
            directCandidateRoadOverlapCount = directPreferred.roadOverlapCount,
            directCandidateLabelOverlapCount = directPreferred.labelContactOrOverlapCount,
            directCandidateJunctionClutter = directPreferred.junctionClutter,
            directCandidateEndClearanceMinPx = directPreferred.endClearancePx,
            directCandidateFitClean = directPreferred.fitClean,
            directCandidateFailureReason = requireNotNull(directPreferred.failureReason),
            sameRoadCandidateCountTested = sameRoadCandidateCountTested,
            calloutJustified = true
        )
        val anchor = pointAtPathFraction(request.road.points, 0.5)
        val tailGap = request.scale.geometryUnits((p.calloutTailGapMinPx + p.calloutTailGapMaxPx) / 2.0)
        val preferred = request.scale.geometryUnits(p.calloutPreferredMaxLengthPx)
        val hard = request.scale.geometryUnits(p.calloutHardMaxLengthPx)
        val minCenterDistance = max(request.textMetrics.width, request.textMetrics.height) / 2.0 + request.scale.geometryUnits(8.0)
        val distances = linkedSetOf(
            minCenterDistance,
            minCenterDistance + preferred * 0.35,
            minCenterDistance + preferred * 0.70,
            minCenterDistance + preferred,
            minCenterDistance + hard
        ).filter { it > 0.0 }
        val directions = listOf(0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0)
        var sawHardExcess = false
        for (distance in distances) {
            for (degrees in directions) {
                val radians = degrees * PI / 180.0
                val ux = cos(radians)
                val uy = sin(radians)
                val center = Point2D(anchor.x + ux * distance, anchor.y + uy * distance)
                val bounds = AxisAlignedRect(
                    center.x - request.textMetrics.width / 2.0,
                    center.y - request.textMetrics.height / 2.0,
                    center.x + request.textMetrics.width / 2.0,
                    center.y + request.textMetrics.height / 2.0
                )
                if (!request.mapBounds.contains(bounds) || bounds.edgeClearanceWithin(request.mapBounds) <= 1e-9) continue
                if (roadIntersectsBounds(request.road, bounds)) continue
                if (firstCollision(bounds, request.obstacles) != null) continue
                val labelAttach = rectangleBoundaryToward(bounds, anchor)
                val rawLength = distance(anchor, labelAttach)
                val lineLength = max(0.0, rawLength - tailGap)
                if (lineLength > hard + 1e-9) {
                    sawHardExcess = true
                    continue
                }
                val tailStart = moveToward(labelAttach, anchor, tailGap)
                if (request.obstacles.any { segmentIntersectsRect(tailStart, anchor, it.bounds) }) continue
                val review = lineLength > preferred + 1e-9
                return CalloutAttempt(
                    placement = LabelPlacement(
                        mode = LabelPlacementMode.NEARBY_ATTACHED_ARROW_CALLOUT,
                        center = center,
                        angleDeg = 0.0,
                        bounds = bounds,
                        roadGapGeometryUnits = 0.0,
                        sourceSegmentIndex = segmentContainingPathMidpoint(
                            request.road.points.zipWithNext().mapIndexedNotNull { index, (a, b) ->
                                val len = distance(a, b); if (len <= 1e-9) null else SegmentCandidate(index, a, b, len)
                            }
                        ).index,
                        navigationLock = request.navigationLock,
                        calloutEvidence = calloutEvidence,
                        callout = ArrowCalloutGeometry(anchor, tailStart, labelAttach, lineLength, tailGap),
                        requiresReview = review,
                        reviewNote = if (review) "callout is within hard maximum but exceeds preferred maximum" else null
                    ),
                    attempt = LabelPlacementAttempt(
                        LabelPlacementMode.NEARBY_ATTACHED_ARROW_CALLOUT,
                        true,
                        if (review) "collision-free attached callout within hard maximum; review required" else "nearest collision-free attached callout within preferred maximum"
                    ),
                    exceededHardMax = false
                )
            }
        }
        return CalloutAttempt(
            null,
            LabelPlacementAttempt(
                LabelPlacementMode.NEARBY_ATTACHED_ARROW_CALLOUT,
                false,
                if (sawHardExcess) "available callouts exceed the locked hard maximum" else "no collision-free attached callout fits within map bounds"
            ),
            sawHardExcess
        )
    }

    private fun roadIntersectsBounds(road: RoadGeometry, bounds: AxisAlignedRect): Boolean {
        val half = road.widthPt / 2.0
        val expanded = AxisAlignedRect(bounds.left - half, bounds.top - half, bounds.right + half, bounds.bottom + half)
        return road.points.zipWithNext().any { (a, b) -> segmentIntersectsRect(a, b, expanded) }
    }

    private fun firstCollision(bounds: AxisAlignedRect, obstacles: List<LabelObstacle>): LabelObstacle? =
        obstacles.firstOrNull { bounds.touchesOrOverlaps(it.bounds) }

    private fun isMeaningfullyCurved(segments: List<SegmentCandidate>): Boolean {
        if (segments.size < 2) return false
        val nonZeroAngles = segments.map { atan2(it.b.y - it.a.y, it.b.x - it.a.x) }
        for (i in 0 until nonZeroAngles.lastIndex) {
            var delta = abs(nonZeroAngles[i + 1] - nonZeroAngles[i])
            while (delta > PI) delta = abs(delta - 2.0 * PI)
            if (delta > 1e-3) return true
        }
        return false
    }

    private fun segmentContainingPathMidpoint(segments: List<SegmentCandidate>): SegmentCandidate {
        val total = segments.sumOf { it.length }
        val target = total / 2.0
        var traversed = 0.0
        for (segment in segments) {
            if (traversed + segment.length + 1e-9 >= target) return segment
            traversed += segment.length
        }
        return segments.last()
    }

    private fun rotatedBounds(center: Point2D, width: Double, height: Double, angleDeg: Double): AxisAlignedRect {
        val radians = angleDeg * PI / 180.0
        val c = abs(cos(radians))
        val s = abs(sin(radians))
        val aabbWidth = width * c + height * s
        val aabbHeight = width * s + height * c
        return AxisAlignedRect(
            center.x - aabbWidth / 2.0,
            center.y - aabbHeight / 2.0,
            center.x + aabbWidth / 2.0,
            center.y + aabbHeight / 2.0
        )
    }

    private fun uprightAngleDegrees(raw: Double): Double {
        var angle = raw
        while (angle > 180.0) angle -= 360.0
        while (angle <= -180.0) angle += 360.0
        if (angle > 90.0) angle -= 180.0
        if (angle < -90.0) angle += 180.0
        return angle
    }

    private fun rectangleBoundaryToward(rect: AxisAlignedRect, target: Point2D): Point2D {
        val center = rect.center
        val dx = target.x - center.x
        val dy = target.y - center.y
        if (abs(dx) < 1e-12 && abs(dy) < 1e-12) return center
        val tx = if (abs(dx) < 1e-12) Double.POSITIVE_INFINITY else (rect.width / 2.0) / abs(dx)
        val ty = if (abs(dy) < 1e-12) Double.POSITIVE_INFINITY else (rect.height / 2.0) / abs(dy)
        val t = min(tx, ty)
        return Point2D(center.x + dx * t, center.y + dy * t)
    }

    private fun moveToward(from: Point2D, to: Point2D, distance: Double): Point2D {
        val total = distance(from, to)
        if (total <= 1e-12 || distance <= 0.0) return from
        val t = min(1.0, distance / total)
        return Point2D(from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t)
    }

    private fun segmentIntersectsRect(a: Point2D, b: Point2D, r: AxisAlignedRect): Boolean {
        if (pointInsideRect(a, r) || pointInsideRect(b, r)) return true
        val corners = listOf(
            Point2D(r.left, r.top),
            Point2D(r.right, r.top),
            Point2D(r.right, r.bottom),
            Point2D(r.left, r.bottom)
        )
        return corners.indices.any { i -> segmentsIntersect(a, b, corners[i], corners[(i + 1) % corners.size]) }
    }

    private fun pointInsideRect(p: Point2D, r: AxisAlignedRect): Boolean =
        p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom

    private fun segmentsIntersect(a: Point2D, b: Point2D, c: Point2D, d: Point2D): Boolean {
        fun cross(p: Point2D, q: Point2D, r: Point2D): Double =
            (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x)
        fun onSegment(p: Point2D, q: Point2D, r: Point2D): Boolean =
            q.x >= min(p.x, r.x) - 1e-9 && q.x <= max(p.x, r.x) + 1e-9 &&
                q.y >= min(p.y, r.y) - 1e-9 && q.y <= max(p.y, r.y) + 1e-9

        val o1 = cross(a, b, c)
        val o2 = cross(a, b, d)
        val o3 = cross(c, d, a)
        val o4 = cross(c, d, b)
        if ((o1 > 0 && o2 < 0 || o1 < 0 && o2 > 0) && (o3 > 0 && o4 < 0 || o3 < 0 && o4 > 0)) return true
        if (abs(o1) <= 1e-9 && onSegment(a, c, b)) return true
        if (abs(o2) <= 1e-9 && onSegment(a, d, b)) return true
        if (abs(o3) <= 1e-9 && onSegment(c, a, d)) return true
        if (abs(o4) <= 1e-9 && onSegment(c, b, d)) return true
        return false
    }

    private fun pointAtPathFraction(points: List<Point2D>, fraction: Double): Point2D {
        val total = polylineLength(points)
        require(total > 0.0)
        val target = total * fraction.coerceIn(0.0, 1.0)
        var walked = 0.0
        for ((a, b) in points.zipWithNext()) {
            val length = distance(a, b)
            if (length <= 1e-12) continue
            if (walked + length >= target) {
                val t = (target - walked) / length
                return Point2D(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)
            }
            walked += length
        }
        return points.last()
    }

    private fun polylineLength(points: List<Point2D>): Double = points.zipWithNext().sumOf { (a, b) -> distance(a, b) }
    private fun distance(a: Point2D, b: Point2D): Double = hypot(b.x - a.x, b.y - a.y)
    private fun fmt(value: Double): String = "%.2f".format(java.util.Locale.US, value)

    private data class SegmentCandidate(val index: Int, val a: Point2D, val b: Point2D, val length: Double)
    private data class StraightAttempt(
        val placement: LabelPlacement?,
        val attempt: LabelPlacementAttempt,
        val sideEvidence: SideSelectionEvidence
    )
    private data class CalloutAttempt(
        val placement: LabelPlacement?,
        val attempt: LabelPlacementAttempt,
        val exceededHardMax: Boolean
    )
}
