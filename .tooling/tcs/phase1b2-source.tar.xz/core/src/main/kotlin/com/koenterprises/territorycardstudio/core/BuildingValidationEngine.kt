package com.koenterprises.territorycardstudio.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Platform-independent 300/301 building gate.
 *
 * The engine deliberately does not depend on Android graphics APIs. That keeps the same
 * deterministic geometry and source-binding behavior available to the desktop parity suite,
 * JVM unit tests, and the Android UI/rendering layers.
 */
data class BuildingValidationReport(
    val applicable: Boolean,
    val passed: Boolean,
    val buildingCount: Int,
    val assignedBuildingCount: Int,
    val memberLabelCount: Int,
    val failures: List<String>
)

object BuildingValidationEngine {
    private const val EPS = 1e-7
    private const val LABEL_BUFFER_PT = 0.35
    private val supportedHousingTypes = setOf(
        "apartment", "condo", "townhome", "mobile_home", "manufactured_home", "ancillary"
    )

    fun validateAssignment(assignment: KnowledgeBaseAssignment): BuildingValidationReport {
        return when (assignment.buildingAssignmentStatus) {
            "not_applicable" -> BuildingValidationReport(
                applicable = false,
                passed = true,
                buildingCount = 0,
                assignedBuildingCount = 0,
                memberLabelCount = 0,
                failures = emptyList()
            )

            "locked_300_301", "needs_300_301_reaudit" -> {
                val report = validateBuildings(assignment.buildings, applicable = true)
                val failures = report.failures.toMutableList()
                if (assignment.buildings.isEmpty()) {
                    failures.add("no recoverable building footprints")
                }
                val signatureMembers = assignment.assignmentSignature?.buildingMemberIds.orEmpty().map(::normalizeMemberId).sorted()
                val geometryMembers = assignment.buildings
                    .flatMap { it.sourceMembers }
                    .map(::normalizeMemberId)
                    .distinct()
                    .sorted()
                if (signatureMembers != geometryMembers) {
                    failures.add("building member inventory does not reconcile to assignment signature")
                }
                report.copy(passed = failures.isEmpty(), failures = failures)
            }

            else -> error("Unsupported building_assignment_status '${assignment.buildingAssignmentStatus}'")
        }
    }

    fun validateBuildings(buildings: List<BuildingGeometry>, applicable: Boolean = buildings.isNotEmpty()): BuildingValidationReport {
        if (!applicable) {
            return BuildingValidationReport(false, true, 0, 0, 0, emptyList())
        }

        val failures = mutableListOf<String>()
        val polygons = mutableListOf<Pair<BuildingGeometry, List<Point2D>>>()

        buildings.forEach { building ->
            if (building.housingType !in supportedHousingTypes) {
                failures.add("${building.buildingId}: unsupported housing_type '${building.housingType}'")
            }
            if (building.polygon.size < 3) {
                failures.add("${building.buildingId}: footprint requires at least 3 points")
                return@forEach
            }
            if (building.assigned && building.label.isBlank()) {
                failures.add("${building.buildingId}: assigned footprint requires an inside label")
            }
            if (!isValidPolygon(building.polygon)) {
                failures.add("${building.buildingId}: invalid/zero-area footprint")
                return@forEach
            }
            polygons.add(building to building.polygon)

            if (building.labelItems.isNotEmpty()) {
                val itemTexts = building.labelItems.map { it.text }
                building.labelItems.forEach { item ->
                    val rect = labelRectangle(item)
                    if (!polygonCoversShapeWithBuffer(building.polygon, rect, LABEL_BUFFER_PT)) {
                        failures.add("${building.buildingId}: source-bound label '${item.text}' is not fully inside its footprint")
                    }
                }
                if (building.sourceMembers.isNotEmpty()) {
                    val missing = building.sourceMembers.filterNot { it in itemTexts }
                    if (missing.isNotEmpty()) {
                        failures.add("${building.buildingId}: member labels missing from footprint: $missing")
                    }
                    if (itemTexts.size != itemTexts.toSet().size) {
                        failures.add("${building.buildingId}: duplicate member label binding")
                    }
                }
            } else if (building.assigned) {
                failures.add("${building.buildingId}: assigned footprint has no verified interior building/site label")
            }
        }

        for (i in polygons.indices) {
            val (a, pa) = polygons[i]
            for (j in i + 1 until polygons.size) {
                val (b, pb) = polygons[j]
                if (a.attachedGroup.isNotBlank() && a.attachedGroup == b.attachedGroup) continue
                if (polygonsIntersectOrTouch(pa, pb)) {
                    failures.add("${a.buildingId}/${b.buildingId}: separate buildings touch or overlap")
                }
            }
        }

        return BuildingValidationReport(
            applicable = true,
            passed = failures.isEmpty(),
            buildingCount = buildings.size,
            assignedBuildingCount = buildings.count { it.assigned },
            memberLabelCount = buildings.sumOf { it.labelItems.size },
            failures = failures
        )
    }

    internal fun normalizeMemberId(raw: String): String = raw.lowercase().filter { it.isLetterOrDigit() }

    private fun labelRectangle(item: BuildingLabelItem): List<Point2D> {
        val width = helveticaTextWidth(item.text, item.fontSizePt).coerceAtLeast(1.0)
        val height = item.fontSizePt * 0.86
        val angle = Math.toRadians(item.angleDeg)
        val ux = cos(angle)
        val uy = sin(angle)
        val vx = -uy
        val vy = ux
        val hw = width / 2.0
        val hh = height / 2.0
        fun corner(su: Double, sv: Double) = Point2D(
            item.center.x + ux * hw * su + vx * hh * sv,
            item.center.y + uy * hw * su + vy * hh * sv
        )
        return listOf(corner(-1.0, -1.0), corner(1.0, -1.0), corner(1.0, 1.0), corner(-1.0, 1.0))
    }

    /** Helvetica AFM widths used by the desktop engine's fitz Helvetica fallback. */
    private fun helveticaTextWidth(text: String, fontSizePt: Double): Double {
        fun width1000(c: Char): Int = when (c) {
            '0','1','2','3','4','5','6','7','8','9' -> 556
            'A','B','E','K','P','S','V','X','Y' -> 667
            'C','D','H','N','R','U' -> 722
            'G','O','Q' -> 778
            'I' -> 278
            'J' -> 500
            'F','T','Z' -> 611
            'L' -> 556
            'M' -> 833
            'W' -> 944
            'a','b','d','e','g','h','n','o','p','q','u' -> 556
            'c','k','s','v','x','y','z' -> 500
            'f','t' -> 278
            'i','j','l' -> 222
            'm' -> 833
            'r' -> 333
            'w' -> 722
            ' ' -> 278
            '-', '\u2010', '\u2011' -> 333
            '\u2012', '\u2013' -> 556
            '\u2014' -> 1000
            '.', ',', ':', ';', '!', '|' -> 278
            '/', '\\' -> 278
            '(', ')' -> 333
            '[', ']' -> 278
            '\'', '`' -> 191
            '"' -> 355
            '&' -> 667
            else -> 556
        }
        return text.sumOf { width1000(it) }.toDouble() * fontSizePt / 1000.0
    }

    private fun isValidPolygon(points: List<Point2D>): Boolean {
        if (points.size < 3 || abs(signedArea(points)) <= EPS) return false
        val n = points.size
        for (i in 0 until n) {
            val a1 = points[i]
            val a2 = points[(i + 1) % n]
            if (distance(a1, a2) <= EPS) return false
            for (j in i + 1 until n) {
                if (j == i || j == (i + 1) % n || (i == 0 && j == n - 1)) continue
                val b1 = points[j]
                val b2 = points[(j + 1) % n]
                if (segmentsIntersectInclusive(a1, a2, b1, b2)) return false
            }
        }
        return true
    }

    private fun signedArea(points: List<Point2D>): Double {
        var sum = 0.0
        for (i in points.indices) {
            val a = points[i]
            val b = points[(i + 1) % points.size]
            sum += a.x * b.y - b.x * a.y
        }
        return sum / 2.0
    }

    private fun polygonCoversShapeWithBuffer(polygon: List<Point2D>, shape: List<Point2D>, buffer: Double): Boolean {
        // Sample the entire label perimeter rather than only its corners so concave building
        // footprints cannot falsely contain a rectangle that bridges an exterior notch.
        val samples = mutableListOf<Point2D>()
        for (i in shape.indices) {
            val a = shape[i]
            val b = shape[(i + 1) % shape.size]
            val steps = max(8, ceil(distance(a, b) / 0.25).toInt())
            for (step in 0..steps) {
                val t = step.toDouble() / steps
                samples.add(Point2D(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
            }
        }
        samples.add(Point2D(shape.sumOf { it.x } / shape.size, shape.sumOf { it.y } / shape.size))
        return samples.all { pointCoveredWithBuffer(it, polygon, buffer) }
    }

    private fun pointCoveredWithBuffer(point: Point2D, polygon: List<Point2D>, buffer: Double): Boolean {
        if (pointInPolygonInclusive(point, polygon)) return true
        var best = Double.POSITIVE_INFINITY
        for (i in polygon.indices) {
            best = min(best, pointToSegmentDistance(point, polygon[i], polygon[(i + 1) % polygon.size]))
        }
        return best <= buffer + EPS
    }

    private fun polygonsIntersectOrTouch(a: List<Point2D>, b: List<Point2D>): Boolean {
        for (i in a.indices) {
            val a1 = a[i]
            val a2 = a[(i + 1) % a.size]
            for (j in b.indices) {
                val b1 = b[j]
                val b2 = b[(j + 1) % b.size]
                if (segmentsIntersectInclusive(a1, a2, b1, b2)) return true
            }
        }
        return pointInPolygonInclusive(a.first(), b) || pointInPolygonInclusive(b.first(), a)
    }

    private fun pointInPolygonInclusive(p: Point2D, poly: List<Point2D>): Boolean {
        for (i in poly.indices) {
            if (pointOnSegment(p, poly[i], poly[(i + 1) % poly.size])) return true
        }
        var inside = false
        var j = poly.lastIndex
        for (i in poly.indices) {
            val pi = poly[i]
            val pj = poly[j]
            val crosses = ((pi.y > p.y) != (pj.y > p.y)) &&
                (p.x < (pj.x - pi.x) * (p.y - pi.y) / (pj.y - pi.y) + pi.x)
            if (crosses) inside = !inside
            j = i
        }
        return inside
    }

    private fun segmentsIntersectInclusive(a: Point2D, b: Point2D, c: Point2D, d: Point2D): Boolean {
        val o1 = orientation(a, b, c)
        val o2 = orientation(a, b, d)
        val o3 = orientation(c, d, a)
        val o4 = orientation(c, d, b)
        if (o1 * o2 < -EPS && o3 * o4 < -EPS) return true
        if (abs(o1) <= EPS && pointOnSegment(c, a, b)) return true
        if (abs(o2) <= EPS && pointOnSegment(d, a, b)) return true
        if (abs(o3) <= EPS && pointOnSegment(a, c, d)) return true
        if (abs(o4) <= EPS && pointOnSegment(b, c, d)) return true
        return false
    }

    private fun orientation(a: Point2D, b: Point2D, c: Point2D): Double =
        (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)

    private fun pointOnSegment(p: Point2D, a: Point2D, b: Point2D): Boolean {
        if (abs(orientation(a, b, p)) > EPS) return false
        return p.x >= min(a.x, b.x) - EPS && p.x <= max(a.x, b.x) + EPS &&
            p.y >= min(a.y, b.y) - EPS && p.y <= max(a.y, b.y) + EPS
    }

    private fun pointToSegmentDistance(p: Point2D, a: Point2D, b: Point2D): Double {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val len2 = dx * dx + dy * dy
        if (len2 <= EPS) return distance(p, a)
        val t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2
        val clamped = max(0.0, min(1.0, t))
        return hypot(p.x - (a.x + clamped * dx), p.y - (a.y + clamped * dy))
    }

    private fun distance(a: Point2D, b: Point2D): Double = hypot(a.x - b.x, a.y - b.y)
}
