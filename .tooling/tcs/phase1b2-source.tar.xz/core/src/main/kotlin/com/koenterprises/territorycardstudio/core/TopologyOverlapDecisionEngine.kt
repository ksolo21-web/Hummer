package com.koenterprises.territorycardstudio.core

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Platform-independent parity port of the desktop road-topology and cross-territory overlap gates.
 *
 * Important authority rules preserved here:
 * - work colors bind to real junction-to-junction road segments only;
 * - same-name roads are never enough to prove duplicate work;
 * - a proven duplicate workable segment blocks offline;
 * - weaker matches route to master/live-GIS review instead of being guessed;
 * - explicit permanent patches remain higher authority;
 * - exact approved artifacts are never rewritten merely to satisfy a newer extractor.
 */
object TopologyOverlapDecisionEngine {
    const val ENDPOINT_NEIGHBOR_TOLERANCE_PT = 3.0
    const val COLOR_TRANSITION_TOLERANCE_PT = 0.75

    private val validStatuses = setOf("green", "yellow", "red", "context")
    private val validRoles = setOf("interior", "perimeter", "excluded", "context")

    fun normalizeRoadName(name: String): String =
        name.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()

    fun topologySignature(roads: List<RoadGeometry>): TopologySignature {
        val segments = roads.mapIndexedNotNull { index, road ->
            val normalized = normalizeRoadName(road.name)
            if (normalized.isBlank() || road.points.isEmpty()) return@mapIndexedNotNull null
            TopologySegment(
                road = normalized,
                status = road.status,
                role = road.role,
                insideSide = road.insideSide,
                accessOnly = road.accessOnly,
                endpointAKind = road.endpointAKind,
                endpointBKind = road.endpointBKind,
                endpointANeighbors = endpointNeighbors(roads, index, first = true),
                endpointBNeighbors = endpointNeighbors(roads, index, first = false)
            )
        }
        return TopologySignature(segments, segments.size)
    }

    fun validateIntersectionColorRoles(roads: List<RoadGeometry>): TopologyValidationReport {
        val failures = mutableListOf<String>()
        roads.forEach { road -> failures += validateRoad(road) }

        for (i in roads.indices) {
            val a = roads[i]
            for (j in i + 1 until roads.size) {
                val b = roads[j]
                if (normalizeRoadName(a.name) != normalizeRoadName(b.name) || a.status == b.status) continue
                if (a.points.size < 2 || b.points.size < 2) continue

                val endpointPairs = listOf(
                    EndpointPair(a.points.first(), a.endpointAKind, b.points.first(), b.endpointAKind),
                    EndpointPair(a.points.first(), a.endpointAKind, b.points.last(), b.endpointBKind),
                    EndpointPair(a.points.last(), a.endpointBKind, b.points.first(), b.endpointAKind),
                    EndpointPair(a.points.last(), a.endpointBKind, b.points.last(), b.endpointBKind)
                )
                var shared = false
                endpointPairs.forEach { pair ->
                    if (distance(pair.a, pair.b) <= COLOR_TRANSITION_TOLERANCE_PT) {
                        shared = true
                        if (pair.aKind != "junction" || pair.bKind != "junction") {
                            failures += "${a.segmentId}/${b.segmentId}: color transition is not at a real junction"
                        }
                    }
                }
                if (!shared && polylineDistance(a.points, b.points) <= COLOR_TRANSITION_TOLERANCE_PT) {
                    failures += "${a.segmentId}/${b.segmentId}: contiguous same-road color transition lacks a shared junction endpoint"
                }
            }
        }

        return TopologyValidationReport(
            segmentCount = roads.size,
            failures = failures,
            passed = failures.isEmpty(),
            midSegmentColorTransitionCount = failures.count { "transition" in it },
            accessOnlyYellowCount = failures.count { "access-only" in it }
        )
    }

    /** Candidate-time overlap gate used before a newly generated card can proceed toward release. */
    fun crossTerritoryOverlapCheck(
        identity: TerritoryIdentity,
        candidateTopology: TopologySignature?,
        kb: TerritoryKnowledgeBase,
        exactLocked: Boolean = false
    ): CandidateOverlapDecision {
        if (exactLocked) {
            val global = kb.crossTerritoryOverlapAudit
            return CandidateOverlapDecision(
                status = "LOCKED_CORPUS_ACCEPTED",
                passed = global.blockingCount == 0,
                blocking = emptyList(),
                reviewCandidates = emptyList(),
                allowed = emptyList(),
                globalBlockingCount = global.blockingCount,
                note = "Exact approved artifact uses the frozen corpus overlap audit; its bytes are not rewritten.",
                permanentPatchCount = kb.permanentPatches.size
            )
        }
        if (candidateTopology == null || candidateTopology.junctionBoundedSegments.isEmpty()) {
            return CandidateOverlapDecision(
                status = "UNRESOLVED",
                passed = false,
                blocking = emptyList(),
                reviewCandidates = emptyList(),
                allowed = emptyList(),
                hardFailure = "candidate road geometry unavailable for cross-territory duplicate-work proof",
                permanentPatchCount = kb.permanentPatches.size
            )
        }

        val blockers = mutableListOf<CandidateOverlapFinding>()
        val reviews = mutableListOf<CandidateOverlapFinding>()
        val allowed = mutableListOf<CandidateOverlapFinding>()

        candidateTopology.junctionBoundedSegments.forEach { candidate ->
            kb.assignments.forEach assignmentLoop@ { (otherId, assignment) ->
                if (otherId == identity.displayId) return@assignmentLoop
                assignment.topologySignature?.junctionBoundedSegments.orEmpty().forEach segmentLoop@ { existing ->
                    if (existing.road != candidate.road) return@segmentLoop
                    when (val classification = classifyPair(identity.displayId, otherId, candidate, existing, kb)) {
                        is PairClassification.Block -> blockers += classification.finding
                        is PairClassification.Review -> reviews += classification.finding
                        is PairClassification.Allowed -> allowed += classification.finding
                        PairClassification.Ignore -> Unit
                    }
                }
            }
        }

        val dedupedReviews = reviews.distinctBy { Triple(it.road, it.otherTerritory, it.confidence) }
        return CandidateOverlapDecision(
            status = if (blockers.isEmpty()) "PASS" else "BLOCKED",
            passed = blockers.isEmpty(),
            blocking = blockers,
            reviewCandidates = dedupedReviews,
            allowed = allowed,
            permanentPatchCount = kb.permanentPatches.size
        )
    }

    /**
     * Recomputes the frozen corpus audit using the same deterministic rules that built the desktop KB.
     * This gives Android a strong parity assertion instead of merely trusting stored summary counts.
     */
    fun auditFrozenAssignments(kb: TerritoryKnowledgeBase): RecomputedOverlapAudit {
        val byRoad = linkedMapOf<String, MutableList<Pair<String, TopologySegment>>>()
        kb.assignments.forEach { (territory, assignment) ->
            assignment.topologySignature?.junctionBoundedSegments.orEmpty().forEach { segment ->
                if (segment.road.isNotBlank()) byRoad.getOrPut(segment.road) { mutableListOf() } += territory to segment
            }
        }

        val blockers = mutableListOf<OverlapCandidate>()
        val reviews = mutableListOf<OverlapCandidate>()
        val allowed = mutableListOf<AllowedSharedFinding>()
        val seen = mutableSetOf<Triple<String, String, String>>()

        byRoad.forEach { (road, values) ->
            for (i in values.indices) {
                val (ta, a) = values[i]
                for (j in i + 1 until values.size) {
                    val (tb, b) = values[j]
                    if (ta == tb) continue
                    val low = minOf(ta, tb)
                    val high = maxOf(ta, tb)
                    if (!seen.add(Triple(low, high, road))) continue

                    val ka = segmentEndpointKey(a)
                    val kbKey = segmentEndpointKey(b)
                    val sharedEndpoints = ka != null && kbKey != null && ka == kbKey
                    val oneEnd = endpointNeighborUnion(a).intersect(endpointNeighborUnion(b)).isNotEmpty()
                    val sa = a.status
                    val sb = b.status

                    if (sa == "red" || sb == "red" || a.role == "context" || b.role == "context") {
                        if (sharedEndpoints) {
                            allowed += AllowedSharedFinding(road, listOf(ta, tb), "red/context sharing")
                        }
                        continue
                    }

                    if (sharedEndpoints) {
                        val ca = cardinalSide(a.insideSide)
                        val cb = cardinalSide(b.insideSide)
                        if (sa == "yellow" && sb == "yellow" && ca.isNotBlank() && cb.isNotBlank() && oppositeCardinals(ca, cb)) {
                            allowed += AllowedSharedFinding(road, listOf(ta, tb), "yellow opposite cardinal sides")
                        } else if (sa in setOf("green", "yellow") && sb in setOf("green", "yellow")) {
                            if (sa == "yellow" && sb == "yellow" && (ca.isBlank() || cb.isBlank())) {
                                reviews += OverlapCandidate(
                                    road, listOf(ta, tb), "high-segment/side-unresolved",
                                    "same junction-bounded road, yellow side requires georeferenced resolution"
                                )
                            } else {
                                blockers += OverlapCandidate(
                                    road, listOf(ta, tb), "high",
                                    "same proven junction-bounded workable road segment"
                                )
                            }
                        }
                    } else if (oneEnd) {
                        reviews += OverlapCandidate(
                            road, listOf(ta, tb), "medium",
                            "same road with one endpoint/junction relationship matching; master/live resolution required"
                        )
                    }
                }
            }
        }

        val roadToIds = sortedMapOf<String, MutableSet<String>>()
        kb.assignments.forEach { (territory, assignment) ->
            assignment.roadNameInventory.forEach { road -> roadToIds.getOrPut(road) { sortedSetOf() } += territory }
        }
        val nameGroups = roadToIds.filterValues { it.size > 1 }.map { (road, ids) ->
            OverlapCandidate(
                road = road,
                territories = ids.sorted(),
                confidence = "low-name-only",
                reason = "same street name appears in multiple approved artifacts; master/live GIS must prove whether the worked physical segment overlaps"
            )
        }
        return RecomputedOverlapAudit(blockers, reviews, nameGroups, allowed)
    }

    internal fun classifyPair(
        candidateTerritory: String,
        otherTerritory: String,
        candidate: TopologySegment,
        existing: TopologySegment,
        kb: TerritoryKnowledgeBase
    ): PairClassification {
        if (candidate.road != existing.road) return PairClassification.Ignore
        if (existing.status == "red" || candidate.status == "red" || existing.role == "context" || candidate.role == "context") {
            return PairClassification.Ignore
        }

        if (isAuthoritativeOppositeSidePatch(candidateTerritory, otherTerritory, candidate.road, kb)) {
            return PairClassification.Allowed(
                CandidateOverlapFinding(candidate.road, otherTerritory, "authoritative-patch", reason = "permanent 278/280 opposite-side patch")
            )
        }

        val candidateKey = segmentEndpointKey(candidate)
        val existingKey = segmentEndpointKey(existing)
        if (candidateKey != null && existingKey != null && candidateKey == existingKey) {
            val ca = cardinalSide(candidate.insideSide)
            val oa = cardinalSide(existing.insideSide)
            if (candidate.status == "yellow" && existing.status == "yellow" && ca.isNotBlank() && oa.isNotBlank() && oppositeCardinals(ca, oa)) {
                return PairClassification.Allowed(
                    CandidateOverlapFinding(candidate.road, otherTerritory, "high", reason = "same boundary segment, opposite cardinal yellow sides")
                )
            }
            if (candidate.status == "yellow" && existing.status == "yellow" && (ca.isBlank() || oa.isBlank())) {
                return PairClassification.Review(
                    CandidateOverlapFinding(
                        candidate.road, otherTerritory, "high-segment/side-unresolved",
                        candidateStatus = candidate.status, existingStatus = existing.status,
                        reason = "same junction-bounded road; yellow worked side needs georeferenced master/live resolution"
                    )
                )
            }
            return PairClassification.Block(
                CandidateOverlapFinding(
                    candidate.road, otherTerritory, "high",
                    candidateStatus = candidate.status, existingStatus = existing.status,
                    reason = "same proven junction-bounded workable road segment is assigned in two territories"
                )
            )
        }

        if (endpointNeighborUnion(candidate).intersect(endpointNeighborUnion(existing)).isNotEmpty()) {
            return PairClassification.Review(
                CandidateOverlapFinding(
                    candidate.road, otherTerritory, "medium",
                    candidateStatus = candidate.status, existingStatus = existing.status,
                    reason = "same road and at least one junction relationship match; master/live GIS resolution required"
                )
            )
        }
        return PairClassification.Ignore
    }

    private fun validateRoad(road: RoadGeometry): List<String> {
        val errors = mutableListOf<String>()
        if (road.status !in validStatuses) errors += "${road.segmentId}: invalid status '${road.status}'"
        if (road.role !in validRoles) errors += "${road.segmentId}: invalid role '${road.role}'"
        if (road.points.size < 2) errors += "${road.segmentId}: road needs at least two points"
        if (road.role == "perimeter" && road.insideSide !in setOf("left", "right")) {
            errors += "${road.segmentId}: perimeter road requires inside_side left/right"
        }
        if (road.status == "yellow" && road.role != "perimeter") {
            errors += "${road.segmentId}: yellow is valid only for a one-side perimeter assignment"
        }
        if (road.accessOnly && road.status != "red") errors += "${road.segmentId}: access-only road must remain red"
        if (road.status == "green" && road.role == "perimeter") {
            errors += "${road.segmentId}: perimeter cannot be green unless both sides are actually assigned"
        }
        return errors
    }

    private fun endpointNeighbors(roads: List<RoadGeometry>, index: Int, first: Boolean): List<String> {
        val road = roads[index]
        if (road.points.isEmpty()) return emptyList()
        val point = if (first) road.points.first() else road.points.last()
        val selfName = normalizeRoadName(road.name)
        val result = sortedSetOf<String>()
        roads.forEachIndexed { otherIndex, other ->
            if (otherIndex == index || other.points.size < 2) return@forEachIndexed
            val otherName = normalizeRoadName(other.name)
            if (otherName.isBlank()) return@forEachIndexed
            if (pointToPolylineDistance(point, other.points) <= ENDPOINT_NEIGHBOR_TOLERANCE_PT) result += otherName
        }
        result.remove(selfName)
        return result.toList()
    }

    private fun isAuthoritativeOppositeSidePatch(
        candidateTerritory: String,
        otherTerritory: String,
        normalizedRoad: String,
        kb: TerritoryKnowledgeBase
    ): Boolean {
        val expectedPair = setOf("278", "280")
        if (setOf(candidateTerritory, otherTerritory) != expectedPair || normalizedRoad != "bridgestone dr") return false
        val patch = kb.permanentPatches["278-280-BRIDGESTONE"] ?: return false
        return patch.status == "active" && patch.territories.toSet() == expectedPair && normalizeRoadName(patch.road ?: "Bridgestone Dr") == normalizedRoad
    }

    private fun cardinalSide(side: String): String {
        val lower = side.lowercase()
        return listOf("north", "south", "east", "west").firstOrNull { it in lower }.orEmpty()
    }

    private fun oppositeCardinals(a: String, b: String): Boolean =
        setOf(a, b) == setOf("north", "south") || setOf(a, b) == setOf("east", "west")

    private fun endpointNeighborUnion(segment: TopologySegment): Set<String> =
        (segment.endpointANeighbors + segment.endpointBNeighbors).toSet()

    private fun segmentEndpointKey(segment: TopologySegment): EndpointKey? {
        val a = segment.endpointANeighbors.sorted()
        val b = segment.endpointBNeighbors.sorted()
        if (a.isEmpty() || b.isEmpty()) return null
        return if (compareStringLists(a, b) <= 0) EndpointKey(a, b) else EndpointKey(b, a)
    }

    private fun compareStringLists(a: List<String>, b: List<String>): Int {
        val n = min(a.size, b.size)
        for (i in 0 until n) {
            val c = a[i].compareTo(b[i])
            if (c != 0) return c
        }
        return a.size.compareTo(b.size)
    }

    private fun distance(a: Point2D, b: Point2D): Double = hypot(a.x - b.x, a.y - b.y)

    private fun pointToPolylineDistance(point: Point2D, polyline: List<Point2D>): Double {
        if (polyline.isEmpty()) return Double.POSITIVE_INFINITY
        if (polyline.size == 1) return distance(point, polyline.first())
        var best = Double.POSITIVE_INFINITY
        for (i in 0 until polyline.lastIndex) {
            best = min(best, pointToSegmentDistance(point, polyline[i], polyline[i + 1]))
        }
        return best
    }

    private fun polylineDistance(a: List<Point2D>, b: List<Point2D>): Double {
        if (a.size < 2 || b.size < 2) return Double.POSITIVE_INFINITY
        var best = Double.POSITIVE_INFINITY
        for (i in 0 until a.lastIndex) {
            for (j in 0 until b.lastIndex) {
                best = min(best, segmentDistance(a[i], a[i + 1], b[j], b[j + 1]))
                if (best == 0.0) return 0.0
            }
        }
        return best
    }

    private fun segmentDistance(a: Point2D, b: Point2D, c: Point2D, d: Point2D): Double {
        if (segmentsIntersect(a, b, c, d)) return 0.0
        return min(
            min(pointToSegmentDistance(a, c, d), pointToSegmentDistance(b, c, d)),
            min(pointToSegmentDistance(c, a, b), pointToSegmentDistance(d, a, b))
        )
    }

    private fun pointToSegmentDistance(p: Point2D, a: Point2D, b: Point2D): Double {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val lengthSquared = dx * dx + dy * dy
        if (lengthSquared == 0.0) return distance(p, a)
        val t = max(0.0, min(1.0, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lengthSquared))
        return hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy))
    }

    private fun segmentsIntersect(a: Point2D, b: Point2D, c: Point2D, d: Point2D): Boolean {
        fun cross(p: Point2D, q: Point2D, r: Point2D): Double =
            (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x)
        fun onSegment(p: Point2D, q: Point2D, r: Point2D): Boolean =
            q.x >= min(p.x, r.x) - 1e-9 && q.x <= max(p.x, r.x) + 1e-9 &&
                q.y >= min(p.y, r.y) - 1e-9 && q.y <= max(p.y, r.y) + 1e-9

        val o1 = cross(a, b, c)
        val o2 = cross(a, b, d)
        val o3 = cross(c, d, a)
        val o4 = cross(c, d, b)
        if ((o1 > 0 && o2 < 0 || o1 < 0 && o2 > 0) && (o3 > 0 && o4 < 0 || o3 < 0 && o4 > 0)) return true
        if (kotlin.math.abs(o1) <= 1e-9 && onSegment(a, c, b)) return true
        if (kotlin.math.abs(o2) <= 1e-9 && onSegment(a, d, b)) return true
        if (kotlin.math.abs(o3) <= 1e-9 && onSegment(c, a, d)) return true
        if (kotlin.math.abs(o4) <= 1e-9 && onSegment(c, b, d)) return true
        return false
    }

    private data class EndpointPair(val a: Point2D, val aKind: String, val b: Point2D, val bKind: String)
    private data class EndpointKey(val first: List<String>, val second: List<String>)
}

data class TopologyValidationReport(
    val segmentCount: Int,
    val failures: List<String>,
    val passed: Boolean,
    val midSegmentColorTransitionCount: Int,
    val accessOnlyYellowCount: Int
)

data class CandidateOverlapFinding(
    val road: String,
    val otherTerritory: String,
    val confidence: String,
    val candidateStatus: String? = null,
    val existingStatus: String? = null,
    val reason: String
)

data class CandidateOverlapDecision(
    val status: String,
    val passed: Boolean,
    val blocking: List<CandidateOverlapFinding>,
    val reviewCandidates: List<CandidateOverlapFinding>,
    val allowed: List<CandidateOverlapFinding>,
    val globalBlockingCount: Int = 0,
    val hardFailure: String? = null,
    val note: String? = null,
    val permanentPatchCount: Int
) {
    val blockingCount: Int get() = blocking.size
    val reviewCandidateCount: Int get() = reviewCandidates.size
}

data class AllowedSharedFinding(val road: String, val territories: List<String>, val reason: String)

data class RecomputedOverlapAudit(
    val blockingDuplicateWork: List<OverlapCandidate>,
    val reviewCandidates: List<OverlapCandidate>,
    val nameOnlyOverlapGroups: List<OverlapCandidate>,
    val allowedSharedContext: List<AllowedSharedFinding>
) {
    val blockingCount: Int get() = blockingDuplicateWork.size
    val reviewCandidateCount: Int get() = reviewCandidates.size
    val nameOnlyOverlapGroupCount: Int get() = nameOnlyOverlapGroups.size
}

internal sealed interface PairClassification {
    data object Ignore : PairClassification
    data class Allowed(val finding: CandidateOverlapFinding) : PairClassification
    data class Review(val finding: CandidateOverlapFinding) : PairClassification
    data class Block(val finding: CandidateOverlapFinding) : PairClassification
}
