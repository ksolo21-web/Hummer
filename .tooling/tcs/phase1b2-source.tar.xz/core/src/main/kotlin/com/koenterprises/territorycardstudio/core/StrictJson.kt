package com.koenterprises.territorycardstudio.core

import java.io.Reader

sealed class JsonValue {
    data class Obj(val values: LinkedHashMap<String, JsonValue>) : JsonValue()
    data class Arr(val values: List<JsonValue>) : JsonValue()
    data class Str(val value: String) : JsonValue()
    data class Num(val raw: String) : JsonValue() {
        fun asInt(): Int = raw.toIntOrNull() ?: error("Expected integer, got $raw")
        fun asDouble(): Double = raw.toDoubleOrNull() ?: error("Expected number, got $raw")
    }
    data class Bool(val value: Boolean) : JsonValue()
    object Null : JsonValue()
}

object StrictJson {
    fun parse(reader: Reader): JsonValue = Parser(reader.readText()).parse()

    private class Parser(private val text: String) {
        private var i = 0

        fun parse(): JsonValue {
            skipWs()
            val result = value()
            skipWs()
            require(i == text.length) { "Trailing JSON content at offset $i" }
            return result
        }

        private fun value(): JsonValue {
            skipWs()
            require(i < text.length) { "Unexpected end of JSON" }
            return when (text[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> JsonValue.Str(string())
                't' -> { literal("true"); JsonValue.Bool(true) }
                'f' -> { literal("false"); JsonValue.Bool(false) }
                'n' -> { literal("null"); JsonValue.Null }
                '-', in '0'..'9' -> JsonValue.Num(number())
                else -> error("Unexpected JSON token '${text[i]}' at offset $i")
            }
        }

        private fun obj(): JsonValue.Obj {
            expect('{')
            skipWs()
            val values = linkedMapOf<String, JsonValue>()
            if (peek('}')) { i++; return JsonValue.Obj(values) }
            while (true) {
                skipWs()
                require(peek('"')) { "Expected JSON object key at offset $i" }
                val key = string()
                require(!values.containsKey(key)) { "Duplicate JSON object key '$key'" }
                skipWs(); expect(':'); skipWs()
                values[key] = value()
                skipWs()
                when {
                    peek(',') -> { i++; continue }
                    peek('}') -> { i++; return JsonValue.Obj(values) }
                    else -> error("Expected ',' or '}' at offset $i")
                }
            }
        }

        private fun arr(): JsonValue.Arr {
            expect('[')
            skipWs()
            val values = mutableListOf<JsonValue>()
            if (peek(']')) { i++; return JsonValue.Arr(values) }
            while (true) {
                values += value()
                skipWs()
                when {
                    peek(',') -> { i++; continue }
                    peek(']') -> { i++; return JsonValue.Arr(values) }
                    else -> error("Expected ',' or ']' at offset $i")
                }
            }
        }

        private fun string(): String {
            expect('"')
            val out = StringBuilder()
            while (i < text.length) {
                val c = text[i++]
                when (c) {
                    '"' -> return out.toString()
                    '\\' -> {
                        require(i < text.length) { "Unterminated JSON escape" }
                        when (val e = text[i++]) {
                            '"', '\\', '/' -> out.append(e)
                            'b' -> out.append('\b')
                            'f' -> out.append('\u000C')
                            'n' -> out.append('\n')
                            'r' -> out.append('\r')
                            't' -> out.append('\t')
                            'u' -> {
                                require(i + 4 <= text.length) { "Short unicode escape at offset $i" }
                                val hex = text.substring(i, i + 4)
                                val code = hex.toIntOrNull(16) ?: error("Invalid unicode escape \\u$hex")
                                out.append(code.toChar())
                                i += 4
                            }
                            else -> error("Invalid JSON escape \\$e at offset ${i - 1}")
                        }
                    }
                    else -> {
                        require(c.code >= 0x20) { "Control character in JSON string at offset ${i - 1}" }
                        out.append(c)
                    }
                }
            }
            error("Unterminated JSON string")
        }

        private fun number(): String {
            val start = i
            if (peek('-')) i++
            require(i < text.length) { "Invalid JSON number at offset $start" }
            if (peek('0')) {
                i++
            } else {
                require(text[i] in '1'..'9') { "Invalid JSON number at offset $start" }
                while (i < text.length && text[i].isDigit()) i++
            }
            if (peek('.')) {
                i++
                require(i < text.length && text[i].isDigit()) { "Invalid JSON fraction at offset $start" }
                while (i < text.length && text[i].isDigit()) i++
            }
            if (i < text.length && (text[i] == 'e' || text[i] == 'E')) {
                i++
                if (i < text.length && (text[i] == '+' || text[i] == '-')) i++
                require(i < text.length && text[i].isDigit()) { "Invalid JSON exponent at offset $start" }
                while (i < text.length && text[i].isDigit()) i++
            }
            return text.substring(start, i)
        }

        private fun literal(s: String) {
            require(text.regionMatches(i, s, 0, s.length)) { "Expected '$s' at offset $i" }
            i += s.length
        }

        private fun skipWs() {
            while (i < text.length && text[i] in charArrayOf(' ', '\n', '\r', '\t')) i++
        }

        private fun expect(c: Char) {
            require(i < text.length && text[i] == c) { "Expected '$c' at offset $i" }
            i++
        }

        private fun peek(c: Char): Boolean = i < text.length && text[i] == c
    }
}

internal fun JsonValue.obj(context: String): LinkedHashMap<String, JsonValue> =
    (this as? JsonValue.Obj)?.values ?: error("$context must be an object")

internal fun JsonValue.arr(context: String): List<JsonValue> =
    (this as? JsonValue.Arr)?.values ?: error("$context must be an array")

internal fun JsonValue.string(context: String): String =
    (this as? JsonValue.Str)?.value ?: error("$context must be a string")

internal fun JsonValue.bool(context: String): Boolean =
    (this as? JsonValue.Bool)?.value ?: error("$context must be a boolean")

internal fun JsonValue.int(context: String): Int =
    (this as? JsonValue.Num)?.asInt() ?: error("$context must be an integer")

internal fun JsonValue.double(context: String): Double =
    (this as? JsonValue.Num)?.asDouble() ?: error("$context must be a number")

internal fun Map<String, JsonValue>.required(name: String, context: String): JsonValue =
    this[name] ?: error("Missing $context.$name")

internal fun Map<String, JsonValue>.optionalString(name: String): String? = when (val v = this[name]) {
    null, JsonValue.Null -> null
    is JsonValue.Str -> v.value
    else -> error("$name must be string or null")
}

internal fun Map<String, JsonValue>.stringList(name: String, context: String): List<String> =
    required(name, context).arr("$context.$name").mapIndexed { idx, v -> v.string("$context.$name[$idx]") }
