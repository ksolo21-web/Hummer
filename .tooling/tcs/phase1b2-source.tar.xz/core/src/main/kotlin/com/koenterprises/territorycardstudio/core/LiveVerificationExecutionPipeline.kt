package com.koenterprises.territorycardstudio.core

import java.io.IOException
import java.security.MessageDigest
import java.time.Instant

enum class VerificationPipelineEventPhase {
    EXECUTION,
    PARSE_ASSEMBLY,
    DEPENDENCY
}

enum class VerificationPipelineBindingKind {
    PLAN,
    COMPOSITE_PLANS,
    NONE
}

enum class VerificationPipelineStageOutcome {
    SUCCEEDED,
    FAILED,
    SKIPPED_DEPENDENCY
}

data class VerificationPipelineEvent(
    val providerId: String,
    val stage: ProviderQueryStage,
    val phase: VerificationPipelineEventPhase,
    val bindingKind: VerificationPipelineBindingKind,
    val bindingFingerprint: String?,
    val outcome: VerificationPipelineStageOutcome,
    val responseSha256: String?,
    val errorCode: String?
) {
    init {
        require(providerId.isNotBlank())
        bindingFingerprint?.let { require(PIPELINE_SHA256_HEX.matches(it)) { "Invalid pipeline binding fingerprint" } }
        when (bindingKind) {
            VerificationPipelineBindingKind.NONE -> require(bindingFingerprint == null) { "NONE binding cannot carry a fingerprint" }
            VerificationPipelineBindingKind.PLAN, VerificationPipelineBindingKind.COMPOSITE_PLANS -> require(bindingFingerprint != null) { "Bound event needs a fingerprint" }
        }
        responseSha256?.let { require(PIPELINE_SHA256_HEX.matches(it)) { "Invalid pipeline response SHA-256" } }
        when (outcome) {
            VerificationPipelineStageOutcome.SUCCEEDED -> {
                require(bindingFingerprint != null) { "Successful provider stage needs a binding fingerprint" }
                require(responseSha256 != null) { "Successful provider stage needs a response SHA-256" }
                require(errorCode == null) { "Successful provider stage cannot carry an error code" }
            }
            VerificationPipelineStageOutcome.FAILED -> require(!errorCode.isNullOrBlank()) {
                "Failed provider stage needs an error code"
            }
            VerificationPipelineStageOutcome.SKIPPED_DEPENDENCY -> {
                require(phase == VerificationPipelineEventPhase.DEPENDENCY)
                require(bindingKind == VerificationPipelineBindingKind.NONE)
                require(bindingFingerprint == null) { "Dependency-skipped provider stage cannot claim a query binding" }
                require(responseSha256 == null) { "Dependency-skipped provider stage cannot claim a response digest" }
                require(!errorCode.isNullOrBlank()) { "Dependency-skipped provider stage needs a reason code" }
            }
        }
    }
}

data class LiveVerificationExecutionResult(
    val requestFingerprint: String,
    val evidence: List<ProviderVerificationEvidence>,
    val decision: LiveGeometryVerificationDecision,
    val events: List<VerificationPipelineEvent>
) {
    init {
        require(PIPELINE_SHA256_HEX.matches(requestFingerprint))
        require(evidence.all { it.requestFingerprint == requestFingerprint }) {
            "Pipeline result contains evidence from another verification request"
        }
        require(evidence.map { it.providerId }.distinct().size == evidence.size) {
            "Pipeline result contains duplicate provider evidence"
        }
    }
}

class LiveVerificationExecutionPipeline(
    private val coordinator: ProviderExecutionCoordinator
) {
    fun verify(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy,
        cacheMode: ProviderCacheMode = ProviderCacheMode.READ_WRITE
    ): LiveVerificationExecutionResult {
        require(LiveGeometryVerificationRequestFactory.fingerprintMatches(request)) {
            "Verification request fingerprint mismatch"
        }
        require(request.onlinePolicyRevision == policy.revision) {
            "Verification request policy revision mismatch"
        }
        require(policy.releasePolicy.defaultAppMode == "required") {
            "Live verification execution requires required-mode policy"
        }

        val sourceTruthFailures = request.sourceTruth.hardFailures(request.territoryDisplayId)
        if (sourceTruthFailures.isNotEmpty()) {
            val decision = LiveGeometryVerificationReconciler.reconcile(request, policy, emptyList())
            require(!decision.renderable) { "Source-truth failure cannot produce a renderable verification decision" }
            return LiveVerificationExecutionResult(
                requestFingerprint = request.requestFingerprint,
                evidence = emptyList(),
                decision = decision,
                events = emptyList()
            )
        }

        val plans = ProviderQueryPlanner.initialPlans(request, policy)
        val evidence = mutableListOf<ProviderVerificationEvidence>()
        val events = mutableListOf<VerificationPipelineEvent>()

        plans.oaklandRoads?.let { plan ->
            evidence += executeRoadProvider(
                request = request,
                providerId = "oakland_county_roads",
                plans = listOf(plan),
                cacheMode = cacheMode,
                events = events,
                parser = { raws -> ProviderResponseParser.parseOaklandRoads(raws.single()) }
            )
        }

        evidence += executeRoadProvider(
            request = request,
            providerId = "census_tigerweb_transportation",
            plans = plans.censusRoads,
            cacheMode = cacheMode,
            events = events,
            parser = ProviderResponseParser::parseCensusRoads
        )

        evidence += executeOsm(
            request = request,
            policy = policy,
            areaPlan = plans.osmAreaLookup,
            cacheMode = cacheMode,
            events = events
        )

        plans.oaklandSiteAddresses?.let { sitePlan ->
            val siteEvidenceAndPins = executeSiteAddresses(request, sitePlan, cacheMode, events)
            evidence += siteEvidenceAndPins.first

            if (request.buildingOutlineCrosscheckRequired) {
                val matchedPins = siteEvidenceAndPins.second
                if (matchedPins == null || siteEvidenceAndPins.first.siteAddressCrosscheckPassed != true) {
                    evidence += unavailableBuildingEvidence(request, "SITE_ADDRESS_DEPENDENCY_FAILED")
                    events += dependencySkipped(
                        providerId = "oakland_county_buildings",
                        stage = ProviderQueryStage.BUILDING_OUTLINE,
                        code = "SITE_ADDRESS_DEPENDENCY_FAILED"
                    )
                    events += dependencySkipped(
                        providerId = "oakland_county_buildings",
                        stage = ProviderQueryStage.BUILDING_METADATA,
                        code = "SITE_ADDRESS_DEPENDENCY_FAILED"
                    )
                } else {
                    evidence += executeBuildings(request, policy, matchedPins, cacheMode, events)
                }
            }
        }

        val decision = LiveGeometryVerificationReconciler.reconcile(request, policy, evidence)
        return LiveVerificationExecutionResult(
            requestFingerprint = request.requestFingerprint,
            evidence = evidence.toList(),
            decision = decision,
            events = events.toList()
        )
    }

    private fun executeRoadProvider(
        request: LiveGeometryVerificationRequest,
        providerId: String,
        plans: List<ProviderQueryPlan>,
        cacheMode: ProviderCacheMode,
        events: MutableList<VerificationPipelineEvent>,
        parser: (List<ProviderRawResponse>) -> ProviderRoadParseResult
    ): ProviderVerificationEvidence {
        require(plans.isNotEmpty()) { "$providerId road execution needs at least one plan" }
        require(plans.all { it.providerId == providerId && it.stage == ProviderQueryStage.ROAD_GEOMETRY })
        val raws = mutableListOf<ProviderRawResponse>()
        for (plan in plans) {
            when (val execution = executeSingle(plan, cacheMode, events)) {
                is StageExecution.Success -> raws += execution.response
                is StageExecution.Failure -> return if (raws.isEmpty()) {
                    unavailableRoadEvidence(request, providerId, execution.errorCode)
                } else {
                    unavailableRoadEvidenceFromRaw(request, providerId, raws, execution.errorCode)
                }
            }
        }
        val compositePlan = compositePlanFingerprint(plans)
        return try {
            val parsed = parser(raws)
            val assembled = ProviderEvidenceAssembler.roadEvidence(request, parsed, oldestObservation(raws))
            events += parseSucceeded(
                providerId = providerId,
                stage = ProviderQueryStage.ROAD_GEOMETRY,
                bindingFingerprint = compositePlan,
                responseSha256 = compositeResponseDigest(raws),
                bindingKind = if (plans.size == 1) VerificationPipelineBindingKind.PLAN else VerificationPipelineBindingKind.COMPOSITE_PLANS
            )
            assembled
        } catch (failure: RuntimeException) {
            val code = failureCode(failure)
            events += parseFailed(
                providerId = providerId,
                stage = ProviderQueryStage.ROAD_GEOMETRY,
                bindingFingerprint = compositePlan,
                code = code,
                bindingKind = if (plans.size == 1) VerificationPipelineBindingKind.PLAN else VerificationPipelineBindingKind.COMPOSITE_PLANS
            )
            unavailableRoadEvidenceFromRaw(request, providerId, raws, code)
        }
    }

    private fun executeOsm(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy,
        areaPlan: ProviderQueryPlan,
        cacheMode: ProviderCacheMode,
        events: MutableList<VerificationPipelineEvent>
    ): ProviderVerificationEvidence {
        val areaExecution = executeSingle(areaPlan, cacheMode, events)
        if (areaExecution is StageExecution.Failure) {
            events += dependencySkipped("openstreetmap_overpass", ProviderQueryStage.OSM_ROADS, "OSM_AREA_DEPENDENCY_FAILED")
            return unavailableRoadEvidence(request, "openstreetmap_overpass", areaExecution.errorCode)
        }
        val areaRaw = (areaExecution as StageExecution.Success).response
        val area = try {
            ProviderResponseParser.parseOsmArea(areaRaw, request.jurisdiction).also {
                events += parseSucceeded(
                    providerId = "openstreetmap_overpass",
                    stage = ProviderQueryStage.OSM_AREA_LOOKUP,
                    bindingFingerprint = areaPlan.planFingerprint,
                    responseSha256 = areaRaw.responseSha256
                )
            }
        } catch (failure: RuntimeException) {
            events += parseFailed(
                providerId = "openstreetmap_overpass",
                stage = ProviderQueryStage.OSM_AREA_LOOKUP,
                bindingFingerprint = areaPlan.planFingerprint,
                code = failureCode(failure)
            )
            events += dependencySkipped("openstreetmap_overpass", ProviderQueryStage.OSM_ROADS, "OSM_AREA_DEPENDENCY_FAILED")
            return unavailableRoadEvidenceFromRaw(request, "openstreetmap_overpass", listOf(areaRaw), "OSM_AREA_PARSE_FAILED")
        }

        val roadPlan = try {
            ProviderQueryPlanner.osmRoadPlan(request, policy, area)
        } catch (failure: RuntimeException) {
            events += parseFailed(
                providerId = "openstreetmap_overpass",
                stage = ProviderQueryStage.OSM_ROADS,
                bindingFingerprint = areaPlan.planFingerprint,
                code = failureCode(failure)
            )
            return unavailableRoadEvidenceFromRaw(request, "openstreetmap_overpass", listOf(areaRaw), "OSM_ROAD_PLAN_FAILED")
        }
        val roadExecution = executeSingle(roadPlan, cacheMode, events)
        if (roadExecution is StageExecution.Failure) {
            return unavailableRoadEvidenceFromRaw(request, "openstreetmap_overpass", listOf(areaRaw), roadExecution.errorCode)
        }
        val roadRaw = (roadExecution as StageExecution.Success).response
        return try {
            val parsed = ProviderResponseParser.parseOsmRoads(areaRaw, roadRaw)
            val assembled = ProviderEvidenceAssembler.roadEvidence(request, parsed, oldestObservation(listOf(areaRaw, roadRaw)))
            events += parseSucceeded(
                providerId = "openstreetmap_overpass",
                stage = ProviderQueryStage.OSM_ROADS,
                bindingFingerprint = roadPlan.planFingerprint,
                responseSha256 = parsed.compositeResponseSha256
            )
            assembled
        } catch (failure: RuntimeException) {
            val code = failureCode(failure)
            events += parseFailed("openstreetmap_overpass", ProviderQueryStage.OSM_ROADS, roadPlan.planFingerprint, code)
            unavailableRoadEvidenceFromRaw(request, "openstreetmap_overpass", listOf(areaRaw, roadRaw), "OSM_ROAD_PARSE_FAILED")
        }
    }

    private fun executeSiteAddresses(
        request: LiveGeometryVerificationRequest,
        plan: ProviderQueryPlan,
        cacheMode: ProviderCacheMode,
        events: MutableList<VerificationPipelineEvent>
    ): Pair<ProviderVerificationEvidence, MatchedSiteAddressPins?> {
        val execution = executeSingle(plan, cacheMode, events)
        if (execution is StageExecution.Failure) return unavailableSiteEvidence(request, execution.errorCode) to null
        val raw = (execution as StageExecution.Success).response
        return try {
            val parsed = ProviderResponseParser.parseSiteAddresses(raw)
            val assembled = ProviderEvidenceAssembler.siteAddressEvidence(request, parsed, raw.observedAtUtc)
            events += parseSucceeded("oakland_county_site_addresses", ProviderQueryStage.SITE_ADDRESS, plan.planFingerprint, raw.responseSha256)
            assembled
        } catch (failure: RuntimeException) {
            val code = failureCode(failure)
            events += parseFailed("oakland_county_site_addresses", ProviderQueryStage.SITE_ADDRESS, plan.planFingerprint, code)
            unavailableSiteEvidenceFromRaw(raw, code) to null
        }
    }

    private fun executeBuildings(
        request: LiveGeometryVerificationRequest,
        policy: OnlineSourcePolicy,
        matchedPins: MatchedSiteAddressPins,
        cacheMode: ProviderCacheMode,
        events: MutableList<VerificationPipelineEvent>
    ): ProviderVerificationEvidence {
        val plans = try {
            ProviderQueryPlanner.oaklandBuildingPlans(request, policy, matchedPins)
        } catch (failure: RuntimeException) {
            val code = failureCode(failure)
            events += parseFailed("oakland_county_buildings", ProviderQueryStage.BUILDING_OUTLINE, null, code)
            return unavailableBuildingEvidence(request, "BUILDING_PLAN_FAILED")
        }
        val outlineExecution = executeSingle(plans.first, cacheMode, events)
        if (outlineExecution is StageExecution.Failure) {
            events += dependencySkipped("oakland_county_buildings", ProviderQueryStage.BUILDING_METADATA, "BUILDING_OUTLINE_DEPENDENCY_FAILED")
            return unavailableBuildingEvidence(request, outlineExecution.errorCode)
        }
        val outlineRaw = (outlineExecution as StageExecution.Success).response
        val metadataExecution = executeSingle(plans.second, cacheMode, events)
        if (metadataExecution is StageExecution.Failure) {
            return unavailableBuildingEvidenceFromRaw(request, listOf(outlineRaw), metadataExecution.errorCode)
        }
        val metadataRaw = (metadataExecution as StageExecution.Success).response
        return try {
            val outline = ProviderResponseParser.parseBuildingOutlines(outlineRaw)
            val metadata = ProviderResponseParser.parseBuildingMetadata(metadataRaw)
            val assembled = ProviderEvidenceAssembler.buildingOutlineEvidence(
                request = request,
                parseResult = outline,
                metadata = metadata,
                requiredPins = matchedPins,
                observedAtUtc = oldestObservation(listOf(outlineRaw, metadataRaw))
            )
            events += parseSucceeded(
                providerId = "oakland_county_buildings",
                stage = ProviderQueryStage.BUILDING_OUTLINE,
                bindingFingerprint = compositePlanFingerprint(listOf(plans.first, plans.second)),
                responseSha256 = requireNotNull(assembled.responseSha256),
                bindingKind = VerificationPipelineBindingKind.COMPOSITE_PLANS
            )
            assembled
        } catch (failure: RuntimeException) {
            val code = failureCode(failure)
            events += parseFailed(
                providerId = "oakland_county_buildings",
                stage = ProviderQueryStage.BUILDING_OUTLINE,
                bindingFingerprint = compositePlanFingerprint(listOf(plans.first, plans.second)),
                code = code,
                bindingKind = VerificationPipelineBindingKind.COMPOSITE_PLANS
            )
            unavailableBuildingEvidenceFromRaw(request, listOf(outlineRaw, metadataRaw), "BUILDING_PARSE_FAILED")
        }
    }

    private fun executeSingle(
        plan: ProviderQueryPlan,
        cacheMode: ProviderCacheMode,
        events: MutableList<VerificationPipelineEvent>
    ): StageExecution = try {
        val raw = coordinator.execute(plan, cacheMode)
        events += VerificationPipelineEvent(
            providerId = plan.providerId,
            stage = plan.stage,
            phase = VerificationPipelineEventPhase.EXECUTION,
            bindingKind = VerificationPipelineBindingKind.PLAN,
            bindingFingerprint = plan.planFingerprint,
            outcome = VerificationPipelineStageOutcome.SUCCEEDED,
            responseSha256 = raw.responseSha256,
            errorCode = null
        )
        StageExecution.Success(raw)
    } catch (failure: IOException) {
        val code = failureCode(failure)
        events += executionFailed(plan, code)
        StageExecution.Failure(code)
    }

    private fun unavailableRoadEvidence(
        request: LiveGeometryVerificationRequest,
        providerId: String,
        errorCode: String
    ): ProviderVerificationEvidence = ProviderVerificationEvidence(
        providerId = providerId,
        requestFingerprint = request.requestFingerprint,
        available = false,
        observedAtUtc = null,
        responseSha256 = null,
        sourceDataVintage = null,
        queriedTargetIds = request.roadTargets.mapTo(linkedSetOf()) { it.targetId },
        confirmedTargetIds = emptySet(),
        notFoundTargetIds = emptySet(),
        conflictingTargetIds = emptySet(),
        unknownMeaningChangingRoads = emptySet(),
        siteAddressCrosscheckPassed = null,
        buildingOutlineCrosscheckPassed = null,
        errorCode = errorCode
    )

    private fun unavailableRoadEvidenceFromRaw(
        request: LiveGeometryVerificationRequest,
        providerId: String,
        raws: List<ProviderRawResponse>,
        errorCode: String
    ): ProviderVerificationEvidence {
        require(raws.isNotEmpty())
        require(raws.all { it.plan.requestFingerprint == request.requestFingerprint })
        return ProviderVerificationEvidence(
            providerId = providerId,
            requestFingerprint = request.requestFingerprint,
            available = false,
            observedAtUtc = oldestObservation(raws),
            responseSha256 = compositeResponseDigest(raws),
            sourceDataVintage = null,
            queriedTargetIds = request.roadTargets.mapTo(linkedSetOf()) { it.targetId },
            confirmedTargetIds = emptySet(),
            notFoundTargetIds = emptySet(),
            conflictingTargetIds = emptySet(),
            unknownMeaningChangingRoads = emptySet(),
            siteAddressCrosscheckPassed = null,
            buildingOutlineCrosscheckPassed = null,
            errorCode = errorCode
        )
    }

    private fun unavailableSiteEvidence(request: LiveGeometryVerificationRequest, errorCode: String): ProviderVerificationEvidence =
        ProviderVerificationEvidence(
            providerId = "oakland_county_site_addresses",
            requestFingerprint = request.requestFingerprint,
            available = false,
            observedAtUtc = null,
            responseSha256 = null,
            sourceDataVintage = null,
            queriedTargetIds = emptySet(),
            confirmedTargetIds = emptySet(),
            notFoundTargetIds = emptySet(),
            conflictingTargetIds = emptySet(),
            unknownMeaningChangingRoads = emptySet(),
            siteAddressCrosscheckPassed = null,
            buildingOutlineCrosscheckPassed = null,
            errorCode = errorCode
        )

    private fun unavailableSiteEvidenceFromRaw(raw: ProviderRawResponse, errorCode: String): ProviderVerificationEvidence =
        ProviderVerificationEvidence(
            providerId = "oakland_county_site_addresses",
            requestFingerprint = raw.plan.requestFingerprint,
            available = false,
            observedAtUtc = raw.observedAtUtc,
            responseSha256 = raw.responseSha256,
            sourceDataVintage = null,
            queriedTargetIds = emptySet(),
            confirmedTargetIds = emptySet(),
            notFoundTargetIds = emptySet(),
            conflictingTargetIds = emptySet(),
            unknownMeaningChangingRoads = emptySet(),
            siteAddressCrosscheckPassed = null,
            buildingOutlineCrosscheckPassed = null,
            errorCode = errorCode
        )

    private fun unavailableBuildingEvidence(request: LiveGeometryVerificationRequest, errorCode: String): ProviderVerificationEvidence =
        ProviderVerificationEvidence(
            providerId = "oakland_county_buildings",
            requestFingerprint = request.requestFingerprint,
            available = false,
            observedAtUtc = null,
            responseSha256 = null,
            sourceDataVintage = null,
            queriedTargetIds = emptySet(),
            confirmedTargetIds = emptySet(),
            notFoundTargetIds = emptySet(),
            conflictingTargetIds = emptySet(),
            unknownMeaningChangingRoads = emptySet(),
            siteAddressCrosscheckPassed = null,
            buildingOutlineCrosscheckPassed = null,
            errorCode = errorCode
        )

    private fun unavailableBuildingEvidenceFromRaw(
        request: LiveGeometryVerificationRequest,
        raws: List<ProviderRawResponse>,
        errorCode: String
    ): ProviderVerificationEvidence = ProviderVerificationEvidence(
        providerId = "oakland_county_buildings",
        requestFingerprint = request.requestFingerprint,
        available = false,
        observedAtUtc = oldestObservation(raws),
        responseSha256 = compositeResponseDigest(raws),
        sourceDataVintage = null,
        queriedTargetIds = emptySet(),
        confirmedTargetIds = emptySet(),
        notFoundTargetIds = emptySet(),
        conflictingTargetIds = emptySet(),
        unknownMeaningChangingRoads = emptySet(),
        siteAddressCrosscheckPassed = null,
        buildingOutlineCrosscheckPassed = null,
        errorCode = errorCode
    )

    private fun oldestObservation(raws: List<ProviderRawResponse>): String = raws
        .map { Instant.parse(it.observedAtUtc) }
        .minOrNull()
        .let(::requireNotNull)
        .toString()

    private fun compositePlanFingerprint(plans: List<ProviderQueryPlan>): String = pipelineSha256(
        plans.sortedBy { it.resourceId }.joinToString("\n") { it.planFingerprint }
    )

    private fun compositeResponseDigest(raws: List<ProviderRawResponse>): String = pipelineSha256(
        raws.sortedBy { it.plan.resourceId }.joinToString("\n") { it.responseSha256 }
    )

    private fun failureCode(failure: Throwable): String = when (failure) {
        is ProviderHttpStatusException -> "HTTP_${failure.statusCode}"
        is ProviderResponseTooLargeException -> "RESPONSE_TOO_LARGE"
        is ProviderCacheIntegrityException -> "CACHE_INTEGRITY_FAILURE"
        is ProviderExecutionExhaustedException -> "EXECUTION_EXHAUSTED"
        is IOException -> "IO_FAILURE"
        is IllegalArgumentException, is IllegalStateException -> "RESPONSE_PARSE_OR_BINDING_FAILURE"
        else -> "PROVIDER_STAGE_FAILURE"
    }

    private fun executionFailed(plan: ProviderQueryPlan, code: String): VerificationPipelineEvent = VerificationPipelineEvent(
        providerId = plan.providerId,
        stage = plan.stage,
        phase = VerificationPipelineEventPhase.EXECUTION,
        bindingKind = VerificationPipelineBindingKind.PLAN,
        bindingFingerprint = plan.planFingerprint,
        outcome = VerificationPipelineStageOutcome.FAILED,
        responseSha256 = null,
        errorCode = code
    )

    private fun parseSucceeded(
        providerId: String,
        stage: ProviderQueryStage,
        bindingFingerprint: String,
        responseSha256: String,
        bindingKind: VerificationPipelineBindingKind = VerificationPipelineBindingKind.PLAN
    ): VerificationPipelineEvent = VerificationPipelineEvent(
        providerId = providerId,
        stage = stage,
        phase = VerificationPipelineEventPhase.PARSE_ASSEMBLY,
        bindingKind = bindingKind,
        bindingFingerprint = bindingFingerprint,
        outcome = VerificationPipelineStageOutcome.SUCCEEDED,
        responseSha256 = responseSha256,
        errorCode = null
    )

    private fun parseFailed(
        providerId: String,
        stage: ProviderQueryStage,
        bindingFingerprint: String?,
        code: String,
        bindingKind: VerificationPipelineBindingKind = if (bindingFingerprint == null) VerificationPipelineBindingKind.NONE else VerificationPipelineBindingKind.PLAN
    ): VerificationPipelineEvent = VerificationPipelineEvent(
        providerId = providerId,
        stage = stage,
        phase = VerificationPipelineEventPhase.PARSE_ASSEMBLY,
        bindingKind = bindingKind,
        bindingFingerprint = bindingFingerprint,
        outcome = VerificationPipelineStageOutcome.FAILED,
        responseSha256 = null,
        errorCode = code
    )

    private fun dependencySkipped(
        providerId: String,
        stage: ProviderQueryStage,
        code: String
    ): VerificationPipelineEvent = VerificationPipelineEvent(
        providerId = providerId,
        stage = stage,
        phase = VerificationPipelineEventPhase.DEPENDENCY,
        bindingKind = VerificationPipelineBindingKind.NONE,
        bindingFingerprint = null,
        outcome = VerificationPipelineStageOutcome.SKIPPED_DEPENDENCY,
        responseSha256 = null,
        errorCode = code
    )

    private sealed interface StageExecution {
        data class Success(val response: ProviderRawResponse) : StageExecution
        data class Failure(val errorCode: String) : StageExecution
    }
}

private val PIPELINE_SHA256_HEX = Regex("^[0-9a-f]{64}$")

private fun pipelineSha256(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray(Charsets.UTF_8))
    .joinToString("") { "%02x".format(it) }
