package com.koenterprises.territorycardstudio.core

enum class ReleaseDisposition {
    APPROVED_REFERENCE,
    CANDIDATE_UNAPPROVED
}

data class ReleasePolicyResult(
    val disposition: ReleaseDisposition,
    val fieldReleaseAllowed: Boolean,
    val reason: String
)

object ReleasePolicy {
    fun evaluate(status: AssignmentStatus): ReleasePolicyResult =
        if (status.needsNewCard) {
            ReleasePolicyResult(
                disposition = ReleaseDisposition.CANDIDATE_UNAPPROVED,
                fieldReleaseAllowed = false,
                reason = "needs_new_card requires explicit human approval of the generated candidate"
            )
        } else {
            ReleasePolicyResult(
                disposition = ReleaseDisposition.APPROVED_REFERENCE,
                fieldReleaseAllowed = true,
                reason = "current reference assignment; downstream release gates still apply"
            )
        }
}
