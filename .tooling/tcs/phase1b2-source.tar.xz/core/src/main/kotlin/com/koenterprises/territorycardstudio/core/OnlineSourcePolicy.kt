package com.koenterprises.territorycardstudio.core

import java.io.Reader

private const val LIVE_POLICY_REVISION = "2026-09-24-live-verification-v1"

enum class OnlineProviderCapability {
    ROAD_GEOMETRY_AUTHORITY,
    SITE_ADDRESS_CROSSCHECK,
    BUILDING_OUTLINE_CROSSCHECK,
    OPTIONAL_COMMERCIAL_CROSSCHECK
}

data class OnlineReleasePolicy(
    val defaultAppMode: String,
    val minimumIndependentGeometrySources: Int,
    val oaklandCountyPrimaryWhenApplicable: Boolean,
    val googleIsCrosscheckNotGeometryAuthority: Boolean,
    val googleMapTilesScrapingOrMachineExtraction: Boolean,
    val sourceDisagreementBehavior: String,
    val providerUnavailableBehaviorWhenRequired: String
)

data class OnlineProviderConfig(
    val id: String,
    val tier: Int,
    val role: String,
    val capability: OnlineProviderCapability,
    val primaryEndpoint: String,
    val secondaryEndpoint: String?,
    val docsEndpoint: String?,
    val layers: List<Int>,
    val requiresApiKey: Boolean
) {
    init {
        require(tier in 1..3) { "$id has unsupported provider tier $tier" }
        require(primaryEndpoint.startsWith("https://")) { "$id must use HTTPS" }
        secondaryEndpoint?.let { require(it.startsWith("https://")) { "$id secondary endpoint must use HTTPS" } }
        docsEndpoint?.let { require(it.startsWith("https://")) { "$id docs endpoint must use HTTPS" } }
    }
}

data class OnlineSourcePolicy(
    val schemaVersion: Int,
    val revision: String,
    val principle: String,
    val releasePolicy: OnlineReleasePolicy,
    val providers: Map<String, OnlineProviderConfig>
) {
    init {
        require(schemaVersion == 1) { "Unsupported online-source policy schema $schemaVersion" }
        require(revision == LIVE_POLICY_REVISION) { "Unsupported online-source policy revision $revision" }
        require(principle.contains("never define congregation work assignment colors or boundaries")) {
            "Online-source principle no longer protects assignment authority"
        }
        require(releasePolicy.defaultAppMode == "required") { "Live verification must remain required by default" }
        require(releasePolicy.minimumIndependentGeometrySources == 2) { "Independent geometry-source minimum drift" }
        require(releasePolicy.oaklandCountyPrimaryWhenApplicable) { "Oakland County primary-source requirement disabled" }
        require(releasePolicy.googleIsCrosscheckNotGeometryAuthority) { "Google cannot become geometry authority" }
        require(!releasePolicy.googleMapTilesScrapingOrMachineExtraction) { "Google tile scraping/extraction must remain disabled" }
        require(releasePolicy.sourceDisagreementBehavior == "BLOCK") { "Source disagreements must BLOCK" }
        require(releasePolicy.providerUnavailableBehaviorWhenRequired == "BLOCK") { "Required provider unavailability must BLOCK" }

        val expectedIds = setOf(
            "oakland_county_roads",
            "oakland_county_site_addresses",
            "oakland_county_buildings",
            "census_tigerweb_transportation",
            "openstreetmap_overpass",
            "google_geocoding",
            "google_roads"
        )
        require(providers.keys == expectedIds) { "Online provider set drift: ${providers.keys}" }
        require(providers.getValue("oakland_county_roads").tier == 1)
        require(providers.getValue("oakland_county_roads").capability == OnlineProviderCapability.ROAD_GEOMETRY_AUTHORITY)
        require(providers.getValue("census_tigerweb_transportation").tier == 2)
        require(providers.getValue("census_tigerweb_transportation").capability == OnlineProviderCapability.ROAD_GEOMETRY_AUTHORITY)
        require(providers.getValue("openstreetmap_overpass").tier == 2)
        require(providers.getValue("openstreetmap_overpass").capability == OnlineProviderCapability.ROAD_GEOMETRY_AUTHORITY)
        require(providers.getValue("oakland_county_site_addresses").capability == OnlineProviderCapability.SITE_ADDRESS_CROSSCHECK)
        require(providers.getValue("oakland_county_buildings").capability == OnlineProviderCapability.BUILDING_OUTLINE_CROSSCHECK)
        listOf("google_geocoding", "google_roads").forEach { id ->
            require(providers.getValue(id).tier == 3)
            require(providers.getValue(id).capability == OnlineProviderCapability.OPTIONAL_COMMERCIAL_CROSSCHECK)
        }
    }
}

object OnlineSourcePolicyLoader {
    private val rootKeys = setOf("schema_version", "revision", "principle", "release_policy", "providers")
    private val releaseKeys = setOf(
        "default_app_mode",
        "minimum_independent_geometry_sources",
        "oakland_county_primary_when_applicable",
        "google_is_crosscheck_not_geometry_authority",
        "google_map_tiles_scraping_or_machine_extraction",
        "source_disagreement_behavior",
        "provider_unavailable_behavior_when_required"
    )

    fun load(reader: Reader): OnlineSourcePolicy {
        val root = StrictJson.parse(reader).obj("online_source_policy")
        require(root.keys == rootKeys) { "Online-source root schema drift: ${root.keys}" }
        val release = root.required("release_policy", "online_source_policy").obj("release_policy")
        require(release.keys == releaseKeys) { "Online release-policy schema drift: ${release.keys}" }
        val providersObject = root.required("providers", "online_source_policy").obj("providers")

        return OnlineSourcePolicy(
            schemaVersion = root.required("schema_version", "online_source_policy").int("schema_version"),
            revision = root.required("revision", "online_source_policy").string("revision"),
            principle = root.required("principle", "online_source_policy").string("principle"),
            releasePolicy = OnlineReleasePolicy(
                defaultAppMode = release.required("default_app_mode", "release_policy").string("default_app_mode"),
                minimumIndependentGeometrySources = release.required("minimum_independent_geometry_sources", "release_policy").int("minimum_independent_geometry_sources"),
                oaklandCountyPrimaryWhenApplicable = release.required("oakland_county_primary_when_applicable", "release_policy").bool("oakland_county_primary_when_applicable"),
                googleIsCrosscheckNotGeometryAuthority = release.required("google_is_crosscheck_not_geometry_authority", "release_policy").bool("google_is_crosscheck_not_geometry_authority"),
                googleMapTilesScrapingOrMachineExtraction = release.required("google_map_tiles_scraping_or_machine_extraction", "release_policy").bool("google_map_tiles_scraping_or_machine_extraction"),
                sourceDisagreementBehavior = release.required("source_disagreement_behavior", "release_policy").string("source_disagreement_behavior"),
                providerUnavailableBehaviorWhenRequired = release.required("provider_unavailable_behavior_when_required", "release_policy").string("provider_unavailable_behavior_when_required")
            ),
            providers = providersObject.mapValues { (id, value) -> provider(id, value) }
        )
    }

    private fun provider(id: String, value: JsonValue): OnlineProviderConfig {
        val o = value.obj("providers.$id")
        val tier = o.required("tier", "providers.$id").int("providers.$id.tier")
        val role = o.required("role", "providers.$id").string("providers.$id.role")
        return when (id) {
            "oakland_county_roads" -> {
                require(o.keys == setOf("tier", "role", "layer", "docs")) { "$id schema drift: ${o.keys}" }
                OnlineProviderConfig(
                    id = id,
                    tier = tier,
                    role = role,
                    capability = OnlineProviderCapability.ROAD_GEOMETRY_AUTHORITY,
                    primaryEndpoint = o.required("layer", id).string("$id.layer"),
                    secondaryEndpoint = null,
                    docsEndpoint = o.required("docs", id).string("$id.docs"),
                    layers = emptyList(),
                    requiresApiKey = false
                )
            }
            "oakland_county_site_addresses" -> {
                require(o.keys == setOf("tier", "role", "layer", "docs")) { "$id schema drift: ${o.keys}" }
                OnlineProviderConfig(
                    id = id,
                    tier = tier,
                    role = role,
                    capability = OnlineProviderCapability.SITE_ADDRESS_CROSSCHECK,
                    primaryEndpoint = o.required("layer", id).string("$id.layer"),
                    secondaryEndpoint = null,
                    docsEndpoint = o.required("docs", id).string("$id.docs"),
                    layers = emptyList(),
                    requiresApiKey = false
                )
            }
            "oakland_county_buildings" -> {
                require(o.keys == setOf("tier", "role", "layer", "docs")) { "$id schema drift: ${o.keys}" }
                OnlineProviderConfig(
                    id = id,
                    tier = tier,
                    role = role,
                    capability = OnlineProviderCapability.BUILDING_OUTLINE_CROSSCHECK,
                    primaryEndpoint = o.required("layer", id).string("$id.layer"),
                    secondaryEndpoint = null,
                    docsEndpoint = o.required("docs", id).string("$id.docs"),
                    layers = emptyList(),
                    requiresApiKey = false
                )
            }
            "census_tigerweb_transportation" -> {
                require(o.keys == setOf("tier", "role", "layers", "service", "docs")) { "$id schema drift: ${o.keys}" }
                val layers = o.required("layers", id).arr("$id.layers").mapIndexed { index, layer -> layer.int("$id.layers[$index]") }
                require(layers == listOf(2, 6, 8)) { "$id layer set drift: $layers" }
                OnlineProviderConfig(
                    id = id,
                    tier = tier,
                    role = role,
                    capability = OnlineProviderCapability.ROAD_GEOMETRY_AUTHORITY,
                    primaryEndpoint = o.required("service", id).string("$id.service"),
                    secondaryEndpoint = null,
                    docsEndpoint = o.required("docs", id).string("$id.docs"),
                    layers = layers,
                    requiresApiKey = false
                )
            }
            "openstreetmap_overpass" -> {
                require(o.keys == setOf("tier", "role", "overpass", "nominatim")) { "$id schema drift: ${o.keys}" }
                OnlineProviderConfig(
                    id = id,
                    tier = tier,
                    role = role,
                    capability = OnlineProviderCapability.ROAD_GEOMETRY_AUTHORITY,
                    primaryEndpoint = o.required("overpass", id).string("$id.overpass"),
                    secondaryEndpoint = o.required("nominatim", id).string("$id.nominatim"),
                    docsEndpoint = null,
                    layers = emptyList(),
                    requiresApiKey = false
                )
            }
            "google_geocoding", "google_roads" -> {
                require(o.keys == setOf("tier", "role", "endpoint", "docs")) { "$id schema drift: ${o.keys}" }
                OnlineProviderConfig(
                    id = id,
                    tier = tier,
                    role = role,
                    capability = OnlineProviderCapability.OPTIONAL_COMMERCIAL_CROSSCHECK,
                    primaryEndpoint = o.required("endpoint", id).string("$id.endpoint"),
                    secondaryEndpoint = null,
                    docsEndpoint = o.required("docs", id).string("$id.docs"),
                    layers = emptyList(),
                    requiresApiKey = true
                )
            }
            else -> error("Unsupported online provider $id")
        }
    }
}
