package com.koenterprises.territorycardstudio.core

import java.io.Reader

/** Byte-locked provenance for the shared desktop/new-output renderer authority. */
object LockedPdfRendererAuthorityHashes {
    const val STYLE_TOKENS_SHA256 = "ced211f7df0d2dafffb6d05bde4640a8bd2c1b0a44719b986a57c11a65d792fe"
    const val TEMPLATE_PDF_SHA256 = "9de0e819a0301b6d6b7dfdce8851e94839d4de2b72f5e3f2ca55d27579973ee4"
    const val RENDERER_SHA256 = "8a79a906b0c2b80d3346283ddb9c83211f2c7a628674504d13a71dee155bc70a"
    const val DIRECTIONS_BADGE_SHA256 = "34c61891dcfd6d5c7a45cf0acbbead99184d5141f8578860a688880d715d636d"
    const val CONTRACT_SHA256 = "f337f59fd235347d2d04431c664101273bc83e43ca7713ef20016827a7da0bc7"
}


object LockedPdfFinalValidatorAuthorityHashes {
    const val STYLE_TOKEN_VALIDATOR_SHA256 = "f65bad6f9cf2f2b6f7765a2e092c073a7e23c606f28df25d6fa0b072651b8184"
    const val PDF_IDENTITY_VALIDATOR_SHA256 = "1e7faa125511cf937bef4eaa183388aa12e7b58a61bc6bd0a772d6f95ad69aa3"
    const val TERRITORY_IDENTITY_VALIDATOR_SHA256 = "d80fbba2e0fc6bbe3ab947ee1a092d517e4952f6bfcb0478271cff3961ed7c9b"
    const val TERRITORY_IDENTITY_HELPER_SHA256 = "4b61a1806574b9007fd3ab9602c46c4984892b435da43622411743948925fba8"
    const val LABEL_METRIC_VALIDATOR_SHA256 = "510a028e53a42ecac376cb32995981caed7f9909d565d22f69804d7b7596d0c1"
    const val LABEL_NAVIGATION_VALIDATOR_SHA256 = "38c2205b16b7e4e858a7027d0ad0495c50531f3d182b2a46fc230ed488f8ea4f"
    const val VISUAL_HARD_OVERRIDE_VALIDATOR_SHA256 = "65b2c640e8f3344ee2d71af14beba5a5b7bf02e36f9aedf9b28edcb61c8bc920"
}

data class LockedPdfRendererContract(
    val widthPt: Double,
    val heightPt: Double,
    val orientation: String,
    val pages: Int,
    val mapContentRect: List<Double>,
    val layoutModes: Set<String>,
    val noShellReconstruction: Boolean,
    val noSidebarVariants: Boolean,
    val noPanelGeometryVariants: Boolean,
    val noFontSubstitution: Boolean,
    val noConsumerMapBackground: Boolean,
    val a33CarBadgeRequired: Boolean,
    val styleTokenProvenanceRequired: Boolean,
    val directionsBadgeAsset: String
) {
    init {
        require(widthPt == 768.0) { "Locked PDF width drift: $widthPt" }
        require(heightPt == 480.5) { "Locked PDF height drift: $heightPt" }
        require(orientation == "landscape") { "Locked PDF orientation drift: $orientation" }
        require(pages == 1) { "Territory card front must remain one PDF page" }
        require(mapContentRect == listOf(176.0, 20.0, 571.0, 343.0)) { "Locked map panel geometry drift" }
        require(layoutModes == setOf("full_map", "split_detail", "full_plus_detail", "site_building_assignment")) {
            "Unsupported/changed PDF layout modes: $layoutModes"
        }
        require(noShellReconstruction) { "Shell reconstruction must remain forbidden" }
        require(noSidebarVariants) { "Unapproved sidebar variants must remain forbidden" }
        require(noPanelGeometryVariants) { "Unapproved panel geometry variants must remain forbidden" }
        require(noFontSubstitution) { "Font substitution must remain forbidden" }
        require(noConsumerMapBackground) { "Consumer map backgrounds must remain forbidden" }
        require(a33CarBadgeRequired) { "Locked A33 directions badge must remain required" }
        require(styleTokenProvenanceRequired) { "Style-token provenance must remain required" }
        require(directionsBadgeAsset == "assets/a33-directions-car.png") { "Directions badge authority drift" }
    }
}

object LockedPdfRendererContractLoader {
    fun load(reader: Reader): LockedPdfRendererContract {
        val root = StrictJson.parse(reader).obj("R48 style tokens")
        val page = root.required("page", "R48 style tokens").obj("page")
        val map = root.required("map_content", "R48 style tokens").obj("map_content")
        val layouts = root.required("layout_modes", "R48 style tokens").obj("layout_modes")
        val locked = root.required("locked_new_output", "R48 style tokens").obj("locked_new_output")
        val directions = root.required("directions", "R48 style tokens").obj("directions")

        return LockedPdfRendererContract(
            widthPt = page.required("width_pt", "page").double("page.width_pt"),
            heightPt = page.required("height_pt", "page").double("page.height_pt"),
            orientation = page.required("orientation", "page").string("page.orientation"),
            pages = page.required("pages", "page").int("page.pages"),
            mapContentRect = listOf(
                map.required("x", "map_content").double("map_content.x"),
                map.required("y", "map_content").double("map_content.y"),
                map.required("w", "map_content").double("map_content.w"),
                map.required("h", "map_content").double("map_content.h")
            ),
            layoutModes = layouts.keys,
            noShellReconstruction = locked.required("no_shell_reconstruction", "locked_new_output")
                .bool("locked_new_output.no_shell_reconstruction"),
            noSidebarVariants = locked.required("no_sidebar_variants", "locked_new_output")
                .bool("locked_new_output.no_sidebar_variants"),
            noPanelGeometryVariants = locked.required("no_panel_geometry_variants", "locked_new_output")
                .bool("locked_new_output.no_panel_geometry_variants"),
            noFontSubstitution = locked.required("no_font_substitution", "locked_new_output")
                .bool("locked_new_output.no_font_substitution"),
            noConsumerMapBackground = locked.required("no_consumer_map_background", "locked_new_output")
                .bool("locked_new_output.no_consumer_map_background"),
            a33CarBadgeRequired = locked.required("a33_car_badge_required", "locked_new_output")
                .bool("locked_new_output.a33_car_badge_required"),
            styleTokenProvenanceRequired = locked.required("style_token_provenance_required", "locked_new_output")
                .bool("locked_new_output.style_token_provenance_required"),
            directionsBadgeAsset = directions.required("car_badge_asset", "directions")
                .string("directions.car_badge_asset")
        )
    }
}
