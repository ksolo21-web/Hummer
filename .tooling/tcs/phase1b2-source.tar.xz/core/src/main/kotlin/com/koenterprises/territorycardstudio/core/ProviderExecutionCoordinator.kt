package com.koenterprises.territorycardstudio.core

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.time.Clock
import java.time.Duration
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import javax.net.ssl.HttpsURLConnection
import kotlin.math.max
import kotlin.math.min

private const val PROVIDER_EXECUTION_POLICY_REVISION = "2026-09-25-provider-execution-v1"
private val EXECUTION_SHA256_HEX = Regex("^[0-9a-f]{64}$")

enum class ProviderCacheMode {
    READ_WRITE,
    BYPASS
}

data class ProviderExecutionRule(
    val providerId: String,
    val stage: ProviderQueryStage,
    val connectTimeoutMillis: Int,
    val readTimeoutMillis: Int,
    val maxResponseBytes: Int,
    val maxAttempts: Int,
    val baseRetryDelayMillis: Long,
    val minimumRequestIntervalMillis: Long,
    val freshCacheSeconds: Long
) {
    init {
        require(providerId.isNotBlank())
        require(connectTimeoutMillis in 1_000..120_000)
        require(readTimeoutMillis in 1_000..120_000)
        require(maxResponseBytes in 1_024..32 * 1024 * 1024)
        require(maxAttempts in 1..3)
        require(baseRetryDelayMillis in 0..60_000)
        require(minimumRequestIntervalMillis in 0..60_000)
        require(freshCacheSeconds in 0..7 * 24 * 60 * 60)
    }
}

object ProviderExecutionPolicy {
    val revision: String = PROVIDER_EXECUTION_POLICY_REVISION

    fun ruleFor(plan: ProviderQueryPlan): ProviderExecutionRule {
        require(ProviderQueryPlanner.fingerprintMatches(plan)) { "Provider query plan fingerprint mismatch" }
        return when (plan.providerId) {
            "openstreetmap_overpass" -> when (plan.stage) {
                ProviderQueryStage.OSM_AREA_LOOKUP -> ProviderExecutionRule(
                    providerId = plan.providerId,
                    stage = plan.stage,
                    connectTimeoutMillis = 10_000,
                    readTimeoutMillis = 20_000,
                    maxResponseBytes = 2 * 1024 * 1024,
                    maxAttempts = 2,
                    baseRetryDelayMillis = 2_000,
                    minimumRequestIntervalMillis = 1_000,
                    freshCacheSeconds = 86_400
                )
                ProviderQueryStage.OSM_ROADS -> ProviderExecutionRule(
                    providerId = plan.providerId,
                    stage = plan.stage,
                    connectTimeoutMillis = 15_000,
                    readTimeoutMillis = 45_000,
                    maxResponseBytes = 12 * 1024 * 1024,
                    maxAttempts = 2,
                    baseRetryDelayMillis = 3_000,
                    minimumRequestIntervalMillis = 0,
                    freshCacheSeconds = 900
                )
                else -> error("Unsupported OpenStreetMap execution stage ${plan.stage}")
            }
            "oakland_county_roads", "census_tigerweb_transportation" -> ProviderExecutionRule(
                providerId = plan.providerId,
                stage = plan.stage,
                connectTimeoutMillis = 10_000,
                readTimeoutMillis = 30_000,
                maxResponseBytes = 12 * 1024 * 1024,
                maxAttempts = 3,
                baseRetryDelayMillis = 750,
                minimumRequestIntervalMillis = 0,
                freshCacheSeconds = 900
            )
            "oakland_county_site_addresses" -> ProviderExecutionRule(
                providerId = plan.providerId,
                stage = plan.stage,
                connectTimeoutMillis = 10_000,
                readTimeoutMillis = 30_000,
                maxResponseBytes = 8 * 1024 * 1024,
                maxAttempts = 3,
                baseRetryDelayMillis = 750,
                minimumRequestIntervalMillis = 0,
                freshCacheSeconds = 900
            )
            "oakland_county_buildings" -> ProviderExecutionRule(
                providerId = plan.providerId,
                stage = plan.stage,
                connectTimeoutMillis = 10_000,
                readTimeoutMillis = 30_000,
                maxResponseBytes = if (plan.stage == ProviderQueryStage.BUILDING_METADATA) 1024 * 1024 else 12 * 1024 * 1024,
                maxAttempts = 3,
                baseRetryDelayMillis = 750,
                minimumRequestIntervalMillis = 0,
                freshCacheSeconds = if (plan.stage == ProviderQueryStage.BUILDING_METADATA) 86_400 else 900
            )
            "google_geocoding", "google_roads" -> error("Optional Google crosschecks are not enabled in the provider execution coordinator")
            else -> error("Unsupported provider execution policy for ${plan.providerId}")
        }.also { rule ->
            require(rule.stage == plan.stage) { "Execution policy stage mismatch" }
        }
    }

    fun isRetryableStatus(plan: ProviderQueryPlan, statusCode: Int): Boolean {
        if (statusCode in setOf(408, 425, 429, 500, 502, 503, 504)) return true
        return plan.providerId == "openstreetmap_overpass" && plan.stage == ProviderQueryStage.OSM_ROADS && statusCode == 406
    }

    fun retryDelayMillis(
        plan: ProviderQueryPlan,
        rule: ProviderExecutionRule,
        statusCode: Int?,
        attemptNumber: Int,
        responseHeaders: Map<String, List<String>>,
        now: Instant
    ): Long {
        require(attemptNumber >= 1)
        val exponent = (attemptNumber - 1).coerceAtMost(4)
        val exponential = min(60_000L, rule.baseRetryDelayMillis * (1L shl exponent))
        val overpassFloor = if (
            plan.providerId == "openstreetmap_overpass" &&
            plan.stage == ProviderQueryStage.OSM_ROADS &&
            statusCode in setOf(406, 429)
        ) 30_000L else 0L
        val retryAfter = parseRetryAfterMillis(responseHeaders, now)
        return max(exponential, max(overpassFloor, retryAfter))
    }

    private fun parseRetryAfterMillis(headers: Map<String, List<String>>, now: Instant): Long {
        val raw = headers.entries.firstOrNull { it.key.equals("Retry-After", ignoreCase = true) }
            ?.value?.firstOrNull()?.trim().orEmpty()
        if (raw.isBlank()) return 0
        raw.toLongOrNull()?.let { seconds ->
            return seconds.coerceIn(0, 60).times(1_000)
        }
        val target = runCatching { ZonedDateTime.parse(raw, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant() }.getOrNull()
            ?: return 0
        return Duration.between(now, target).toMillis().coerceIn(0, 60_000)
    }
}

data class ProviderTransportResponse(
    val statusCode: Int,
    val body: String,
    val headers: Map<String, List<String>>,
    val observedAtUtc: String
) {
    init {
        require(statusCode in 100..599) { "Invalid HTTP status code $statusCode" }
        require(headers.keys.none { it.contains('\n') || it.contains('\r') })
        Instant.parse(observedAtUtc)
    }
}

fun interface ProviderTransport {
    @Throws(IOException::class)
    fun execute(plan: ProviderQueryPlan, rule: ProviderExecutionRule): ProviderTransportResponse
}

fun interface ProviderSleeper {
    fun sleep(millis: Long)
}

class ProviderResponseTooLargeException(message: String) : IOException(message)
class ProviderCacheIntegrityException(message: String) : IllegalStateException(message)
class ProviderHttpStatusException(val statusCode: Int, message: String) : IOException(message)
class ProviderExecutionExhaustedException(message: String, cause: Throwable? = null) : IOException(message, cause)

object ProviderHttpEncoding {
    fun requestUrl(plan: ProviderQueryPlan): String {
        require(plan.endpoint.startsWith("https://"))
        if (plan.queryParameters.isEmpty()) return plan.endpoint
        val separator = if ('?' in plan.endpoint) '&' else '?'
        return plan.endpoint + separator + plan.queryParameters.joinToString("&") { (key, value) ->
            "${queryComponent(key)}=${queryComponent(value)}"
        }
    }

    fun formBody(plan: ProviderQueryPlan): String = plan.formParameters.joinToString("&") { (key, value) ->
        "${formComponent(key)}=${formComponent(value)}"
    }

    private fun queryComponent(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name()).replace("+", "%20")
    private fun formComponent(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name())
}

class HttpsUrlConnectionProviderTransport(
    private val clock: Clock = Clock.systemUTC()
) : ProviderTransport {
    override fun execute(plan: ProviderQueryPlan, rule: ProviderExecutionRule): ProviderTransportResponse {
        require(ProviderQueryPlanner.fingerprintMatches(plan)) { "Provider query plan fingerprint mismatch" }
        require(rule.providerId == plan.providerId && rule.stage == plan.stage) { "Execution rule does not belong to provider plan" }
        val uri = URI(ProviderHttpEncoding.requestUrl(plan))
        require(uri.scheme == "https") { "Provider transport forbids non-HTTPS requests" }
        val connection = uri.toURL().openConnection() as? HttpsURLConnection
            ?: error("Provider endpoint did not produce an HTTPS connection")
        try {
            connection.instanceFollowRedirects = false
            connection.connectTimeout = rule.connectTimeoutMillis
            connection.readTimeout = rule.readTimeoutMillis
            connection.requestMethod = when (plan.method) {
                ProviderHttpMethod.GET -> "GET"
                ProviderHttpMethod.POST_FORM -> "POST"
            }
            plan.headers.forEach { (name, value) -> connection.setRequestProperty(name, value) }
            if (plan.method == ProviderHttpMethod.POST_FORM) {
                val bytes = ProviderHttpEncoding.formBody(plan).toByteArray(StandardCharsets.UTF_8)
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                connection.setFixedLengthStreamingMode(bytes.size)
                connection.outputStream.use { output -> output.write(bytes) }
            }

            val status = connection.responseCode
            val declaredLength = connection.contentLengthLong
            if (declaredLength > rule.maxResponseBytes) {
                throw ProviderResponseTooLargeException(
                    "${plan.providerId}/${plan.stage} declared $declaredLength response bytes above limit ${rule.maxResponseBytes}"
                )
            }
            val stream = if (status in 200..399) connection.inputStream else connection.errorStream
            val body = if (stream == null) "" else stream.use { readUtf8Limited(it, rule.maxResponseBytes) }
            val headers = connection.headerFields
                .filterKeys { it != null }
                .mapKeys { requireNotNull(it.key) }
                .mapValues { (_, values) -> values?.filterNotNull().orEmpty() }
            return ProviderTransportResponse(
                statusCode = status,
                body = body,
                headers = headers,
                observedAtUtc = Instant.now(clock).toString()
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun readUtf8Limited(input: java.io.InputStream, maxBytes: Int): String {
        val output = ByteArrayOutputStream(min(maxBytes, 64 * 1024))
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > maxBytes) throw ProviderResponseTooLargeException("Provider response exceeded $maxBytes bytes")
            output.write(buffer, 0, read)
        }
        return output.toString(StandardCharsets.UTF_8.name())
    }
}

interface ProviderEvidenceCache {
    fun read(plan: ProviderQueryPlan, rule: ProviderExecutionRule, now: Instant): ProviderRawResponse?
    fun write(response: ProviderRawResponse, rule: ProviderExecutionRule)
}

object NoProviderEvidenceCache : ProviderEvidenceCache {
    override fun read(plan: ProviderQueryPlan, rule: ProviderExecutionRule, now: Instant): ProviderRawResponse? = null
    override fun write(response: ProviderRawResponse, rule: ProviderExecutionRule) = Unit
}

class DirectoryProviderEvidenceCache(private val directory: File) : ProviderEvidenceCache {
    init {
        if (!directory.exists()) require(directory.mkdirs()) { "Unable to create provider evidence cache directory: $directory" }
        require(directory.isDirectory) { "Provider evidence cache path is not a directory: $directory" }
    }

    @Synchronized
    override fun read(plan: ProviderQueryPlan, rule: ProviderExecutionRule, now: Instant): ProviderRawResponse? {
        require(ProviderQueryPlanner.fingerprintMatches(plan))
        val bodyFile = bodyFile(plan)
        val metadataFile = metadataFile(plan)
        if (!bodyFile.exists() && !metadataFile.exists()) return null
        if (!bodyFile.isFile || !metadataFile.isFile) {
            throw ProviderCacheIntegrityException("Provider cache entry is incomplete for ${plan.planFingerprint}")
        }
        if (bodyFile.length() > rule.maxResponseBytes.toLong()) {
            throw ProviderCacheIntegrityException("Cached provider response exceeds execution size limit")
        }
        val metadata = parseMetadata(metadataFile)
        requireCacheField(metadata, "version", "1")
        requireCacheField(metadata, "executionPolicyRevision", PROVIDER_EXECUTION_POLICY_REVISION)
        requireCacheField(metadata, "planFingerprint", plan.planFingerprint)
        requireCacheField(metadata, "requestFingerprint", plan.requestFingerprint)
        requireCacheField(metadata, "providerId", plan.providerId)
        requireCacheField(metadata, "stage", plan.stage.name)
        val observed = metadata.getValue("observedAtUtc")
        val observedInstant = runCatching { Instant.parse(observed) }.getOrElse {
            throw ProviderCacheIntegrityException("Cached provider observation timestamp is invalid")
        }
        val ageSeconds = Duration.between(observedInstant, now).seconds
        if (ageSeconds < -300) throw ProviderCacheIntegrityException("Cached provider observation is implausibly in the future")

        val declaredBytes = metadata.getValue("bodyBytes").toLongOrNull()
            ?: throw ProviderCacheIntegrityException("Cached provider body length is invalid")
        if (declaredBytes != bodyFile.length()) throw ProviderCacheIntegrityException("Cached provider body length mismatch")
        val bodyBytes = bodyFile.readBytes()
        val expectedSha = metadata.getValue("responseSha256")
        if (!EXECUTION_SHA256_HEX.matches(expectedSha) || sha256Execution(bodyBytes) != expectedSha) {
            throw ProviderCacheIntegrityException("Cached provider response digest mismatch")
        }
        val body = bodyBytes.toString(StandardCharsets.UTF_8)
        if (body.isBlank()) throw ProviderCacheIntegrityException("Cached provider response body is blank")
        val raw = ProviderRawResponse(plan = plan, body = body, observedAtUtc = observed)
        if (raw.responseSha256 != expectedSha) throw ProviderCacheIntegrityException("Cached provider response digest does not bind to parsed body")
        if (ageSeconds > rule.freshCacheSeconds) return null
        return raw
    }

    @Synchronized
    override fun write(response: ProviderRawResponse, rule: ProviderExecutionRule) {
        require(ProviderQueryPlanner.fingerprintMatches(response.plan))
        require(rule.providerId == response.plan.providerId && rule.stage == response.plan.stage)
        val bodyBytes = response.body.toByteArray(StandardCharsets.UTF_8)
        require(bodyBytes.size <= rule.maxResponseBytes) { "Provider response exceeds cache size limit" }
        val bodyFile = bodyFile(response.plan)
        val metadataFile = metadataFile(response.plan)
        val bodyTmp = File(directory, bodyFile.name + ".tmp")
        val metadataTmp = File(directory, metadataFile.name + ".tmp")
        val metadata = buildString {
            append("version=1\n")
            append("executionPolicyRevision=").append(PROVIDER_EXECUTION_POLICY_REVISION).append('\n')
            append("planFingerprint=").append(response.plan.planFingerprint).append('\n')
            append("requestFingerprint=").append(response.plan.requestFingerprint).append('\n')
            append("providerId=").append(response.plan.providerId).append('\n')
            append("stage=").append(response.plan.stage.name).append('\n')
            append("observedAtUtc=").append(response.observedAtUtc).append('\n')
            append("responseSha256=").append(response.responseSha256).append('\n')
            append("bodyBytes=").append(bodyBytes.size).append('\n')
        }
        try {
            writeSynced(bodyTmp, bodyBytes)
            writeSynced(metadataTmp, metadata.toByteArray(StandardCharsets.UTF_8))
            moveReplace(bodyTmp, bodyFile)
            moveReplace(metadataTmp, metadataFile)
        } finally {
            bodyTmp.delete()
            metadataTmp.delete()
        }
    }

    private fun bodyFile(plan: ProviderQueryPlan): File = File(directory, "${plan.planFingerprint}.body")
    private fun metadataFile(plan: ProviderQueryPlan): File = File(directory, "${plan.planFingerprint}.meta")

    private fun parseMetadata(file: File): Map<String, String> {
        val lines = file.readLines(StandardCharsets.UTF_8).filter(String::isNotBlank)
        val expectedKeys = setOf(
            "version", "executionPolicyRevision", "planFingerprint", "requestFingerprint", "providerId",
            "stage", "observedAtUtc", "responseSha256", "bodyBytes"
        )
        val pairs = lines.map { line ->
            val index = line.indexOf('=')
            if (index <= 0) throw ProviderCacheIntegrityException("Malformed provider cache metadata")
            line.substring(0, index) to line.substring(index + 1)
        }
        if (pairs.map { it.first }.distinct().size != pairs.size) throw ProviderCacheIntegrityException("Duplicate provider cache metadata key")
        val map = pairs.toMap()
        if (map.keys != expectedKeys) throw ProviderCacheIntegrityException("Provider cache metadata schema drift: ${map.keys}")
        return map
    }

    private fun requireCacheField(metadata: Map<String, String>, key: String, expected: String) {
        if (metadata[key] != expected) throw ProviderCacheIntegrityException("Provider cache $key mismatch")
    }

    private fun writeSynced(file: File, bytes: ByteArray) {
        FileOutputStream(file).use { output ->
            output.write(bytes)
            output.fd.sync()
        }
    }

    private fun moveReplace(source: File, target: File) {
        try {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }
}

class ProviderRateGate {
    private val lastRequestAtMillis = mutableMapOf<String, Long>()

    @Synchronized
    fun await(plan: ProviderQueryPlan, rule: ProviderExecutionRule, clock: Clock, sleeper: ProviderSleeper) {
        val interval = rule.minimumRequestIntervalMillis
        if (interval <= 0) return
        val key = if (plan.providerId == "openstreetmap_overpass" && plan.stage == ProviderQueryStage.OSM_AREA_LOOKUP) {
            "nominatim-public-search"
        } else "${plan.providerId}:${plan.stage}"
        val nowMillis = Instant.now(clock).toEpochMilli()
        val previous = lastRequestAtMillis[key]
        if (previous != null) {
            val wait = interval - (nowMillis - previous)
            if (wait > 0) sleeper.sleep(wait)
        }
        lastRequestAtMillis[key] = Instant.now(clock).toEpochMilli()
    }

    companion object {
        val shared: ProviderRateGate = ProviderRateGate()
    }
}

class ProviderExecutionCoordinator(
    private val transport: ProviderTransport,
    private val cache: ProviderEvidenceCache = NoProviderEvidenceCache,
    private val clock: Clock = Clock.systemUTC(),
    private val sleeper: ProviderSleeper = ProviderSleeper { Thread.sleep(it) },
    private val rateGate: ProviderRateGate = ProviderRateGate.shared
) {

    fun execute(plan: ProviderQueryPlan, cacheMode: ProviderCacheMode = ProviderCacheMode.READ_WRITE): ProviderRawResponse {
        require(ProviderQueryPlanner.fingerprintMatches(plan)) { "Provider query plan fingerprint mismatch" }
        val rule = ProviderExecutionPolicy.ruleFor(plan)
        require(rule.providerId == plan.providerId && rule.stage == plan.stage)
        val now = Instant.now(clock)
        if (cacheMode == ProviderCacheMode.READ_WRITE) {
            cache.read(plan, rule, now)?.let { cached ->
                require(cached.plan == plan) { "Cached response changed provider query plan" }
                return cached
            }
        }

        var lastFailure: IOException? = null
        for (attempt in 1..rule.maxAttempts) {
            rateGate.await(plan, rule, clock, sleeper)
            val response = try {
                transport.execute(plan, rule)
            } catch (tooLarge: ProviderResponseTooLargeException) {
                throw tooLarge
            } catch (io: IOException) {
                lastFailure = io
                if (attempt >= rule.maxAttempts) break
                val delay = ProviderExecutionPolicy.retryDelayMillis(
                    plan = plan,
                    rule = rule,
                    statusCode = null,
                    attemptNumber = attempt,
                    responseHeaders = emptyMap(),
                    now = Instant.now(clock)
                )
                if (delay > 0) sleeper.sleep(delay)
                continue
            }
            validateTransportResponse(plan, rule, response)
            if (response.statusCode in 200..299) {
                if (response.body.isBlank()) throw ProviderExecutionExhaustedException("${plan.providerId}/${plan.stage} returned a blank success body")
                val raw = ProviderRawResponse(plan = plan, body = response.body, observedAtUtc = response.observedAtUtc)
                require(raw.plan == plan) { "Provider execution did not preserve exact query plan" }
                if (cacheMode == ProviderCacheMode.READ_WRITE) cache.write(raw, rule)
                return raw
            }

            val statusFailure = ProviderHttpStatusException(
                statusCode = response.statusCode,
                message = "${plan.providerId}/${plan.stage} HTTP ${response.statusCode}"
            )
            lastFailure = statusFailure
            val retryable = ProviderExecutionPolicy.isRetryableStatus(plan, response.statusCode)
            if (!retryable || attempt >= rule.maxAttempts) throw statusFailure
            val delay = ProviderExecutionPolicy.retryDelayMillis(
                plan = plan,
                rule = rule,
                statusCode = response.statusCode,
                attemptNumber = attempt,
                responseHeaders = response.headers,
                now = Instant.now(clock)
            )
            if (delay > 0) sleeper.sleep(delay)
        }
        throw ProviderExecutionExhaustedException(
            "${plan.providerId}/${plan.stage} failed after ${rule.maxAttempts} attempt(s)",
            lastFailure
        )
    }

    private fun validateTransportResponse(plan: ProviderQueryPlan, rule: ProviderExecutionRule, response: ProviderTransportResponse) {
        Instant.parse(response.observedAtUtc)
        val bytes = response.body.toByteArray(StandardCharsets.UTF_8).size
        if (bytes > rule.maxResponseBytes) {
            throw ProviderResponseTooLargeException(
                "${plan.providerId}/${plan.stage} returned $bytes bytes above limit ${rule.maxResponseBytes}"
            )
        }
    }

}

private fun sha256Execution(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
    .digest(bytes)
    .joinToString("") { "%02x".format(it) }
